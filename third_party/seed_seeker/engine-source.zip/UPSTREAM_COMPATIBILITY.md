# Compatibility boundary

Shattered Pixel Dungeon generation changes between versions. Every engine result
must therefore carry the target version, commit, and run profile. This project
targets the final [v4.0.2 source release](https://github.com/00-Evan/shattered-pixel-dungeon/tree/v4.0.2),
build 922. `SHPD_COMMIT` holds its source commit,
`57a4e06a4caf162446d1c28caa7983f0493fecf0`. The 4.0.2 parity oracle
(`tooling/oracle-4.0`) runs the matching unmodified official release JAR,
with its SHA-256 pinned separately. The v3.3.8 fixtures
that still exist were pinned at commit
`7b8b845a76fe76c6b7c031ae9e570852411f56db`.

## What “exact” means

The Rust engine reproduces the seeded, static world loot visible in a fresh
custom-seed run under the canonical profile:

- main branch floors generated in ascending order;
- Warrior, no challenges, no equipped trinket;
- no bones or other profile-dependent bonus items;
- tutorial complete (`SPDSettings.intro() == false`), with the game's debug
  journal defaults: all pages read except the Halls King's `attrition` page,
  whose floor-24 placement can clear grass and affect subsequent generation;
- no player-caused drops or inventory-dependent mutations;
- weapons, armor, wands, rings, artifacts, their searchable upgrade, cursed flag,
  enchantment/glyph, floor, source, container, secret-room placement, and mutually
  exclusive choice group.

Item appearances are part of that reproduced state. `Dungeon.init()` shuffles
`Ring.gems` once per run and hands each ring class the gem at its own index, so
which gem — and therefore which colour — a ring shows is fixed by the seed
alone, before any floor is generated and before any challenge is read. The
engine reproduces that shuffle and hands it to frontends beside the item
manifest: `GeneratedWorld::ring_gems` in process, the twelve-byte table in the
`SSC5` scout packet, and the scout document's `ringGems` (wasm). A ring's
`items.png` cell is
`RING_SPRITE_BASE` plus its class's gem, while the catalog's own per-ring cell
is the class's identity — what a seedless surface such as the query editor
draws, and what indexes the class's glyph in `item_icons.png`. A frontend that
renders a scouted ring from the catalog cell alone shows the same twelve
colours for every seed, which is not what the run holds.

Normal monster death loot is excluded. It is rolled during play after the level
generator has been popped and is generally based on the unseeded base RNG.
The seed scout reports this same static, searchable set rather than claiming to
be a complete inventory of every consumable or future drop in a run.

Search source constraints refer to the source stored on these static records.
Per-item uncursed constraints reject records whose cursed flag is set.
Same-item groups require distinct obtainable copies with the same concrete item
ID, while normal AND requirements may match different types. The blacksmith
condition is satisfied only when the generated Blacksmith quest room is
accessible within the selected maximum floor; a failed room build does not
count. The Smith-reward exclusion independently prevents those choice items from
satisfying requirements while still allowing the room to meet the blacksmith
condition. The Wandmaker-quest filter is satisfied when the scheduled Prison
quest rolls the demanded variant: the giver appears on floors 7–9 (certain by
floor 9), and its variant is fixed when the quest room is scheduled, so a
query demanding one is impossible below floor 7 and forces the prefix to run
to floor `min(max_depth, 9)` even when every item requirement was already
met. The overall maximum floor and each item's optional floor limit are
passed into planning, so later regions are not simulated once every remaining
requirement has reached its deadline.

## Boss-floor transitions

Under the canonical fresh custom-seed profile, depths 5, 10, 15, and 25 can be
skipped by the search engine after their independent depth roots are computed.
Official v3.3.8 checkpoints across three seeds show identical before/after
Generator, LimitedDrops, quest, special/secret-room queue, and shop-dependent
state. Their initial level creation contains no searchable weapon, armor, wand,
or ring. Depth 10 does directly place an Iron Key, which is outside the searchable
catalog. The boss levels also seed a child generator for `Bones.get()`; with
bones disabled it produces no items, and both the child and all map RNG are
confined to that boss depth.

Because depths 5, 10, and 15 contribute no searchable items, the apps'
floor-limit selectors (the global scope limit and each requirement's
"within first N floors" bound) do not offer them. Stored queries and presets
that still hold one of those limits are rewritten to the equivalent floor
below (5→4, 10→9, 15→14) when loaded; the JSON query format itself continues
to accept every value in 1–24.

Depth 20 must not be skipped. `CityBossLevel.build()` creates an `ImpShopRoom`,
and `ImpShopRoom.paint()` eagerly calls `ShopRoom.generateItems()` before the
shop is visible. The resulting cached tier-five weapon, Plate Armor, missile,
tipped darts, and possible rare wand or ring are searchable initial-world content, and
the call mutates the live Generator state consumed by Halls. The Rust prefix
therefore executes this transition between depths 19 and 21 and includes its
shop records. Rewards generated only after fighting a boss remain excluded as
later gameplay loot.

The Imp quest no longer rewards a single ring. When its accessible City quest
room (floors 17–19) is created, the quest rolls six vault prizes — an artifact
or ring, a ring, a tier-5 weapon with a tier-4 thrown weapon or the reverse,
plate armor, and a wand, at +2..+4 (the tier-4 weapons +3..+5), never cursed,
with a good enchantment or glyph on every weapon and armor — and opens a
Vault sub-level whose treasure rooms hold further equipment at +0..+3 plus one
+4 tier-4 melee weapon, uncursed, with good or no effects. All of it is
generated with the world and is therefore searchable, reported with source
`ImpReward` (the six prizes) or `VaultTreasure` (the treasure rooms), even
though collecting it requires completing the quest. The player may carry
exactly one item out of the vault, so every Imp-reward and vault-treasure
record of a world shares one mutually exclusive choice group, and a query can
be satisfied by at most one of them. These are the only sources of `+4` armor,
wands and rings and of `+4`/`+5` weapons.

The vault sub-level is generated from `seedForDepth(depth, 1)` — a seed derived
from the Imp's floor and the branch number — independently of the main run's
generator state, so its contents depend only on the dungeon seed and the floor
the quest landed on, not on anything the player did before entering. The
engine builds it immediately after the City floor that schedules the quest.
A search skips that extra level whenever no requirement could be satisfied by
vault treasure (`FloorGate::wants_vault_treasure`, answered by the query
plan), which is exact because unmatched items never change a verdict;
scouting and probability calibration always generate it. Which consumable
sits in a given vault heap is decided by an unseeded shuffle upstream and is
not modelled; every weapon, armor, wand and ring is.

Scroll-of-Transmutation outcomes are not searchable. Run setup resets the RNG
stack to an unseeded gameplay generator; floor creation temporarily pushes a
depth-seeded RNG, then pops it before gameplay. A scroll used on a collected
prize draws from the live gameplay RNG instead, so the dungeon seed does not
fix the result and intervening attacks or other RNG-consuming actions can
change it.

## Why floors are simulated sequentially

Each floor has an independent depth root, but the world is not floor-independent.
Generator card decks, special/secret-room schedules, limited drops, and quest
rewards persist across the run. Spatial generation must also be reproduced:
room placement, painting, mob placement, and random-cell rejection loops consume
the same floor stream before and between item rolls.

## Upstream nondeterministic edges

On a first installation, v3.3.8 places the early Guidebook with an unseeded
auxiliary RNG. That heap can change how many isolated grass-painter draws are
skipped and can therefore change the decorative map. Like established seed
finders, this project uses completed tutorial/journal state and does not place
that Guidebook. No seeded RNG stream is replaced or canonicalized.

Two secret rooms select consumables from a real Java `HashMap<Class, …>`.
`Class.hashCode()` identity and map iteration order are not specified across JVM
implementations. Their consumable-only output cannot be intrinsically identical
between desktop OpenJDK and Android ART. These rooms do not generate the target
weapon/armor/wand/ring identity, but the oracle records the runtime/order policy when
their output is compared.

Entrance guide pages and missile set IDs also use unseeded randomness. Neither
changes searchable equipment type, level, enchantment, or glyph and both are
normalized out of parity snapshots.

`ShopRoom.ChooseBag` has an RNG-free equal-score tie whose result depends on
`HashMap` iteration (observed as Magical Holster versus Potion Bandolier across
JVM versions). It changes only non-searchable bag/limited-drop metadata. The
official oracle preserves the runtime result and records JVM provenance.

## Parity gates

1. Seed text/code conversion, including Java UTF-16 hashing.
2. MX3, Java's 48-bit LCG, bounded rejection, signed `nextLong`, floats,
   distributions, and both shuffle overloads.
3. Run initialization and every persistent deck/queue seed.
4. Phase snapshots for rooms, map, mobs, items, and final generator state.
5. Whole-floor item/event snapshots across randomized and targeted seeds.
6. An Android/ART oracle pass for runtime-sensitive collection ordering.

The current desktop fixtures use Temurin 25.0.4.1. `tooling/oracle-4.0` retains
official Java behavior and has no diagnostic RNG canonicalization.

Android native builds use Rust `opt-level=2` with fat LTO. The workspace's
host release profile remains O3. With rustc 1.94/LLVM 21.1.8, Android AArch64
O3 miscompiles the otherwise scalar seed-1 City prefix even though all SIMD
depth roots still match their scalar values. O2 is exact in on-device scalar
and batch fixtures and in a 4,096-seed depth-24 device scan. This target build
override is therefore part of the pinned compatibility profile, not a tuning
preference.
