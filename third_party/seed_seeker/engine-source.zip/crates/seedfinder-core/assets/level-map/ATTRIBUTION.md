# Level map sprites

These are unmodified Shattered Pixel Dungeon PNG assets:

- Pixel Dungeon © 2012–2015 Oleg Dolya / Watabou.
- Shattered Pixel Dungeon © 2014–2026 Evan Debenham.
- License: GPL-3.0-or-later; see the repository's [COPYING](../../../../COPYING).

Source revision: **57a4e06a4caf162446d1c28caa7983f0493fecf0**.

Original files are in
[`core/src/main/assets/environment`](https://github.com/00-Evan/shattered-pixel-dungeon/tree/57a4e06a4caf162446d1c28caa7983f0493fecf0/core/src/main/assets/environment):
`tiles_sewers.png`, `tiles_prison.png`, `tiles_caves.png`, `tiles_city.png`,
`tiles_halls.png`, `tiles_caves_crystal.png`, `tiles_caves_gnoll.png`,
`water0.png` through `water4.png`, `terrain_features.png`,
`occlusion_shadows.png`, `raised_terrain.png`, and
`custom_tiles/caves_quest.png` and `custom_tiles/city_quest.png` (stored here
without the `custom_tiles/` prefix). Boss maps also embed the same revision’s
`custom_tiles/sewer_boss.png`, `custom_tiles/caves_boss.png`,
`custom_tiles/rat_king_room.png`, `custom_tiles/carpet.png`, and
`sprites/pylon.png` and `sprites/ratking.png` (from `core/src/main/assets`).
Initial contents additionally use `sprites/items.png`, the initial mob/NPC
sprite atlases in `sprites/`, `effects/specks.png`, `effects/effects.png`,
`interfaces/icons.png` (sleep indicators and targeting markers), and
`environment/custom_tiles/prison_quest.png`, `weak_floor.png`, and
`halls_special.png`, all from that same revision. No texture was modified.
Every file's SHA-256 and dimensions are recorded in
[`level_map/assets.rs`](../../src/level_map/assets.rs) and returned in map JSON.

Rendering rules are adapted from the same revision's
[`DungeonTileSheet`](https://github.com/00-Evan/shattered-pixel-dungeon/blob/57a4e06a4caf162446d1c28caa7983f0493fecf0/core/src/main/java/com/shatteredpixel/shatteredpixeldungeon/tiles/DungeonTileSheet.java),
`DungeonTerrainTilemap`, `DungeonWallsTilemap`, `WallOcclusionTilemap`,
`RaisedTerrainTilemap`, `TerrainFeaturesTilemap`, `Level.cleanWalls`, the geometric
half-wall masks in `FogOfWar`, the trap/plant sprite indices,
`ItemSpriteSheet`, the corresponding `*Sprite` classes, quest room custom tilemaps,
`CharSprite`/`ItemSprite` shadows, `EmoIcon.Sleep`, `Speck`, `SacrificialParticle`, `ElmoParticle`,
`Beam.DeathRay`, `CheckedCell`, `TargetedCell`, `VaultLaser`, `VaultSentry`,
`Ballistica`, `ConeAOE`,
`WindParticle.Wind` and its chasm visibility gate in `Level.addVisuals`,
`CityLevel.GreenFlame`, `AmbitiousImpRoom` entrance/barrier/banners, `Carpet`,
`StatuesRoom`, `HallwayRoom`, and `LibraryRingRoom` entrance/exit carpet layouts,
and `GameScene` water scrolling and `SewerLevel.Sink` pixel particles. The overview
uses raised sprites, offers concealed/revealed secret layers, and makes ambient animation
repeatable. The source revision matches the generation engine's v4.0.2 pin;
the release JAR's digest is recorded separately in `tooling/oracle-4.0/build.sh`.

To update, obtain the original PNGs and rendering tables from one explicit
source revision, update the embedded manifest and bounds/selection tests, and
review the map schema and cache version. Do not silently swap sprite atlases:
their indices are part of the rendering contract.
