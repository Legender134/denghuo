//! Catalyst offers and the first transmutation deck. Reading never mutates the world RNG.
use crate::catalog::ItemId;
use crate::generator::{GeneratedItem, TrinketKind, random_category};
use crate::model::WorldItem;
use crate::rng::RandomStack;
use crate::run::{GeneratorCategory, GeneratorState, RunState};
use crate::seed::DungeonSeed;

/// Resolve the query's complete selection rule for a single scout or replay.
/// Search batches use the prepared policy in `QueryPlan` instead.
#[must_use]
pub fn selected_for_query(seed: DungeonSeed, query: &crate::query::SearchQuery) -> Option<ItemId> {
    crate::auto_trinkets::AutoTrinketPolicy::prepare(query).map_or_else(
        || resolve_selection(seed, &selection_slots(query)),
        |policy| policy.selected_trinket(seed),
    )
}

/// Validate a saved or manually chosen trinket against the actual initial offers.
///
/// # Errors
/// Rejects unknown IDs and items outside the seed's four initial choices.
pub fn parse_offered(seed: DungeonSeed, id: &str) -> Result<ItemId, String> {
    let selected = crate::catalog::item_by_stable_id(id)
        .ok_or_else(|| format!("unknown trinket: {id}"))?
        .id;
    if !initial_offers(seed).contains(&selected) {
        return Err("selected trinket must be one of the four initial catalyst offers".to_owned());
    }
    Ok(selected)
}

/// The full OR slots which request choosing a trinket. Keep every alternative:
/// even an unchecked alternative makes a multiply matching group ambiguous.
#[must_use]
pub fn selection_slots(query: &crate::query::SearchQuery) -> Vec<Vec<crate::query::Requirement>> {
    query
        .slots()
        .into_iter()
        .filter(|slot| slot.iter().any(|&i| query.requirements[i].select_trinket))
        .map(|slot| slot.into_iter().map(|i| query.requirements[i]).collect())
        .collect()
}

/// Resolve against initial offers, never against the remaining private deck.
/// Multiple distinct matching offers (within or across chosen slots) mean no trinket.
#[must_use]
pub fn resolve_selection(
    seed: DungeonSeed,
    slots: &[Vec<crate::query::Requirement>],
) -> Option<ItemId> {
    if slots.is_empty() {
        return None;
    }
    let offers = initial_offers(seed);
    let mut matches = offers.iter().copied().filter(|id| {
        slots.iter().any(|slot| {
            slot.iter()
                .any(|r| r.trinket_transmutations == 0 && r.item == Some(*id))
        })
    });
    let selected = matches.next()?;
    if matches.next().is_some() {
        None
    } else {
        Some(selected)
    }
}

/// Per-run, +3 generation effects. Stored alongside the RNG stack so nested
/// category/effect streams inherit the profile without thread-global state.
#[derive(Clone, Debug, Default)]
pub(crate) struct TrinketEffects {
    pub selected: Option<ItemId>,
    dungeon_seed: i64,
    feelings: Vec<bool>,
    shuffles: u32,
}

impl TrinketEffects {
    pub fn new(selected: Option<ItemId>, dungeon_seed: i64) -> Self {
        Self {
            selected,
            dungeon_seed,
            ..Self::default()
        }
    }
    pub fn is(&self, id: ItemId) -> bool {
        self.selected == Some(id)
    }
    pub fn level(&self, id: ItemId) -> i32 {
        if self.is(id) { 3 } else { -1 }
    }
    pub fn mimic_multiplier(&self) -> f32 {
        if self.is(ItemId::MimicTooth) {
            3.0
        } else {
            1.0
        }
    }
    pub fn exotic_multiplier(&self) -> f32 {
        if self.is(ItemId::RatSkull) { 5.0 } else { 1.0 }
    }
    pub fn exotic_chance(&self) -> f32 {
        if self.is(ItemId::ExoticCrystals) {
            0.8
        } else {
            0.0
        }
    }
    pub fn reveal_chance(&self) -> f32 {
        if self.is(ItemId::TrapMechanism) {
            0.4
        } else {
            0.0
        }
    }
    pub fn curse_multiplier(&self) -> f32 {
        if self.is(ItemId::ParchmentScrap) {
            0.0
        } else {
            1.0
        }
    }
    pub fn enchant_multiplier(&self) -> f32 {
        if self.is(ItemId::ParchmentScrap) {
            10.0
        } else {
            1.0
        }
    }
    pub fn next_feeling(&mut self) -> crate::level_prelude::Feeling {
        use crate::level_prelude::Feeling;
        let moss = self.is(ItemId::MossyClump);
        if self.feelings.is_empty() {
            self.feelings = if moss {
                vec![true, true, false, false, false, false]
            } else {
                vec![true, true, true, false, false, false]
            };
            let mut random = RandomStack::with_base_seed(0);
            random.push(self.dungeon_seed.wrapping_add(1));
            for _ in 0..=self.shuffles {
                random.shuffle_list(&mut self.feelings);
            }
            self.shuffles += 1;
        }
        match (moss, self.feelings.remove(0)) {
            (true, true) => Feeling::Grass,
            (true, false) => Feeling::Water,
            (false, true) => Feeling::Traps,
            (false, false) => Feeling::Chasm,
        }
    }
}

pub const INITIAL_OFFER_COUNT: usize = 4;
/// The remaining unique cards before the first deck refill.
pub const TRANSMUTATION_COUNT: u8 = 13;

/// Complete first private-deck draw order. Brewing consumes all four offers;
/// the remaining 13 are successive transmutations, regardless of the chosen offer.
///
/// # Panics
/// Panics only if a validated dungeon seed or the pinned trinket deck violates
/// its generation invariants.
#[must_use]
pub fn trinket_order(seed: DungeonSeed) -> [ItemId; 17] {
    order_from_generator(
        &RunState::new(i64::try_from(seed.value()).expect("seed fits i64")).generator,
    )
}

/// Add virtual transmutation outcomes only when matching a query that needs them.
/// They inherit the catalyst's acquisition constraints, not a claim that enough
/// scrolls exist by that floor. Generated worlds and native scout indices stay intact.
pub(crate) fn matching_items<'a>(
    query: &crate::query::SearchQuery,
    world: &'a crate::model::GeneratedWorld,
) -> std::borrow::Cow<'a, [WorldItem]> {
    use std::borrow::Cow;
    if !query
        .requirements
        .iter()
        .any(|r| r.trinket_transmutations > 0)
    {
        return Cow::Borrowed(&world.items);
    }
    let Some(catalyst) = world
        .items
        .iter()
        .find(|entry| crate::catalog::item(entry.item).kind == crate::catalog::ItemKind::Trinket)
    else {
        return Cow::Borrowed(&world.items);
    };
    let mut items = world.items.clone();
    items.extend(
        trinket_order(world.seed)[INITIAL_OFFER_COUNT..]
            .iter()
            .map(|&item| WorldItem {
                item,
                ..catalyst.clone()
            }),
    );
    Cow::Owned(items)
}

pub(crate) fn order_from_generator(generator: &GeneratorState) -> [ItemId; 17] {
    draw_order_from_generator(generator)
}

/// Read just the four initial offers while preserving the full diagnostic order.
pub(crate) fn initial_offers(seed: DungeonSeed) -> [ItemId; INITIAL_OFFER_COUNT] {
    initial_offers_from_generator(
        &RunState::new(i64::try_from(seed.value()).expect("seed fits i64")).generator,
    )
}

pub(crate) fn initial_offers_from_generator(
    generator: &GeneratorState,
) -> [ItemId; INITIAL_OFFER_COUNT] {
    draw_order_from_generator(generator)
}

fn draw_order_from_generator<const N: usize>(generator: &GeneratorState) -> [ItemId; N] {
    let mut generator = generator.clone();
    let mut random = RandomStack::with_base_seed(0);
    std::array::from_fn(|_| {
        let GeneratedItem::Trinket(kind) =
            random_category(&mut random, &mut generator, GeneratorCategory::Trinket, 1)
                .expect("valid trinket deck")
        else {
            unreachable!()
        };
        match kind {
            TrinketKind::RatSkull => ItemId::RatSkull,
            TrinketKind::ParchmentScrap => ItemId::ParchmentScrap,
            TrinketKind::PetrifiedSeed => ItemId::PetrifiedSeed,
            TrinketKind::ExoticCrystals => ItemId::ExoticCrystals,
            TrinketKind::MossyClump => ItemId::MossyClump,
            TrinketKind::DimensionalSundial => ItemId::DimensionalSundial,
            TrinketKind::ThirteenLeafClover => ItemId::ThirteenLeafClover,
            TrinketKind::TrapMechanism => ItemId::TrapMechanism,
            TrinketKind::MimicTooth => ItemId::MimicTooth,
            TrinketKind::WondrousResin => ItemId::WondrousResin,
            TrinketKind::EyeOfNewt => ItemId::EyeOfNewt,
            TrinketKind::SaltCube => ItemId::SaltCube,
            TrinketKind::VialOfBlood => ItemId::VialOfBlood,
            TrinketKind::ShardOfOblivion => ItemId::ShardOfOblivion,
            TrinketKind::ChaoticCenser => ItemId::ChaoticCenser,
            TrinketKind::FerretTuft => ItemId::FerretTuft,
            TrinketKind::CrackedSpyglass => ItemId::CrackedSpyglass,
        }
    })
}

pub(crate) fn expand_catalyst_offers(items: &mut Vec<WorldItem>, generator: &GeneratorState) {
    if !items
        .iter()
        .any(|item| item.item == ItemId::TrinketCatalyst)
    {
        return;
    }
    let offers = initial_offers_from_generator(generator);
    *items = items
        .drain(..)
        .flat_map(|world_item| {
            if world_item.item == ItemId::TrinketCatalyst {
                offers
                    .iter()
                    .map(|&item| WorldItem {
                        item,
                        ..world_item.clone()
                    })
                    .collect()
            } else {
                vec![world_item]
            }
        })
        .collect();
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::catalog::{ItemKind, item};
    use crate::challenges::Challenges;
    use crate::main_world::CanonicalMainWorldGenerator;
    use crate::query::{SearchQuery, scout_matches};
    use crate::search::WorldGenerator;

    #[test]
    fn selected_generation_preserves_prebrew_floors_and_matches_gated_search() {
        use crate::main_world::generate_main_world_with_trinket;
        let seed = DungeonSeed::MIN;
        let unselected = CanonicalMainWorldGenerator.generate(seed, 24);
        let selected =
            generate_main_world_with_trinket(seed, 24, Challenges::NONE, Some(ItemId::MimicTooth))
                .unwrap();
        // Seed zero's first lab is floor 4, so effects begin on floor 6.
        assert_eq!(
            unselected
                .items
                .iter()
                .filter(|i| i.depth <= 4)
                .collect::<Vec<_>>(),
            selected
                .items
                .iter()
                .filter(|i| i.depth <= 4)
                .collect::<Vec<_>>()
        );
        assert_ne!(unselected.items, selected.items);
        let query = crate::json_query::decode(r#"{"requirements":[{"item":"mimic_tooth","select_trinket":true},{"kind":"weapon","max_depth":24}]}"#).unwrap();
        let plan = crate::feasibility::QueryPlan::analyze(&query);
        let batch = CanonicalMainWorldGenerator.generate_batch_gated(&[seed; 5], 24, &plan);
        assert!(batch.iter().all(Option::is_some));
        for world in batch.into_iter().flatten() {
            // Search may skip vault treasure when no requirement can use it.
            assert_eq!(world, selected);
        }
    }

    #[test]
    fn complete_order_matches_beta4_jar_and_does_not_touch_generator() {
        // TrinketOracle AAA-AAA-AAA, pinned official BETA-4 JAR.
        let expected = [
            277, 280, 273, 278, 286, 279, 282, 275, 284, 274, 285, 288, 281, 276, 272, 287, 283,
        ];
        assert_eq!(
            trinket_order(DungeonSeed::MIN).map(|id| item(id).sprite_index),
            expected
        );
        let run = RunState::new(0);
        let before = run.generator.clone();
        assert_eq!(
            order_from_generator(&run.generator),
            trinket_order(DungeonSeed::MIN)
        );
        assert_eq!(run.generator, before);
    }

    #[test]
    fn offers_follow_catalyst_placement_in_scalar_and_gated_worlds() {
        let mut sources = std::collections::HashSet::new();
        for value in 0..100 {
            let seed = DungeonSeed::new(value).unwrap();
            let world = CanonicalMainWorldGenerator.generate(seed, 3);
            let offers: Vec<_> = world
                .items
                .iter()
                .filter(|i| item(i.item).kind == ItemKind::Trinket)
                .collect();
            assert_eq!(offers.len(), 4, "seed {value}");
            let location = offers[0];
            sources.insert(location.source);
            for offer in &offers {
                assert!((1..=3).contains(&offer.depth));
                assert_eq!(
                    (offer.depth, offer.source, offer.accessibility, offer.secret),
                    (
                        location.depth,
                        location.source,
                        location.accessibility,
                        location.secret
                    )
                );
                assert!(trinket_order(seed)[..4].contains(&offer.item));
            }
            // Each first offer matches, each tail entry does not, and a floor
            // limit before the actual catalyst must not claim an offer.
            for (index, id) in trinket_order(seed).iter().enumerate() {
                let query = crate::json_query::decode(&format!(
                    r#"{{"requirements":[{{"item":"{}"}}],"max_depth":3}}"#,
                    item(*id).stable_id
                ))
                .unwrap();
                assert_eq!(
                    scout_matches(&world, &query).matched_requirements,
                    usize::from(index < 4)
                );
                if index == 0 {
                    let plan = crate::feasibility::QueryPlan::analyze(&query);
                    let generated = CanonicalMainWorldGenerator.generate_batch_gated(
                        &[seed],
                        plan.generation_depth(),
                        &plan,
                    );
                    assert_eq!(generated[0].as_ref(), Some(&world));
                    if location.depth > 1 {
                        let early = SearchQuery {
                            max_depth: location.depth - 1,
                            ..query
                        };
                        assert_eq!(scout_matches(&world, &early).matched_requirements, 0);
                    }
                }
            }
        }
        assert!(sources.contains(&crate::model::ItemSource::LockedChest));
        assert!(sources.contains(&crate::model::ItemSource::Heap));
    }

    #[test]
    fn trinket_or_groups_and_shared_codecs_keep_offer_semantics() {
        assert!(crate::json_query::decode(r#"{"requirements":[{"kind":"trinket"}]}"#).is_err());
        let query = crate::json_query::decode(r#"{"requirements":[{"any_of":[{"item":"rat_skull"},{"item":"mimic_tooth"}]}],"max_depth":3}"#).unwrap();
        let world = CanonicalMainWorldGenerator.generate(DungeonSeed::MIN, 3);
        assert_eq!(scout_matches(&world, &query).matched_requirements, 1);
        assert_eq!(
            crate::deep_link::decode(&crate::deep_link::encode(&query).unwrap()).unwrap(),
            query
        );
        assert_eq!(
            crate::json_query::decode(&crate::json_query::encode(&query).to_string()).unwrap(),
            query
        );
        assert_eq!(query.challenges, Challenges::NONE);
        assert!(
            crate::json_query::decode(r#"{"requirements":[{"item":"rat_skull","upgrade":1}]}"#)
                .is_err()
        );
    }
}

#[cfg(test)]
mod prefix_tests {
    use super::*;

    #[test]
    fn initial_offers_are_the_complete_orders_prefix() {
        for index in 0..512_u64 {
            let seed = DungeonSeed::new(
                (index * 3_355_211_884_971 + 812_345_678_901) % crate::seed::TOTAL_SEEDS,
            )
            .unwrap();
            assert_eq!(
                initial_offers(seed),
                trinket_order(seed)[..INITIAL_OFFER_COUNT]
            );
        }
        assert_eq!(
            initial_offers(DungeonSeed::MIN),
            trinket_order(DungeonSeed::MIN)[..INITIAL_OFFER_COUNT]
        );
    }

    #[test]
    fn private_prefix_preserves_noninitial_decks_and_reset_boundaries() {
        let seeds = [i64::MIN, -1, 0, i64::MAX]
            .into_iter()
            .chain((1..=64_i64).map(|seed| seed.wrapping_mul(3_355_211_884_971)));
        for seed in seeds {
            let mut generator = RunState::new(seed).generator;
            let mut random = RandomStack::with_base_seed(seed.wrapping_add(19));
            for category in [
                GeneratorCategory::Potion,
                GeneratorCategory::Wand,
                GeneratorCategory::Ring,
            ] {
                random_category(&mut random, &mut generator, category, 1).unwrap();
            }
            for dropped in 0..=34 {
                if [0, 1, 3, 13, 14, 15, 16, 17, 18, 33, 34].contains(&dropped) {
                    let before = generator.clone();
                    assert_eq!(
                        initial_offers_from_generator(&generator),
                        order_from_generator(&generator)[..INITIAL_OFFER_COUNT],
                        "seed {seed}, dropped {dropped}"
                    );
                    assert_eq!(generator, before);
                }
                if dropped < 34 {
                    random_category(&mut random, &mut generator, GeneratorCategory::Trinket, 1)
                        .unwrap();
                }
            }
        }
    }
}
