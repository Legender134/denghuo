//! Canonical main-dungeon world generation through any depth 1..=24.
//!
//! The regional composites own the exact sequential state transitions for
//! their prefixes. This module is the stable search/JNI entry point and makes
//! the four boss-floor boundaries explicit.

use std::fmt;

use crate::batch::seed_for_depth_batch4;
use crate::caves_floor::{CanonicalCavesWorldGenerator, CavesFloorError, generate_caves_world};
use crate::challenges::Challenges;
use crate::city_boss_shop::generate_city_boss_shop;
use crate::city_floor::{CanonicalCityWorldGenerator, CityFloorError, generate_city_world};
use crate::halls_floor::{CanonicalHallsWorldGenerator, HallsFloorError, generate_halls_world};
use crate::level_prelude::LimitedDrops;
use crate::model::{FloorFeeling, GeneratedWorld};
use crate::prison_floor::{CanonicalPrisonWorldGenerator, PrisonFloorError, generate_prison_world};
use crate::quests::QuestState;
use crate::rng::{RandomStack, seed_for_depth};
use crate::run::RunState;
use crate::search::{FloorGate, WorldGenerator};
use crate::seed::DungeonSeed;
use crate::sewer_floor::{
    CanonicalSewerWorldGenerator, SewerFloorError, generate_sewer_world, remap_floor_choice_groups,
};
use crate::shop::ShopRunState;

/// Exact version-pinned generator used by production search sessions.
#[derive(Clone, Copy, Debug, Default)]
pub struct CanonicalMainWorldGenerator;

impl CanonicalMainWorldGenerator {
    /// Builds a production generator for one validated challenge mask.
    #[must_use]
    pub const fn with_challenges(challenges: Challenges) -> ConfiguredMainWorldGenerator {
        ConfiguredMainWorldGenerator { challenges }
    }
}

/// Canonical main-dungeon generator configured for one challenge mask.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ConfiguredMainWorldGenerator {
    challenges: Challenges,
}

impl WorldGenerator for ConfiguredMainWorldGenerator {
    fn generate(&self, seed: DungeonSeed, max_depth: u8) -> GeneratedWorld {
        generate_main_world_with_challenges(seed, max_depth, self.challenges)
            .expect("ConfiguredMainWorldGenerator accepts depths 1..=24")
    }

    fn generate_batch(&self, seeds: &[DungeonSeed], max_depth: u8) -> Vec<GeneratedWorld> {
        if self.challenges == Challenges::NONE {
            return CanonicalMainWorldGenerator.generate_batch(seeds, max_depth);
        }
        seeds
            .iter()
            .copied()
            .map(|seed| self.generate(seed, max_depth))
            .collect()
    }

    fn generate_batch_gated(
        &self,
        seeds: &[DungeonSeed],
        max_depth: u8,
        gate: &dyn FloorGate,
    ) -> Vec<Option<GeneratedWorld>> {
        if self.challenges == Challenges::NONE {
            return CanonicalMainWorldGenerator.generate_batch_gated(seeds, max_depth, gate);
        }
        seeds
            .iter()
            .copied()
            .map(|seed| {
                generate_main_world_gated_with_challenges(seed, max_depth, self.challenges, gate)
                    .expect("validated gated batch satisfies canonical invariants")
            })
            .collect()
    }
}

impl WorldGenerator for CanonicalMainWorldGenerator {
    fn generate(&self, seed: DungeonSeed, max_depth: u8) -> GeneratedWorld {
        generate_main_world(seed, max_depth)
            .expect("CanonicalMainWorldGenerator accepts depths 1..=24")
    }

    fn generate_batch(&self, seeds: &[DungeonSeed], max_depth: u8) -> Vec<GeneratedWorld> {
        assert!(
            (1..=24).contains(&max_depth),
            "CanonicalMainWorldGenerator accepts depths 1..=24"
        );
        match max_depth {
            1..=4 => CanonicalSewerWorldGenerator.generate_batch(seeds, max_depth),
            5 => CanonicalSewerWorldGenerator.generate_batch(seeds, 4),
            6..=9 => CanonicalPrisonWorldGenerator.generate_batch(seeds, max_depth),
            10 => CanonicalPrisonWorldGenerator.generate_batch(seeds, 9),
            11..=14 => CanonicalCavesWorldGenerator.generate_batch(seeds, max_depth),
            15 => CanonicalCavesWorldGenerator.generate_batch(seeds, 14),
            16..=19 => CanonicalCityWorldGenerator.generate_batch(seeds, max_depth),
            20 => {
                let mut worlds = CanonicalHallsWorldGenerator.generate_batch(seeds, 21);
                for world in &mut worlds {
                    world.items.retain(|item| item.depth <= 20);
                    world.feelings.retain(|floor| floor.depth <= 20);
                    world.floor_rooms.retain(|floor| floor.depth <= 20);
                    world.artifact_decks.retain(|floor| floor.depth <= 20);
                }
                worlds
            }
            21..=24 => CanonicalHallsWorldGenerator.generate_batch(seeds, max_depth),
            _ => unreachable!("depth was validated above"),
        }
    }

    fn generate_batch_gated(
        &self,
        seeds: &[DungeonSeed],
        max_depth: u8,
        gate: &dyn FloorGate,
    ) -> Vec<Option<GeneratedWorld>> {
        assert!(
            (1..=24).contains(&max_depth),
            "CanonicalMainWorldGenerator accepts depths 1..=24"
        );
        let target = effective_regular_depth(max_depth);
        let depths = regular_depths(target).collect::<Vec<_>>();
        let mut output = Vec::with_capacity(seeds.len());
        let mut chunks = seeds.chunks_exact(4);
        for chunk in &mut chunks {
            let dungeon_seeds = std::array::from_fn(|index| {
                i64::try_from(chunk[index].value()).expect("base-26 seed range fits Java long")
            });
            let roots_by_depth = depths
                .iter()
                .map(|&depth| seed_for_depth_batch4(dungeon_seeds, depth, 0))
                .collect::<Vec<_>>();
            for lane in 0..4 {
                let roots = roots_by_depth
                    .iter()
                    .map(|depth_roots| depth_roots[lane])
                    .collect::<Vec<_>>();
                output.push(
                    generate_gated_world_with_roots(
                        chunk[lane],
                        target,
                        &roots,
                        Challenges::NONE,
                        gate,
                    )
                    .expect("validated gated batch satisfies canonical invariants"),
                );
            }
        }
        output.extend(chunks.remainder().iter().copied().map(|seed| {
            generate_main_world_gated(seed, target, gate)
                .expect("validated gated batch satisfies canonical invariants")
        }));
        output
    }
}

/// Generates all searchable static equipment in the canonical main-dungeon
/// prefix through `maximum_depth`.
///
/// Boss floors 5, 10, and 15 contain no searchable initial equipment and are
/// persistent-state neutral in the pinned profile. Depth 20 is different: its
/// Imp shop eagerly generates stock, so the depth-21 Halls prefix is evaluated
/// and then trimmed when callers request exactly depth 20.
///
/// # Errors
///
/// Returns [`MainWorldError::InvalidMaximumDepth`] outside 1..=24, or wraps
/// the exact regional generation failure.
pub fn generate_main_world(
    seed: DungeonSeed,
    maximum_depth: u8,
) -> Result<GeneratedWorld, MainWorldError> {
    match maximum_depth {
        1..=4 => generate_sewer_world(seed, maximum_depth).map_err(MainWorldError::Sewer),
        5 => generate_sewer_world(seed, 4).map_err(MainWorldError::Sewer),
        6..=9 => generate_prison_world(seed, maximum_depth).map_err(MainWorldError::Prison),
        10 => generate_prison_world(seed, 9).map_err(MainWorldError::Prison),
        11..=14 => generate_caves_world(seed, maximum_depth).map_err(MainWorldError::Caves),
        15 => generate_caves_world(seed, 14).map_err(MainWorldError::Caves),
        16..=19 => generate_city_world(seed, maximum_depth).map_err(MainWorldError::City),
        20 => {
            let mut world = generate_halls_world(seed, 21).map_err(MainWorldError::Halls)?;
            world.items.retain(|item| item.depth <= 20);
            world.feelings.retain(|floor| floor.depth <= 20);
            world.floor_rooms.retain(|floor| floor.depth <= 20);
            world.artifact_decks.retain(|floor| floor.depth <= 20);
            Ok(world)
        }
        21..=24 => generate_halls_world(seed, maximum_depth).map_err(MainWorldError::Halls),
        _ => Err(MainWorldError::InvalidMaximumDepth(maximum_depth)),
    }
}

/// Challenge-aware form of [`generate_main_world`].
///
/// # Errors
///
/// Returns [`MainWorldError`] when `maximum_depth` is outside `1..=24` or a
/// regional generator rejects its inputs.
///
/// # Panics
///
/// Panics only if the ungated generation pipeline abandons a world, which the
/// open gate makes unreachable.
pub fn generate_main_world_with_challenges(
    seed: DungeonSeed,
    maximum_depth: u8,
    challenges: Challenges,
) -> Result<GeneratedWorld, MainWorldError> {
    struct OpenGate;
    impl FloorGate for OpenGate {
        fn continue_after_floor(
            &self,
            _completed_depth: u8,
            _items: &[crate::model::WorldItem],
            _quests: &crate::quests::QuestSummary,
        ) -> bool {
            true
        }
    }
    generate_main_world_gated_with_challenges(seed, maximum_depth, challenges, &OpenGate)
        .map(|world| world.expect("open gate never abandons a world"))
}

/// Generate with a chosen initial offer at +3, activated after the first brewing opportunity.
/// The caller validates the identity against the seed's initial offers.
///
/// # Panics
/// Panics if the internal open gate unexpectedly abandons generation.
///
/// # Errors
/// Returns the same depth and generation errors as `generate_main_world`.
pub fn generate_main_world_with_trinket(
    seed: DungeonSeed,
    maximum_depth: u8,
    challenges: Challenges,
    selected: Option<crate::catalog::ItemId>,
) -> Result<GeneratedWorld, MainWorldError> {
    struct OpenGate(Option<crate::catalog::ItemId>);
    impl FloorGate for OpenGate {
        fn selected_trinket(&self, _: DungeonSeed) -> Option<crate::catalog::ItemId> {
            self.0
        }
        fn continue_after_floor(
            &self,
            _: u8,
            _: &[crate::model::WorldItem],
            _: &crate::quests::QuestSummary,
        ) -> bool {
            true
        }
    }
    generate_main_world_gated_with_challenges(seed, maximum_depth, challenges, &OpenGate(selected))
        .map(|world| world.expect("open gate never abandons a world"))
}

/// Regular (non-boss) depths generated for a prefix through `target`.
/// Depth 20 is included from 20 onward because its Imp shop eagerly draws
/// stock which the searchable model exposes as depth-20 items.
fn regular_depths(target: u8) -> impl Iterator<Item = u32> {
    (1..=u32::from(target)).filter(|&depth| !matches!(depth, 5 | 10 | 15))
}

/// The boss floors that generate no searchable items, so a floor limit set to
/// one of them describes exactly the same world as the floor above it. Floor
/// 20 is *not* one of them: its Imp shop eagerly draws stock, which the
/// searchable model exposes as depth-20 items.
pub const EMPTY_BOSS_FLOORS: [u8; 3] = [5, 10, 15];

/// Snaps a floor limit on an empty boss floor to the equivalent floor above
/// it (5→4, 10→9, 15→14) and leaves every other limit alone. Frontends use
/// this to keep their floor-limit controls off floors that mean nothing;
/// generation applies the identical mapping internally.
#[must_use]
pub const fn normalize_floor_limit(limit: u8) -> u8 {
    let mut index = 0;
    while index < EMPTY_BOSS_FLOORS.len() {
        if EMPTY_BOSS_FLOORS[index] == limit {
            return limit - 1;
        }
        index += 1;
    }
    limit
}

/// Maps a requested depth onto the deepest state-mutating floor at or above
/// it: boss floors 5/10/15 are persistent-state neutral in the pinned profile.
const fn effective_regular_depth(maximum_depth: u8) -> u8 {
    match maximum_depth {
        5 => 4,
        10 => 9,
        15 => 14,
        other => other,
    }
}

/// Gated variant of [`generate_main_world`]: after each completed floor the
/// gate may prove the partial world unable to match, abandoning the seed's
/// remaining floors. Returns `Ok(None)` for abandoned seeds.
///
/// # Errors
///
/// Returns [`MainWorldError::InvalidMaximumDepth`] outside 1..=24, or wraps
/// the exact regional generation failure.
///
/// # Panics
///
/// Panics only if a representable seed exceeds Java's `long` range, which the
/// [`DungeonSeed`] type rules out.
pub fn generate_main_world_gated(
    seed: DungeonSeed,
    maximum_depth: u8,
    gate: &dyn FloorGate,
) -> Result<Option<GeneratedWorld>, MainWorldError> {
    if !(1..=24).contains(&maximum_depth) {
        return Err(MainWorldError::InvalidMaximumDepth(maximum_depth));
    }
    let target = effective_regular_depth(maximum_depth);
    let dungeon_seed = i64::try_from(seed.value()).expect("base-26 seed range fits Java long");
    let roots = regular_depths(target)
        .map(|depth| seed_for_depth(dungeon_seed, depth, 0))
        .collect::<Vec<_>>();
    generate_gated_world_with_roots(seed, target, &roots, Challenges::NONE, gate)
}

fn generate_main_world_gated_with_challenges(
    seed: DungeonSeed,
    maximum_depth: u8,
    challenges: Challenges,
    gate: &dyn FloorGate,
) -> Result<Option<GeneratedWorld>, MainWorldError> {
    if !(1..=24).contains(&maximum_depth) {
        return Err(MainWorldError::InvalidMaximumDepth(maximum_depth));
    }
    let target = effective_regular_depth(maximum_depth);
    let dungeon_seed = i64::try_from(seed.value()).expect("base-26 seed range fits Java long");
    let roots = regular_depths(target)
        .map(|depth| seed_for_depth(dungeon_seed, depth, 0))
        .collect::<Vec<_>>();
    generate_gated_world_with_roots(seed, target, &roots, challenges, gate)
}

pub(crate) struct FloorObservation<'a> {
    pub level: &'a crate::level::Level,
    pub contents: crate::level_map::contents::FloorSource<'a>,
    pub rooms: &'a [crate::room::Room],
    pub quests: crate::quests::QuestSummary,
    pub imp_rewards: &'a [crate::quests::ImpRewardOption],
    pub trinket: &'a crate::trinkets::TrinketEffects,
    pub vault: Option<&'a crate::vault_floor::GeneratedVault>,
}

/// Captures completed regular floors without changing generation or retaining
/// maps in search results. The observer is called after mob/item terrain edits.
pub(crate) fn generate_main_world_observed(
    seed: DungeonSeed,
    maximum_depth: u8,
    challenges: Challenges,
    gate: &dyn FloorGate,
    observer: &mut impl FnMut(FloorObservation<'_>),
) -> Result<Option<GeneratedWorld>, MainWorldError> {
    if !(1..=24).contains(&maximum_depth) {
        return Err(MainWorldError::InvalidMaximumDepth(maximum_depth));
    }
    let target = effective_regular_depth(maximum_depth);
    let dungeon_seed = i64::try_from(seed.value()).expect("base-26 seed range fits Java long");
    let roots = regular_depths(target)
        .map(|depth| seed_for_depth(dungeon_seed, depth, 0))
        .collect::<Vec<_>>();
    // Map observers need the vault alongside its parent floor, so replay eagerly.
    generate_gated_world_attempt(seed, target, &roots, challenges, gate, None, true, observer)
}

/// Sequential gated composite over the canonical per-region floor generators.
/// `target` must already be boss-mapped (never 5, 10, or 15).
#[allow(clippy::too_many_lines)]
fn generate_gated_world_with_roots(
    seed: DungeonSeed,
    target: u8,
    roots: &[i64],
    challenges: Challenges,
    gate: &dyn FloorGate,
) -> Result<Option<GeneratedWorld>, MainWorldError> {
    let deferred = gate.deferred_vault_plan(target);
    let result = generate_gated_world_attempt(
        seed,
        target,
        roots,
        challenges,
        gate,
        deferred,
        false,
        &mut |_| {},
    );
    if deferred.is_some() && result.is_err() {
        // Delaying a vault can change which regional error is encountered
        // first. Discard the entire attempt and reproduce the eager result.
        return generate_gated_world_attempt(
            seed,
            target,
            roots,
            challenges,
            gate,
            None,
            false,
            &mut |_| {},
        );
    }
    result
}

struct PendingVault {
    depth: u8,
    trinket: crate::trinkets::TrinketEffects,
    insertion_index: usize,
    global_group: u16,
}

#[allow(clippy::too_many_lines, clippy::too_many_arguments)]
fn generate_gated_world_attempt(
    seed: DungeonSeed,
    target: u8,
    roots: &[i64],
    challenges: Challenges,
    gate: &dyn FloorGate,
    deferred: Option<&crate::feasibility::QueryPlan>,
    acquire_hourglass: bool,
    observer: &mut impl FnMut(FloorObservation<'_>),
) -> Result<Option<GeneratedWorld>, MainWorldError> {
    let dungeon_seed = i64::try_from(seed.value()).expect("base-26 seed range fits Java long");
    let mut pending_vault = None;
    let mut run = RunState::with_challenges(dungeon_seed, challenges);
    run.generate_vault = gate.wants_vault_treasure();
    if !gate.continue_after_run_init(&run) {
        return Ok(None);
    }
    let mut limited_drops = LimitedDrops::default();
    let mut quests = QuestState::new();
    let mut shop_run = ShopRunState::default();
    let mut random = RandomStack::with_base_seed(0);
    random.record_room_order = acquire_hourglass;
    let mut items = Vec::new();
    let mut feelings = Vec::new();
    let mut floor_rooms = Vec::new();
    let mut artifact_decks = vec![crate::artifacts::ArtifactDeck::capture(0, &run.generator)];
    let mut next_choice_group = 0_u16;
    let selected_trinket = gate.selected_trinket(seed);
    let mut alchemy_available = false;

    for (&root, depth) in roots.iter().zip(regular_depths(target)) {
        random.push(root);
        let completed = u8::try_from(depth).expect("main-path depths fit u8");
        let (mut floor_items, feeling) = match depth {
            1..=4 => {
                let Some(floor) = crate::sewer_floor::generate_sewer_floor_filtered(
                    &mut run,
                    &mut limited_drops,
                    &mut quests,
                    depth,
                    &mut random,
                    gate.floor_requirement(completed),
                )
                .map_err(MainWorldError::Sewer)?
                else {
                    return Ok(None);
                };
                alchemy_available |= floor
                    .painted
                    .level
                    .map
                    .cells
                    .contains(&crate::geometry::terrain::ALCHEMY);
                floor_rooms.push(crate::floor_filters::FloorRooms {
                    depth: completed,
                    rooms: crate::floor_filters::RoomSet::from_rooms(&floor.painted.rooms),
                });
                observer(FloorObservation {
                    contents: crate::level_map::contents::FloorSource::Sewer(&floor),
                    level: &floor.painted.level,
                    rooms: &floor.painted.rooms,
                    quests: quests.summary(),
                    imp_rewards: &quests.imp.reward_options,
                    trinket: &random.trinket,
                    vault: None,
                });
                (floor.world_items, Some(floor.painted.level.feeling))
            }
            6..=9 => {
                let Some(floor) = crate::prison_floor::generate_prison_floor_filtered(
                    &mut run,
                    &mut limited_drops,
                    &mut quests,
                    &mut shop_run,
                    depth,
                    &mut random,
                    gate.floor_requirement(completed),
                )
                .map_err(MainWorldError::Prison)?
                else {
                    return Ok(None);
                };
                floor_rooms.push(crate::floor_filters::FloorRooms {
                    depth: completed,
                    rooms: crate::floor_filters::RoomSet::from_rooms(&floor.painted.rooms),
                });
                observer(FloorObservation {
                    contents: crate::level_map::contents::FloorSource::Prison(&floor),
                    level: &floor.painted.level,
                    rooms: &floor.painted.rooms,
                    quests: quests.summary(),
                    imp_rewards: &quests.imp.reward_options,
                    trinket: &random.trinket,
                    vault: None,
                });
                (floor.world_items, Some(floor.painted.level.feeling))
            }
            11..=14 => {
                let Some(floor) = crate::caves_floor::generate_caves_floor_filtered(
                    &mut run,
                    &mut limited_drops,
                    &mut quests,
                    &mut shop_run,
                    depth,
                    &mut random,
                    gate.floor_requirement(completed),
                )
                .map_err(MainWorldError::Caves)?
                else {
                    return Ok(None);
                };
                floor_rooms.push(crate::floor_filters::FloorRooms {
                    depth: completed,
                    rooms: crate::floor_filters::RoomSet::from_rooms(&floor.painted.rooms),
                });
                observer(FloorObservation {
                    contents: crate::level_map::contents::FloorSource::Caves(&floor),
                    level: &floor.painted.level,
                    rooms: &floor.painted.rooms,
                    quests: quests.summary(),
                    imp_rewards: &quests.imp.reward_options,
                    trinket: &random.trinket,
                    vault: None,
                });
                (floor.world_items, Some(floor.painted.level.feeling))
            }
            16..=19 => {
                let wanted_vault = run.generate_vault;
                if deferred.is_some() {
                    run.generate_vault = false;
                }
                let floor = crate::city_floor::generate_city_floor_filtered(
                    &mut run,
                    &mut limited_drops,
                    &mut quests,
                    &mut shop_run,
                    depth,
                    &mut random,
                    gate.floor_requirement(completed),
                );
                run.generate_vault = wanted_vault;
                let Some(floor) = floor.map_err(MainWorldError::City)? else {
                    return Ok(None);
                };
                if deferred.is_some()
                    && wanted_vault
                    && quests.imp.depth == Some(completed)
                    && quests.imp.room_accessible
                {
                    debug_assert!(pending_vault.is_none());
                    // City appends regular items after Imp options and vault
                    // treasure. The Imp's ring keeps its group represented,
                    // so omitting treasure leaves all later group offsets intact.
                    pending_vault = Some(PendingVault {
                        depth: completed,
                        trinket: random.trinket.clone(),
                        insertion_index: items.len() + floor.world_items.len()
                            - floor.regular_items.world_items.len(),
                        global_group: floor
                            .painted
                            .remaining_prizes
                            .next_choice_group
                            .checked_add(next_choice_group)
                            .expect("canonical world choice groups fit u16"),
                    });
                    #[cfg(test)]
                    deferred_vault_tests::fault(1)?;
                }
                floor_rooms.push(crate::floor_filters::FloorRooms {
                    depth: completed,
                    rooms: crate::floor_filters::RoomSet::from_rooms(&floor.painted.rooms),
                });
                observer(FloorObservation {
                    contents: crate::level_map::contents::FloorSource::City(&floor),
                    level: &floor.painted.level,
                    rooms: &floor.painted.rooms,
                    quests: quests.summary(),
                    imp_rewards: &quests.imp.reward_options,
                    trinket: &random.trinket,
                    vault: floor.vault.as_ref(),
                });
                (floor.world_items, Some(floor.painted.level.feeling))
            }
            20 => (
                generate_city_boss_shop(&mut run, &mut shop_run, &mut random)
                    .map_err(|error| MainWorldError::Halls(HallsFloorError::BossShop(error)))?
                    .world_items,
                None,
            ),
            _ => {
                let Some(floor) = crate::halls_floor::generate_halls_floor_filtered(
                    &mut run,
                    &mut limited_drops,
                    &mut quests,
                    &mut shop_run,
                    depth,
                    &mut random,
                    gate.floor_requirement(completed),
                )
                .map_err(MainWorldError::Halls)?
                else {
                    return Ok(None);
                };
                floor_rooms.push(crate::floor_filters::FloorRooms {
                    depth: completed,
                    rooms: crate::floor_filters::RoomSet::from_rooms(&floor.painted.rooms),
                });
                observer(FloorObservation {
                    contents: crate::level_map::contents::FloorSource::Halls(&floor),
                    level: &floor.painted.level,
                    rooms: &floor.painted.rooms,
                    quests: quests.summary(),
                    imp_rewards: &quests.imp.reward_options,
                    trinket: &random.trinket,
                    vault: None,
                });
                (floor.world_items, Some(floor.painted.level.feeling))
            }
        };
        // Map pickup profile: take an obtainable earlier-floor hourglass,
        // identify and uncurse it. Stock already constructed on this floor is
        // unchanged; subsequent shops carry sand using the existing bag rules.
        if acquire_hourglass
            && floor_items
                .iter()
                .any(|item| item.item == crate::catalog::ItemId::TimekeepersHourglass)
            && matches!(
                shop_run.hourglass,
                crate::shop::ShopHourglassState::Ineligible
            )
        {
            shop_run.hourglass = crate::shop::ShopHourglassState::Eligible { sand_bags: 0 };
        }
        if let Some(feeling) = feeling {
            feelings.push(FloorFeeling {
                depth: completed,
                feeling,
            });
        }
        #[cfg(test)]
        deferred_vault_tests::record_state(
            completed,
            &run,
            &limited_drops,
            &quests,
            &shop_run,
            &random,
        );
        random.pop();
        if random.trinket.selected.is_none()
            && alchemy_available
            && limited_drops.trinket_catalyst_dropped
        {
            random.trinket = crate::trinkets::TrinketEffects::new(selected_trinket, dungeon_seed);
        }
        next_choice_group = remap_floor_choice_groups(&mut floor_items, next_choice_group);
        artifact_decks.push(crate::artifacts::ArtifactDeck::capture(
            completed,
            &run.generator,
        ));
        items.extend(floor_items);
        if completed < target && !gate.continue_after_floor(completed, &items, &quests.summary()) {
            return Ok(None);
        }
    }
    if let Some(pending) = pending_vault {
        let plan = deferred.expect("only opted-in gates defer vaults");
        if !plan.viable_with_pending_vault(target, &items, quests.summary(), Some(pending.depth)) {
            return Ok(None);
        }
        #[cfg(test)]
        deferred_vault_tests::fault(2)?;
        let vault = crate::vault_floor::generate_vault_with_trinket(
            dungeon_seed,
            pending.depth,
            challenges,
            &pending.trinket,
            false,
        )
        .map_err(|error| MainWorldError::City(CityFloorError::Vault(error)))?;
        let treasure = vault.world_items(
            pending.depth,
            pending.global_group,
            crate::city_floor::VAULT_FIRST_OPTION,
        );
        items.splice(pending.insertion_index..pending.insertion_index, treasure);
    }
    Ok(Some(GeneratedWorld {
        seed,
        items,
        floor_rooms,
        artifact_decks,
        feelings,
        quests: quests.summary(),
        ring_gems: run.appearances.ring_gems,
    }))
}

/// Failure while producing a canonical main-dungeon prefix.
#[derive(Clone, Debug, PartialEq)]
pub enum MainWorldError {
    InvalidMaximumDepth(u8),
    Sewer(SewerFloorError),
    Prison(PrisonFloorError),
    Caves(CavesFloorError),
    City(CityFloorError),
    Halls(HallsFloorError),
}

impl fmt::Display for MainWorldError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidMaximumDepth(depth) => {
                write!(formatter, "main-world depth must be in 1..=24, got {depth}")
            }
            Self::Sewer(error) => error.fmt(formatter),
            Self::Prison(error) => error.fmt(formatter),
            Self::Caves(error) => error.fmt(formatter),
            Self::City(error) => error.fmt(formatter),
            Self::Halls(error) => error.fmt(formatter),
        }
    }
}

impl std::error::Error for MainWorldError {}

#[cfg(test)]
mod tests {
    use crate::catalog::{ItemId, ItemKind};
    use crate::feasibility::QueryPlan;
    use crate::model::{ItemSource, WorldItem};
    use crate::query::{
        EffectRequirement, Requirement, SearchQuery, TierRequirement, UpgradeRequirement,
    };
    use crate::search::{FloorGate, WorldGenerator};
    use crate::seed::DungeonSeed;

    use super::{
        CanonicalMainWorldGenerator, MainWorldError, generate_main_world, generate_main_world_gated,
    };

    struct OpenGate;

    impl FloorGate for OpenGate {
        fn continue_after_floor(
            &self,
            _depth: u8,
            _items: &[WorldItem],
            _quests: &crate::quests::QuestSummary,
        ) -> bool {
            true
        }
    }

    #[test]
    fn gated_generation_with_an_open_gate_matches_ungated_generation() {
        for depth in [1, 4, 5, 9, 12, 15, 17, 20, 24] {
            for seed_value in [0_u64, 5, 26, 4_093] {
                let seed = DungeonSeed::new(seed_value).unwrap();
                assert_eq!(
                    generate_main_world_gated(seed, depth, &OpenGate)
                        .unwrap()
                        .expect("an open gate never abandons a seed"),
                    generate_main_world(seed, depth).unwrap(),
                    "depth {depth} seed {seed_value}"
                );
            }
        }
    }

    #[test]
    fn feelings_match_across_prefix_scalar_batch_and_gated_generation() {
        let seeds = [0, 5, 26, 66, 4_093].map(|value| DungeonSeed::new(value).unwrap());
        let complete = CanonicalMainWorldGenerator.generate_batch(&seeds, 24);
        for depth in [1, 4, 5, 9, 10, 14, 15, 19, 20, 21, 24] {
            let batched = CanonicalMainWorldGenerator.generate_batch(&seeds, depth);
            let gated = CanonicalMainWorldGenerator.generate_batch_gated(&seeds, depth, &OpenGate);
            for (index, &seed) in seeds.iter().enumerate() {
                let scalar = generate_main_world(seed, depth).unwrap();
                let expected = complete[index]
                    .feelings
                    .iter()
                    .copied()
                    .filter(|floor| floor.depth <= depth)
                    .collect::<Vec<_>>();
                assert_eq!(scalar.feelings, expected, "seed {seed}, depth {depth}");
                assert_eq!(scalar, batched[index]);
                assert_eq!(Some(&scalar), gated[index].as_ref());
                assert!(scalar.feelings.iter().all(|floor| floor.depth % 5 != 0));
            }
        }
        assert_eq!(complete[0].feelings.len(), 20);
        assert_eq!(
            complete[0].feelings[0].feeling,
            crate::level_prelude::Feeling::None
        );
    }

    #[test]
    fn challenge_feelings_match_scalar_batch_gated_and_truncated_worlds() {
        let configured = CanonicalMainWorldGenerator::with_challenges(
            crate::challenges::Challenges::LEVEL_GENERATION,
        );
        let seeds = [DungeonSeed::MIN, DungeonSeed::new(66).unwrap()];
        let full = configured.generate_batch(&seeds, 24);
        for depth in [4, 9, 14, 19, 20, 24] {
            let batched = configured.generate_batch(&seeds, depth);
            let gated = configured.generate_batch_gated(&seeds, depth, &OpenGate);
            for (index, &seed) in seeds.iter().enumerate() {
                let scalar = configured.generate(seed, depth);
                assert_eq!(scalar, batched[index]);
                assert_eq!(Some(&scalar), gated[index].as_ref());
                assert_eq!(
                    scalar.feelings,
                    full[index]
                        .feelings
                        .iter()
                        .copied()
                        .filter(|floor| floor.depth <= depth)
                        .collect::<Vec<_>>()
                );
            }
        }
    }

    #[test]
    fn gated_search_agrees_with_brute_force_matching() {
        let wildcard = |kind, upgrade| Requirement {
            kind,
            weapon_category: None,
            item: None,
            tier: TierRequirement::Any,
            upgrade,
            effect: EffectRequirement::Any,
            require_uncursed: false,
            select_trinket: false,
            trinket_transmutations: 0,
            artifact_transmutations: 0,
            blanket: false,
            exclude_resin: false,
            source: None,
            identity_group: None,
            max_depth: None,
            alternative_group: None,
            level_sum: None,
        };
        let query = |requirements: Vec<Requirement>| SearchQuery {
            floor_requirements: Vec::new(),
            auto_apply_trinket: false,
            arcane_resin_filter: crate::query::ArcaneResinFilter::default(),
            arcane_resin_auto: false,
            arcane_resin: 0,
            requirements,
            max_depth: 24,
            challenges: crate::challenges::Challenges::NONE,
            require_blacksmith: false,
            exclude_blacksmith_rewards: false,
            wandmaker_quest: None,
        };
        let queries = [
            // Imp-only: exercises depth-19 truncation and post-quest aborts.
            query(vec![wildcard(ItemKind::Ring, UpgradeRequirement::Exact(4))]),
            // Wandmaker-only: exercises the depth-9 deadline.
            query(vec![wildcard(ItemKind::Wand, UpgradeRequirement::Exact(3))]),
            // Ghost/Blacksmith/Crypt/Sacrifice interplay, exact semantics.
            query(vec![
                wildcard(ItemKind::Weapon, UpgradeRequirement::Exact(3)),
                wildcard(ItemKind::Armor, UpgradeRequirement::Exact(3)),
            ]),
            // Mixed rare + ordinary requirement keeps full depth.
            query(vec![
                wildcard(ItemKind::Ring, UpgradeRequirement::AtLeast(3)),
                wildcard(ItemKind::Wand, UpgradeRequirement::AtLeast(1)),
            ]),
        ];
        let seeds = (0..32)
            .map(|value| DungeonSeed::new(value).unwrap())
            .collect::<Vec<_>>();
        let full_worlds = seeds
            .iter()
            .map(|&seed| generate_main_world(seed, 24).unwrap())
            .collect::<Vec<_>>();

        let mut total_matches = 0;
        for query in &queries {
            let plan = QueryPlan::analyze(query);
            assert!(!plan.is_unsatisfiable());
            let gated = CanonicalMainWorldGenerator.generate_batch_gated(
                &seeds,
                plan.generation_depth(),
                &plan,
            );
            for (index, gated_world) in gated.iter().enumerate() {
                let expected = query.matches(&full_worlds[index]);
                let actual = gated_world
                    .as_ref()
                    .is_some_and(|world| query.matches(world));
                assert_eq!(
                    actual, expected,
                    "seed {} disagreed for {query:?}",
                    seeds[index]
                );
                total_matches += usize::from(expected);
            }
        }
        // Seed AAA-AAA-AAF carries a +4 Imp ring, so the comparison is not
        // vacuously passing on all-negative outcomes.
        assert!(total_matches > 0);
    }

    /// The three Wandmaker quests partition the seed space: every run reaching
    /// floor nine has exactly one, so filtering by each variant in turn must
    /// reproduce the unfiltered results without overlap. This is what proves
    /// the gate's early rejection agrees with the matcher.
    #[test]
    fn wandmaker_quest_filters_partition_the_unfiltered_results() {
        use crate::quests::WandmakerQuestType;

        let base = SearchQuery {
            floor_requirements: Vec::new(),
            auto_apply_trinket: false,
            arcane_resin_filter: crate::query::ArcaneResinFilter::default(),
            arcane_resin_auto: false,
            arcane_resin: 0,
            requirements: vec![Requirement {
                kind: ItemKind::Wand,
                weapon_category: None,
                item: None,
                tier: TierRequirement::Any,
                upgrade: UpgradeRequirement::AtLeast(1),
                effect: EffectRequirement::Any,
                require_uncursed: false,
                select_trinket: false,
                trinket_transmutations: 0,
                artifact_transmutations: 0,
                blanket: false,
                exclude_resin: false,
                source: None,
                identity_group: None,
                max_depth: None,
                alternative_group: None,
                level_sum: None,
            }],
            max_depth: 24,
            challenges: crate::challenges::Challenges::NONE,
            require_blacksmith: false,
            exclude_blacksmith_rewards: false,
            wandmaker_quest: None,
        };
        let seeds = (0..48)
            .map(|value| DungeonSeed::new(value).unwrap())
            .collect::<Vec<_>>();
        let matching = |query: &SearchQuery| {
            let plan = QueryPlan::analyze(query);
            CanonicalMainWorldGenerator
                .generate_batch_gated(&seeds, plan.generation_depth(), &plan)
                .into_iter()
                .flatten()
                .filter(|world| query.matches(world))
                .map(|world| world.seed)
                .collect::<Vec<_>>()
        };

        let unfiltered = matching(&base);
        assert!(!unfiltered.is_empty());
        let mut partitioned = WandmakerQuestType::ALL
            .into_iter()
            .flat_map(|variant| {
                matching(&SearchQuery {
                    wandmaker_quest: Some(variant),
                    ..base.clone()
                })
            })
            .collect::<Vec<_>>();
        // No seed may land in two variants, and none may go missing.
        let found = partitioned.len();
        partitioned.sort_unstable();
        partitioned.dedup();
        assert_eq!(partitioned.len(), found);
        assert_eq!(partitioned, unfiltered);

        // Seed AAA-AAA-AAA's Wandmaker rolls elemental embers on floor nine.
        let canonical = generate_main_world(DungeonSeed::MIN, 9).unwrap();
        assert_eq!(
            canonical.quests.wandmaker.map(|quest| quest.variant),
            Some(WandmakerQuestType::ElementalEmbers)
        );
    }

    /// Seed AAA-AAA-ACO (66) holds a +3 throwing hammer in a depth-24
    /// special-room chest. A thrown +3 plan must not treat +3 as quest-only,
    /// or this seed would be silently skipped.
    #[test]
    fn plus_three_thrown_seed_survives_the_gate() {
        use crate::catalog::WeaponCategory;

        let query = SearchQuery {
            floor_requirements: Vec::new(),
            auto_apply_trinket: false,
            arcane_resin_filter: crate::query::ArcaneResinFilter::default(),
            arcane_resin_auto: false,
            arcane_resin: 0,
            requirements: vec![Requirement {
                kind: ItemKind::Weapon,
                weapon_category: Some(WeaponCategory::Thrown),
                item: None,
                tier: TierRequirement::Any,
                upgrade: UpgradeRequirement::Exact(3),
                effect: EffectRequirement::Any,
                require_uncursed: false,
                select_trinket: false,
                trinket_transmutations: 0,
                artifact_transmutations: 0,
                blanket: false,
                exclude_resin: false,
                source: None,
                identity_group: None,
                max_depth: None,
                alternative_group: None,
                level_sum: None,
            }],
            max_depth: 24,
            challenges: crate::challenges::Challenges::NONE,
            require_blacksmith: false,
            exclude_blacksmith_rewards: false,
            wandmaker_quest: None,
        };
        let plan = QueryPlan::analyze(&query);
        assert!(!plan.is_unsatisfiable());
        // ABC-DEF-GHI offers a +3 Force Cube among its depth-18 Imp rewards.
        let seed = DungeonSeed::from_code("ABC-DEF-GHI").unwrap();
        let world = generate_main_world(seed, 24).unwrap();
        assert!(query.matches(&world), "the oracle seed lost its match");
        let gated = CanonicalMainWorldGenerator.generate_batch_gated(
            &[seed],
            plan.generation_depth(),
            &plan,
        );
        assert!(
            gated[0].as_ref().is_some_and(|world| query.matches(world)),
            "the gate abandoned a genuinely matching seed"
        );
    }

    #[test]
    fn rejects_depths_outside_the_main_searchable_dungeon() {
        let seed = DungeonSeed::MIN;
        assert_eq!(
            generate_main_world(seed, 0),
            Err(MainWorldError::InvalidMaximumDepth(0))
        );
        assert_eq!(
            generate_main_world(seed, 25),
            Err(MainWorldError::InvalidMaximumDepth(25))
        );
    }

    #[test]
    fn state_neutral_boss_depths_match_their_preceding_regular_prefixes() {
        let seed = DungeonSeed::MIN;
        for (boss, regular) in [(5, 4), (10, 9), (15, 14)] {
            assert_eq!(
                generate_main_world(seed, boss).unwrap(),
                generate_main_world(seed, regular).unwrap()
            );
        }
    }

    #[test]
    fn the_published_floor_limit_mapping_matches_generation() {
        for limit in 1..=24 {
            assert_eq!(
                super::normalize_floor_limit(limit),
                super::effective_regular_depth(limit),
                "floor limit {limit}"
            );
        }
        assert_eq!(super::EMPTY_BOSS_FLOORS, [5, 10, 15]);
        // Depth 20 carries the Imp shop's stock, so it is a real limit.
        assert_eq!(super::normalize_floor_limit(20), 20);
    }

    #[test]
    fn depth_twenty_includes_official_imp_shop_stock_without_halls_items() {
        let world = generate_main_world(DungeonSeed::MIN, 20).unwrap();
        assert!(world.items.iter().all(|item| item.depth <= 20));
        let depth_twenty = world
            .items
            .iter()
            .filter(|item| item.depth == 20)
            .map(|item| item.item)
            .collect::<Vec<_>>();
        assert_eq!(
            depth_twenty,
            vec![
                ItemId::PlateArmor,
                ItemId::ThrowingHammer,
                ItemId::WarHammer,
                ItemId::IncendiaryDart,
            ]
        );
    }

    #[test]
    fn ghost_rewards_are_reported_once_on_the_ghost_floor() {
        let seed = DungeonSeed::from_code("AAA-GPY-IJW").unwrap();
        let world = generate_main_world(seed, 24).unwrap();
        let ghost_rewards = world
            .items
            .iter()
            .filter(|item| item.source == ItemSource::GhostReward)
            .collect::<Vec<_>>();

        assert_eq!(ghost_rewards.len(), 2);
        assert!(ghost_rewards.iter().all(|item| item.depth == 3));
        assert!(matches!(
            (ghost_rewards[0].accessibility, ghost_rewards[1].accessibility),
            (
                crate::model::Accessibility::Choice { group: first, option: 0 },
                crate::model::Accessibility::Choice { group: second, option: 1 },
            ) if first == second
        ));
    }

    #[test]
    fn plus_four_imp_ring_matches_only_its_generated_identity() {
        let seed = DungeonSeed::from_code("AAA-AAA-AAB").unwrap();
        let world = generate_main_world(seed, 24).unwrap();
        let imp_ring = world.items.iter().find(|value| {
            value.item == ItemId::RingElements
                && value.upgrade == 4
                && value.depth == 18
                && !value.cursed
                && value.source == ItemSource::ImpReward
        });
        assert!(imp_ring.is_some());
        let query = SearchQuery {
            floor_requirements: Vec::new(),
            auto_apply_trinket: false,
            arcane_resin_filter: crate::query::ArcaneResinFilter::default(),
            arcane_resin_auto: false,
            arcane_resin: 0,
            requirements: vec![Requirement {
                kind: ItemKind::Ring,
                weapon_category: None,
                item: Some(ItemId::RingElements),
                tier: TierRequirement::Any,
                upgrade: crate::query::UpgradeRequirement::Exact(4),
                effect: EffectRequirement::Any,
                require_uncursed: false,
                select_trinket: false,
                trinket_transmutations: 0,
                artifact_transmutations: 0,
                blanket: false,
                exclude_resin: false,
                source: None,
                identity_group: None,
                max_depth: None,
                alternative_group: None,
                level_sum: None,
            }],
            max_depth: 24,
            challenges: crate::challenges::Challenges::NONE,
            require_blacksmith: false,
            exclude_blacksmith_rewards: false,
            wandmaker_quest: None,
        };
        assert_eq!(query.validate(), Ok(()));
        assert!(query.matches(&world));

        let different_ring_query = SearchQuery {
            requirements: vec![Requirement {
                item: Some(ItemId::RingAccuracy),
                ..query.requirements[0]
            }],
            ..query
        };
        assert!(!different_ring_query.matches(&world));
    }

    #[test]
    fn canonical_depth_twenty_four_batch_matches_scalar_generation() {
        let seeds = [
            DungeonSeed::MIN,
            DungeonSeed::new(1).unwrap(),
            DungeonSeed::new(2).unwrap(),
            DungeonSeed::new(3).unwrap(),
            DungeonSeed::new(26).unwrap(),
            DungeonSeed::from_code("ABC-DEF-GHI").unwrap(),
            DungeonSeed::new(DungeonSeed::MAX.value() - 1).unwrap(),
            DungeonSeed::MAX,
        ];
        let scalar = seeds
            .iter()
            .copied()
            .map(|seed| CanonicalMainWorldGenerator.generate(seed, 24))
            .collect::<Vec<_>>();
        assert_eq!(
            CanonicalMainWorldGenerator.generate_batch(&seeds, 24),
            scalar
        );
    }

    #[test]
    fn explicit_zero_challenge_generator_is_byte_for_byte_compatible() {
        let configured =
            CanonicalMainWorldGenerator::with_challenges(crate::challenges::Challenges::NONE);
        for value in [0, 1, 5, 26, 8_687_205_886] {
            let seed = DungeonSeed::new(value).unwrap();
            let configured_world = configured.generate(seed, 24);
            let legacy_world = generate_main_world(seed, 24).unwrap();
            assert_eq!(
                crate::wire::encode_scout_world(&configured_world).unwrap(),
                crate::wire::encode_scout_world(&legacy_world).unwrap(),
            );
        }
    }
}

#[cfg(test)]
mod deferred_vault_tests {
    use super::*;
    use crate::catalog::ItemId;
    use crate::feasibility::QueryPlan;
    use crate::model::{Accessibility, ItemSource, WorldItem};
    use crate::query::{SearchQuery, scout_matches};
    use crate::quests::QuestSummary;

    struct EagerGate<'a>(&'a dyn FloorGate);
    impl FloorGate for EagerGate<'_> {
        fn continue_after_run_init(&self, run: &RunState) -> bool {
            self.0.continue_after_run_init(run)
        }
        fn selected_trinket(&self, seed: DungeonSeed) -> Option<ItemId> {
            self.0.selected_trinket(seed)
        }
        fn continue_after_floor(
            &self,
            depth: u8,
            items: &[WorldItem],
            quests: &QuestSummary,
        ) -> bool {
            self.0.continue_after_floor(depth, items, quests)
        }
        fn wants_vault_treasure(&self) -> bool {
            self.0.wants_vault_treasure()
        }
    }

    struct EagerGenerator(Challenges);
    impl WorldGenerator for EagerGenerator {
        fn generate(&self, seed: DungeonSeed, depth: u8) -> GeneratedWorld {
            CanonicalMainWorldGenerator::with_challenges(self.0).generate(seed, depth)
        }
        fn generate_batch_gated(
            &self,
            seeds: &[DungeonSeed],
            depth: u8,
            gate: &dyn FloorGate,
        ) -> Vec<Option<GeneratedWorld>> {
            CanonicalMainWorldGenerator::with_challenges(self.0).generate_batch_gated(
                seeds,
                depth,
                &EagerGate(gate),
            )
        }
    }

    fn query(requirements: &str, depth: u8) -> SearchQuery {
        crate::json_query::decode(&format!(
            r#"{{"max_depth":{depth},"auto_apply_trinket":false,"requirements":{requirements}}}"#
        ))
        .unwrap()
    }

    fn values() -> Vec<DungeonSeed> {
        let mut seeds: Vec<_> = (0..20_u64)
            .map(|i| {
                DungeonSeed::new(
                    (812_345_678_901 + i * 3_355_211_884_971) % crate::seed::TOTAL_SEEDS,
                )
                .unwrap()
            })
            .collect();
        seeds.extend(
            [
                0, 1_334_551, 1_334_612, 20_000_688, 20_013_266, 20_013_756, 20_017_872, 20_028_874,
            ]
            .map(|v| DungeonSeed::new(v).unwrap()),
        );
        seeds
    }

    #[test]
    fn deferred_vault_eligibility_preserves_early_pruning_and_optional_members() {
        let eligible = [
            r#"[{"item":"runic_blade","upgrade":2},{"item":"ring_might","upgrade":2}]"#,
            r#"[{"any_of":[{"item":"runic_blade","upgrade":4,"source":"vault_treasure"},{"item":"greatsword","upgrade":2}]},{"item":"ring_might","upgrade":2}]"#,
        ];
        for requirements in eligible {
            for depth in [17, 18, 19, 24] {
                let plan = QueryPlan::analyze(&query(requirements, depth));
                assert!(plan.deferred_vault_plan(depth).is_some());
                assert!(plan.deferred_vault_plan(depth + 1).is_none());
            }
        }
        for requirements in [
            r#"[{"item":"runic_blade","upgrade":4,"source":"vault_treasure"},{"item":"ring_might","upgrade":2}]"#,
            r#"[{"item":"runic_blade","upgrade":2}]"#,
            r#"[{"kind":"ring"}]"#,
        ] {
            let plan = QueryPlan::analyze(&query(requirements, 19));
            assert!(plan.deferred_vault_plan(19).is_none());
        }
        let mut sum = query(eligible[0], 19);
        sum.requirements[1].level_sum = Some(crate::query::LevelSum {
            group: 1,
            minimum_total: 2,
        });
        // A sum group requires multiple members. Both remain optional.
        sum.requirements.push(sum.requirements[1]);
        sum.validate().unwrap();
        assert!(QueryPlan::analyze(&sum).deferred_vault_plan(19).is_none());
    }

    #[test]
    fn deferred_vault_final_gate_respects_depth_caps_and_one_imp_choice() {
        let cases = [
            // The actual depth-18 vault cannot fill the capped alternative.
            (
                r#"[{"any_of":[{"item":"runic_blade","upgrade":4,"source":"vault_treasure","max_depth":17},{"item":"greatsword","upgrade":2}]},{"item":"ring_might","upgrade":2}]"#,
                17,
                true,
            ),
            (
                r#"[{"any_of":[{"item":"runic_blade","upgrade":4,"source":"vault_treasure","max_depth":17},{"item":"greatsword","upgrade":2}]},{"item":"ring_might","upgrade":2}]"#,
                18,
                false,
            ),
            // Both unresolved requirements would need the same Imp choice.
            (
                r#"[{"item":"runic_blade","upgrade":2},{"item":"ring_might","upgrade":2,"source":"imp_reward"}]"#,
                18,
                false,
            ),
        ];
        for (requirements, pending, expected) in cases {
            let plan = QueryPlan::analyze(&query(requirements, 19));
            assert!(plan.deferred_vault_plan(19).is_some());
            let source = if requirements.contains("imp_reward") {
                ItemSource::ImpReward
            } else {
                ItemSource::Heap
            };
            let item = WorldItem {
                item: ItemId::RingMight,
                upgrade: 2,
                effect: None,
                cursed: false,
                depth: pending,
                source,
                accessibility: if source == ItemSource::Heap {
                    Accessibility::Independent
                } else {
                    Accessibility::Choice {
                        group: 7,
                        option: 1,
                    }
                },
                secret: false,
            };
            assert_eq!(
                plan.viable_with_pending_vault(19, &[item], QuestSummary::default(), Some(pending)),
                expected
            );
        }
    }

    #[test]
    #[ignore = "extended seed sweep; run with --release --ignored"]
    fn deferred_vault_full_world_order_matches_eager_with_challenges_and_all_offers() {
        struct ChoiceGate<'a>(&'a QueryPlan, Option<ItemId>);
        impl FloorGate for ChoiceGate<'_> {
            fn deferred_vault_plan(&self, target: u8) -> Option<&QueryPlan> {
                self.0.deferred_vault_plan(target)
            }
            fn continue_after_run_init(&self, run: &RunState) -> bool {
                self.0.continue_after_run_init(run)
            }
            fn selected_trinket(&self, _: DungeonSeed) -> Option<ItemId> {
                self.1
            }
            fn continue_after_floor(
                &self,
                depth: u8,
                items: &[WorldItem],
                quests: &QuestSummary,
            ) -> bool {
                self.0.continue_after_floor(depth, items, quests)
            }
        }
        let mut imp_depths = [false; 3];
        let mut retained = 0;
        let mut feeling_profiles = [false; 2];
        for seed in values().into_iter().take(24) {
            let offers = crate::trinkets::initial_offers(seed);
            for choice in std::iter::once(None).chain(offers.into_iter().map(Some)) {
                feeling_profiles[0] |= choice == Some(ItemId::MossyClump);
                feeling_profiles[1] |= choice == Some(ItemId::TrapMechanism);
                for challenges in [
                    Challenges::NONE,
                    Challenges::DARKNESS,
                    Challenges::LEVEL_GENERATION,
                ] {
                    for depth in [19, 24] {
                        // Every accessible Imp supplies a ring: this deliberately
                        // retains many complete vaults and their item ordering.
                        let query = query(
                            r#"[{"kind":"weapon"},{"kind":"ring","source":"imp_reward"}]"#,
                            depth,
                        );
                        let plan = QueryPlan::analyze(&query);
                        assert!(plan.deferred_vault_plan(depth).is_some());
                        let gate = ChoiceGate(&plan, choice);
                        let expected = generate_main_world_gated_with_challenges(
                            seed,
                            depth,
                            challenges,
                            &EagerGate(&gate),
                        )
                        .unwrap();
                        let actual = generate_main_world_gated_with_challenges(
                            seed, depth, challenges, &gate,
                        )
                        .unwrap();
                        if let Some(world) = actual {
                            assert_eq!(
                                Some(&world),
                                expected.as_ref(),
                                "seed {seed}, depth {depth}, choice {choice:?}, challenges {challenges:?}"
                            );
                            assert_eq!(
                                scout_matches(&world, &query),
                                scout_matches(expected.as_ref().unwrap(), &query)
                            );
                            for item in world
                                .items
                                .iter()
                                .filter(|item| item.source == ItemSource::VaultTreasure)
                            {
                                imp_depths[usize::from(item.depth - 17)] = true;
                                retained += 1;
                            }
                        } else {
                            assert!(!expected.as_ref().is_some_and(|world| query.matches(world)));
                        }
                    }
                }
            }
        }
        assert!(retained > 0 && imp_depths.into_iter().all(|seen| seen));
        assert!(feeling_profiles.into_iter().all(|seen| seen));
    }

    const DEFERRED_SEARCH_REQUIREMENTS: [&str; 3] = [
        r#"[{"item":"runic_blade","upgrade":2,"effect":["Grim","Corrupting","Vampiric","Crystal"]},{"item":"ring_might","upgrade":2}]"#,
        r#"[{"item":"runic_blade","upgrade":2},{"item":"ring_might"}]"#,
        r#"[{"any_of":[{"item":"runic_blade","upgrade":4,"source":"vault_treasure"},{"item":"greatsword","upgrade":2}]},{"item":"ring_might","upgrade":2}]"#,
    ];

    #[test]
    #[ignore = "extended seed sweep; run with --release --ignored"]
    fn deferred_vault_search_recipes_replays_and_witnesses_match_eager() {
        check_deferred_search(
            &values(),
            &DEFERRED_SEARCH_REQUIREMENTS,
            &[
                Challenges::NONE,
                Challenges::DARKNESS,
                Challenges::LEVEL_GENERATION,
            ],
        );
    }

    #[test]
    fn deferred_vault_smoke_preserves_worlds_recipes_replays_and_witnesses() {
        // A rejected seed, a surviving vault blade, and a blade requiring
        // Mimic Tooth. Keep positive/negative and retained-auto coverage in CI.
        let seeds = [0, 20_013_756, 20_013_125].map(|value| DungeonSeed::new(value).unwrap());
        check_deferred_search(
            &seeds,
            &DEFERRED_SEARCH_REQUIREMENTS[1..2],
            &[Challenges::NONE],
        );
    }

    fn check_deferred_search(
        seeds: &[DungeonSeed],
        requirements: &[&str],
        challenge_modes: &[Challenges],
    ) {
        use crate::auto_trinkets::{self, SeedRecipe, TrinketSearchMatch};
        fn complete(
            results: Vec<Option<TrinketSearchMatch>>,
        ) -> Vec<Option<(SeedRecipe, GeneratedWorld)>> {
            results
                .into_iter()
                .map(|result| result.map(|m| (m.recipe, m.world)))
                .collect()
        }
        let mut matches = 0;
        let mut rejected = 0;
        let mut auto_retained = 0;
        for requirements in requirements {
            for auto in [false, true] {
                for &challenges in challenge_modes {
                    let mut query = query(requirements, 19);
                    query.auto_apply_trinket = auto;
                    query.challenges = challenges;
                    let plan = QueryPlan::analyze(&query);
                    assert!(plan.deferred_vault_plan(19).is_some());
                    let actual = CanonicalMainWorldGenerator::with_challenges(challenges);
                    let eager = EagerGenerator(challenges);
                    let expected =
                        complete(auto_trinkets::search_batch(&eager, &query, &plan, seeds));
                    let found = auto_trinkets::search_batch(&actual, &query, &plan, seeds);
                    for result in &found {
                        if let Some(m) = result {
                            matches += 1;
                            auto_retained += usize::from(m.recipe.trinket.is_some());
                        } else {
                            rejected += 1;
                        }
                    }
                    assert_eq!(complete(found), expected);
                    for choice_index in 0..5 {
                        let recipes: Vec<_> = seeds
                            .iter()
                            .copied()
                            .map(|seed| SeedRecipe {
                                seed,
                                trinket: if choice_index == 0 {
                                    None
                                } else {
                                    Some(crate::trinkets::initial_offers(seed)[choice_index - 1])
                                },
                            })
                            .collect();
                        assert_eq!(
                            complete(auto_trinkets::filter_batch(
                                &actual, &query, &plan, &recipes
                            )),
                            complete(auto_trinkets::filter_batch(&eager, &query, &plan, &recipes))
                        );
                        let mut base = query.clone();
                        base.requirements[0].effect = crate::query::EffectRequirement::Any;
                        assert_eq!(
                            complete(auto_trinkets::refine_batch(
                                &actual, &query, &plan, &base, &recipes
                            )),
                            complete(auto_trinkets::refine_batch(
                                &eager, &query, &plan, &base, &recipes
                            ))
                        );
                    }
                }
            }
        }
        assert!(matches > 0 && rejected > 0 && auto_retained > 0);
    }
    std::thread_local! {
        static FAULT: std::cell::Cell<u8> = const { std::cell::Cell::new(0) };
        static FAULT_HITS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
        static STATES: std::cell::RefCell<Option<Vec<String>>> = const { std::cell::RefCell::new(None) };
    }

    pub(super) fn fault(stage: u8) -> Result<(), MainWorldError> {
        if FAULT.get() == stage {
            FAULT.set(0);
            FAULT_HITS.set(FAULT_HITS.get() + 1);
            Err(MainWorldError::InvalidMaximumDepth(0))
        } else {
            Ok(())
        }
    }

    pub(super) fn record_state(
        depth: u8,
        run: &RunState,
        limited: &LimitedDrops,
        quests: &QuestState,
        shop: &ShopRunState,
        random: &RandomStack,
    ) {
        STATES.with_borrow_mut(|states| {
            if let Some(states) = states {
                states.push(format!(
                    "{depth}: {run:?} {limited:?} {quests:?} {shop:?} {random:?}"
                ));
            }
        });
    }

    #[test]
    fn deferred_vault_preserves_complete_main_rng_and_persistent_state_each_floor() {
        let query = query(
            r#"[{"kind":"weapon"},{"kind":"ring","source":"imp_reward"}]"#,
            24,
        );
        let plan = QueryPlan::analyze(&query);
        assert!(plan.deferred_vault_plan(24).is_some());
        for seed in values().into_iter().take(8) {
            for challenges in [Challenges::NONE, Challenges::LEVEL_GENERATION] {
                STATES.set(Some(Vec::new()));
                let expected = generate_main_world_gated_with_challenges(
                    seed,
                    24,
                    challenges,
                    &EagerGate(&plan),
                )
                .unwrap();
                let expected_state = STATES.replace(Some(Vec::new())).unwrap();
                let actual =
                    generate_main_world_gated_with_challenges(seed, 24, challenges, &plan).unwrap();
                let actual_state = STATES.take().unwrap();
                assert_eq!(actual_state, expected_state, "seed {seed}, {challenges:?}");
                assert_eq!(actual, expected);
                assert!(actual_state.len() >= 16);
            }
        }
    }

    #[test]
    fn deferred_vault_typed_errors_retry_eagerly_once() {
        let mut eager_none = 0;
        let mut eager_some = 0;
        let mut injected = 0;
        for requirements in [
            r#"[{"kind":"weapon"},{"kind":"ring","source":"imp_reward"}]"#,
            r#"[{"item":"runic_blade","upgrade":2},{"item":"ring_might","upgrade":2,"max_depth":18}]"#,
        ] {
            let query = query(requirements, 19);
            let plan = QueryPlan::analyze(&query);
            assert!(plan.deferred_vault_plan(19).is_some());
            for seed in values().into_iter().take(16) {
                let expected = generate_main_world_gated(seed, 19, &EagerGate(&plan));
                for stage in [1, 2] {
                    FAULT.set(stage);
                    FAULT_HITS.set(0);
                    let actual = generate_main_world_gated(seed, 19, &plan);
                    FAULT.set(0);
                    let hits = FAULT_HITS.get();
                    assert!(hits <= 1);
                    if hits == 1 {
                        assert_eq!(actual, expected, "stage {stage}, seed {seed}");
                        eager_none += usize::from(expected == Ok(None));
                        eager_some += usize::from(expected.as_ref().is_ok_and(Option::is_some));
                        injected += 1;
                    }
                }
            }
        }
        assert!(injected > 0 && eager_none > 0 && eager_some > 0);
    }

    #[test]
    fn deferred_vault_default_custom_gate_receives_complete_eager_prefixes() {
        struct Recorder<'a> {
            plan: &'a QueryPlan,
            calls: std::sync::Mutex<Vec<(u8, Vec<WorldItem>, QuestSummary)>>,
        }
        impl FloorGate for Recorder<'_> {
            fn continue_after_floor(
                &self,
                depth: u8,
                items: &[WorldItem],
                quests: &QuestSummary,
            ) -> bool {
                self.calls
                    .lock()
                    .unwrap()
                    .push((depth, items.to_vec(), *quests));
                self.plan.continue_after_floor(depth, items, quests)
            }
        }
        let query = query(
            r#"[{"kind":"weapon"},{"kind":"ring","source":"imp_reward"}]"#,
            24,
        );
        let plan = QueryPlan::analyze(&query);
        let recorder = Recorder {
            plan: &plan,
            calls: std::sync::Mutex::new(Vec::new()),
        };
        assert!(recorder.deferred_vault_plan(24).is_none());
        let seed = DungeonSeed::MIN;
        let dungeon_seed = i64::try_from(seed.value()).unwrap();
        let roots: Vec<_> = regular_depths(24)
            .map(|depth| seed_for_depth(dungeon_seed, depth, 0))
            .collect();
        let expected = generate_gated_world_attempt(
            seed,
            24,
            &roots,
            Challenges::NONE,
            &recorder,
            None,
            false,
            &mut |_| {},
        )
        .unwrap();
        let expected_calls = std::mem::take(&mut *recorder.calls.lock().unwrap());
        let actual = generate_main_world_gated(seed, 24, &recorder).unwrap();
        assert_eq!(actual, expected);
        assert_eq!(*recorder.calls.lock().unwrap(), expected_calls);
        assert!(expected_calls.iter().any(|(_, items, _)| {
            items
                .iter()
                .any(|item| item.source == ItemSource::VaultTreasure)
        }));
    }
    // Append inside main_world::deferred_vault_tests; reuse its query helper.
    // These tests select eager versus deferred execution, never match versus
    // rejection. Every case remains a feasible query that requires the vault.
    #[test]
    fn deferred_vault_skips_non_vault_slots_resolved_before_city() {
        for requirements in [
            r#"[{"kind":"weapon"},{"kind":"wand","source":"wandmaker_reward"}]"#,
            r#"[{"kind":"weapon"},{"kind":"armor","source":"ghost_reward"}]"#,
            r#"[{"kind":"weapon"},{"kind":"armor","source":"blacksmith_reward"}]"#,
            r#"[{"kind":"weapon"},{"item":"parchment_scrap"}]"#,
            r#"[{"kind":"weapon"},{"item":"ring_might","source":"heap","max_depth":16}]"#,
        ] {
            let plan = QueryPlan::analyze(&query(requirements, 19));
            assert!(!plan.is_unsatisfiable(), "{requirements}");
            assert!(plan.wants_vault_treasure(), "{requirements}");
            assert!(plan.deferred_vault_plan(19).is_none(), "{requirements}");
        }
    }

    #[test]
    fn deferred_vault_late_deadline_and_imp_source_keep_the_strategy_available() {
        for target in [17, 18, 19, 24] {
            for (requirements, expected) in [
                (
                    r#"[{"kind":"weapon"},{"item":"ring_might","upgrade":2,"source":"heap","max_depth":16}]"#,
                    false,
                ),
                (
                    r#"[{"kind":"weapon"},{"item":"ring_might","upgrade":2,"source":"heap","max_depth":17}]"#,
                    true,
                ),
                // No identity/upgrade rarity restriction: every accessible
                // Imp supplies a searchable ring. This high-prospect family
                // intentionally survives the static late-opportunity guard.
                (
                    r#"[{"kind":"weapon"},{"kind":"ring","source":"imp_reward"}]"#,
                    true,
                ),
                (
                    r#"[{"kind":"weapon"},{"kind":"ring","source":"imp_reward","max_depth":17}]"#,
                    true,
                ),
            ] {
                let plan = QueryPlan::analyze(&query(requirements, target));
                assert!(!plan.is_unsatisfiable(), "{target}: {requirements}");
                assert!(plan.wants_vault_treasure(), "{target}: {requirements}");
                assert_eq!(
                    plan.deferred_vault_plan(target).is_some(),
                    expected,
                    "{target}: {requirements}"
                );
            }
        }
    }

    #[test]
    fn deferred_vault_late_opportunity_belongs_to_a_wholly_non_vault_slot() {
        for (requirements, expected) in [
            // One genuinely late member keeps the entire non-vault OR slot
            // eligible, even when another alternative is resolved earlier.
            (
                r#"[{"kind":"weapon"},{"any_of":[{"kind":"wand","source":"wandmaker_reward"},{"item":"ring_might","source":"heap","max_depth":17}]}]"#,
                true,
            ),
            (
                r#"[{"kind":"weapon"},{"any_of":[{"kind":"wand","source":"wandmaker_reward"},{"item":"ring_might","source":"heap","max_depth":16}]}]"#,
                false,
            ),
            (
                r#"[{"kind":"weapon"},{"any_of":[{"kind":"wand","source":"wandmaker_reward"},{"kind":"ring","source":"imp_reward"}]}]"#,
                true,
            ),
            // The late generic ring can itself use the vault. Its OR slot
            // is not wholly non-vault; the only other non-vault slot here
            // is an early trinket, which cannot qualify the strategy.
            (
                r#"[{"kind":"weapon"},{"any_of":[{"kind":"wand","source":"wandmaker_reward"},{"kind":"ring"}]},{"item":"parchment_scrap"}]"#,
                false,
            ),
        ] {
            let plan = QueryPlan::analyze(&query(requirements, 19));
            assert!(!plan.is_unsatisfiable(), "{requirements}");
            assert!(plan.wants_vault_treasure(), "{requirements}");
            assert_eq!(
                plan.deferred_vault_plan(19).is_some(),
                expected,
                "{requirements}"
            );
        }
    }
}
