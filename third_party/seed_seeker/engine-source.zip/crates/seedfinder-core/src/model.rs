//! Generated-world result model, including mutually exclusive rewards.

use crate::catalog::{Effect, ItemId};
use crate::equipment::EquipmentRoll;
use crate::quests::QuestSummary;
use crate::run::RingGems;
use crate::seed::DungeonSeed;

/// Where an item can be obtained in the generated world.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum ItemSource {
    Heap,
    Chest,
    LockedChest,
    CrystalChest,
    Tomb,
    Skeleton,
    SacrificialFire,
    Mimic,
    GoldenMimic,
    CrystalMimic,
    Statue,
    ArmoredStatue,
    Shop,
    GhostReward,
    WandmakerReward,
    BlacksmithReward,
    /// One of the Imp's six vault-prize options (v4.0.0), laid out in the
    /// vault's final room; the player brings exactly one vault item home.
    ImpReward,
    /// Equipment placed in the Imp's vault sub-level by its treasure rooms
    /// (v4.0.0). Shares the Imp reward's single-pick choice group.
    VaultTreasure,
}

impl ItemSource {
    /// Every source, in the engine's canonical order. Frontends list sources
    /// in this order and the share-link codec numbers them by it, so the
    /// sequence is part of the engine's contract rather than a display
    /// preference.
    pub const ALL: &'static [Self] = &[
        Self::Heap,
        Self::Chest,
        Self::LockedChest,
        Self::CrystalChest,
        Self::Tomb,
        Self::Skeleton,
        Self::SacrificialFire,
        Self::Mimic,
        Self::GoldenMimic,
        Self::CrystalMimic,
        Self::Statue,
        Self::ArmoredStatue,
        Self::Shop,
        Self::GhostReward,
        Self::WandmakerReward,
        Self::BlacksmithReward,
        Self::ImpReward,
        Self::VaultTreasure,
    ];

    /// The source as English UI text, in sentence case ("Locked chest",
    /// "Ghost reward") — the wording five of the six frontends already used,
    /// shared now by the requirement editor's chips, pickers and the scout.
    #[must_use]
    pub const fn label(self) -> &'static str {
        match self {
            Self::Heap => "Heap",
            Self::Chest => "Chest",
            Self::LockedChest => "Locked chest",
            Self::CrystalChest => "Crystal chest",
            Self::Tomb => "Tomb",
            Self::Skeleton => "Skeleton",
            Self::SacrificialFire => "Sacrificial fire",
            Self::Mimic => "Mimic",
            Self::GoldenMimic => "Golden mimic",
            Self::CrystalMimic => "Crystal mimic",
            Self::Statue => "Statue",
            Self::ArmoredStatue => "Armored statue",
            Self::Shop => "Shop",
            Self::GhostReward => "Ghost reward",
            Self::WandmakerReward => "Wandmaker reward",
            Self::BlacksmithReward => "Blacksmith reward",
            Self::ImpReward => "Imp reward",
            Self::VaultTreasure => "Vault treasure",
        }
    }
}

/// Stable document name for one item source: the `source` value of the
/// query document, the share link's JSON form and the editor envelopes.
#[must_use]
pub const fn source_name(source: ItemSource) -> &'static str {
    match source {
        ItemSource::Heap => "heap",
        ItemSource::Chest => "chest",
        ItemSource::LockedChest => "locked_chest",
        ItemSource::CrystalChest => "crystal_chest",
        ItemSource::Tomb => "tomb",
        ItemSource::Skeleton => "skeleton",
        ItemSource::SacrificialFire => "sacrificial_fire",
        ItemSource::Mimic => "mimic",
        ItemSource::GoldenMimic => "golden_mimic",
        ItemSource::CrystalMimic => "crystal_mimic",
        ItemSource::Statue => "statue",
        ItemSource::ArmoredStatue => "armored_statue",
        ItemSource::Shop => "shop",
        ItemSource::GhostReward => "ghost_reward",
        ItemSource::WandmakerReward => "wandmaker_reward",
        ItemSource::BlacksmithReward => "blacksmith_reward",
        ItemSource::ImpReward => "imp_reward",
        ItemSource::VaultTreasure => "vault_treasure",
    }
}

/// Co-acquisition constraints for a generated reward.
///
/// Most rewards are independent. Simple quest/chest choices use one option,
/// while rooms with keys and prerequisite paths enumerate their finite set of
/// feasible acquisition plans as a bit mask. Items from the same group can be
/// obtained together exactly when their masks have at least one common bit.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum Accessibility {
    Independent,
    Choice {
        /// Stable within one world; all rewards in the same choice share it.
        group: u16,
        /// Rewards with the same option can be obtained together.
        option: u8,
    },
    Scenarios {
        /// Stable within one world; all constrained rewards from the same
        /// decision topology share it.
        group: u16,
        /// Nonzero bit set of feasible acquisition plans containing this
        /// reward. At most 64 plans are needed by v3.3.8 room topologies.
        mask: u64,
    },
}

impl Accessibility {
    /// Converts a simple option or explicit scenario set into the common mask
    /// representation used by the query matcher.
    #[must_use]
    pub const fn scenario_constraint(self) -> Option<(u16, u64)> {
        match self {
            Self::Independent => None,
            Self::Choice { group, option } => {
                let mask = if option < 64 { 1_u64 << option } else { 0 };
                Some((group, mask))
            }
            Self::Scenarios { group, mask } => Some((group, mask)),
        }
    }
}

/// One deterministically generated, world-searchable item.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WorldItem {
    pub item: ItemId,
    /// Equipment upgrade, or the artifact transfer amount (+5 in the Imp vault).
    pub upgrade: u8,
    pub effect: Option<Effect>,
    pub cursed: bool,
    pub depth: u8,
    pub source: ItemSource,
    pub accessibility: Accessibility,
    /// The item lies inside a secret room and stays invisible until the
    /// player searches out its hidden door.
    pub secret: bool,
}

/// Identified in-game level, shared by scout rows and map inspection.
pub(crate) const fn displayed_upgrade(item: ItemId, upgrade: u8) -> u8 {
    let cap = match item {
        ItemId::SandalsOfNature => 3,
        ItemId::EtherealChains | ItemId::TimekeepersHourglass => 5,
        _ => return upgrade,
    };
    let internal = (upgrade * cap + 5) / 10;
    (internal * 10 + cap / 2) / cap
}

impl WorldItem {
    /// Identified in-game upgrade: artifacts round both transferUpgrade and visiblyUpgraded.
    #[must_use]
    pub const fn displayed_upgrade(&self) -> u8 {
        displayed_upgrade(self.item, self.upgrade)
    }

    pub(crate) fn catalyst(depth: u8, source: ItemSource, accessibility: Accessibility) -> Self {
        Self {
            item: ItemId::TrinketCatalyst,
            upgrade: 0,
            effect: None,
            cursed: false,
            depth,
            source,
            accessibility,
            secret: false,
        }
    }

    /// Builds a searchable record without reinterpreting the equipment roll.
    #[must_use]
    pub const fn from_equipment_roll(
        item: ItemId,
        roll: EquipmentRoll,
        depth: u8,
        source: ItemSource,
        accessibility: Accessibility,
    ) -> Self {
        Self {
            item,
            upgrade: roll.upgrade,
            effect: roll.effect,
            cursed: roll.cursed,
            depth,
            source,
            accessibility,
            secret: false,
        }
    }

    /// Marks the record as hidden inside a secret room.
    #[must_use]
    pub const fn in_secret_room(mut self) -> Self {
        self.secret = true;
        self
    }
}

/// Final feeling for a generated regular floor.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct FloorFeeling {
    pub depth: u8,
    pub feeling: crate::level_prelude::Feeling,
}

/// Searchable output for one seed.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GeneratedWorld {
    pub seed: DungeonSeed,
    pub items: Vec<WorldItem>,
    /// Final feelings in depth order, excluding boss floors.
    pub feelings: Vec<FloorFeeling>,
    /// Room presence on regular floors, included in SSC8 and web scout responses.
    pub floor_rooms: Vec<crate::floor_filters::FloorRooms>,
    /// Remaining artifact deck after each generated floor.
    pub artifact_decks: Vec<crate::artifacts::ArtifactDeck>,
    /// Quest variants rolled while generating the requested prefix.
    pub quests: QuestSummary,
    /// The gem this run gave each ring class, and so the `items.png` cell every
    /// ring in [`Self::items`] is drawn in. Like [`Self::quests`] this belongs
    /// to the run rather than to any one item: `Dungeon.init()` shuffles
    /// `Ring.gems` once, before the first floor exists. Resolve a cell with
    /// [`crate::catalog::ItemDefinition::sprite_index_in`].
    pub ring_gems: RingGems,
}
