//! Deterministic, cancellable multicore traversal of seed ranges.

use std::cell::Cell;
use std::collections::VecDeque;
use std::num::NonZeroUsize;
use std::panic::{AssertUnwindSafe, catch_unwind};
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use crate::feasibility::QueryPlan;
use crate::model::{GeneratedWorld, WorldItem};
use crate::query::{QueryError, SearchQuery};
use crate::quests::QuestSummary;
use crate::seed::{DungeonSeed, TOTAL_SEEDS};

/// Distance between the starting points of consecutive production searches.
///
/// Approximately one golden-ratio turn of the seed circle. [`TOTAL_SEEDS`]
/// only has 2 and 13 as prime factors; this odd, non-multiple-of-13 stride is
/// therefore coprime and visits every possible start before repeating.
pub const PRODUCTION_SEARCH_START_STRIDE: u64 = 3_355_211_884_971;

/// Per-floor cancellation oracle consulted between floors of one seed.
///
/// Returning `false` promises that no continuation of the partial world can
/// satisfy the active query, letting the generator abandon the seed without
/// producing its remaining floors. `quests_so_far` carries the variants
/// rolled by the floors generated up to this point, which is what lets a
/// quest filter prune a seed the moment its giver appears.
pub trait FloorGate: Sync {
    /// Exact-floor checks used before layout and before painting. No RNG is consumed.
    fn floor_requirement(
        &self,
        _depth: u8,
    ) -> Option<&crate::floor_filters::CompiledFloorRequirement> {
        None
    }

    /// Check seed-specific facts fixed by run initialization before generating
    /// a floor. Returning false must prove the query cannot match this seed.
    fn continue_after_run_init(&self, _run: &crate::run::RunState) -> bool {
        true
    }

    fn selected_trinket(&self, _seed: DungeonSeed) -> Option<crate::catalog::ItemId> {
        None
    }

    fn continue_after_floor(
        &self,
        completed_depth: u8,
        items_so_far: &[WorldItem],
        quests_so_far: &QuestSummary,
    ) -> bool;

    /// Opt into delaying the independent vault until the requested prefix is
    /// complete. The returned plan must describe this gate's exact pruning
    /// and pass its target-specific eligibility check; forward the plan's
    /// implementation of this method. All callbacks must be pure, since a
    /// failed deferred attempt is retried eagerly. Custom gates default to eager
    /// generation and keep receiving complete floor prefixes.
    fn deferred_vault_plan(&self, _target: u8) -> Option<&QueryPlan> {
        None
    }

    /// Whether the Imp's Vault sub-level must be generated. Its treasure is
    /// only ever matched by requirements the vault can satisfy, so a gate
    /// that knows none exist lets the generator skip the extra level.
    fn wants_vault_treasure(&self) -> bool {
        true
    }
}

/// Version-pinned world simulator used by the parallel search scheduler.
pub trait WorldGenerator: Sync {
    fn generate(&self, seed: DungeonSeed, max_depth: u8) -> GeneratedWorld;

    /// Generates an ordered batch. Implementors may override this to share
    /// setup or use SIMD while preserving one result for every input seed.
    fn generate_batch(&self, seeds: &[DungeonSeed], max_depth: u8) -> Vec<GeneratedWorld> {
        seeds
            .iter()
            .copied()
            .map(|seed| self.generate(seed, max_depth))
            .collect()
    }

    /// Generates an ordered batch under a [`FloorGate`], returning `None` for
    /// seeds the gate proved unable to match. The default ignores the gate,
    /// which is always correct because `None` is only an optimization.
    fn generate_batch_gated(
        &self,
        seeds: &[DungeonSeed],
        max_depth: u8,
        gate: &dyn FloorGate,
    ) -> Vec<Option<GeneratedWorld>> {
        let _ = gate;
        self.generate_batch(seeds, max_depth)
            .into_iter()
            .map(Some)
            .collect()
    }
}

/// Bounds and resource limits for one search.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SearchOptions {
    pub start_seed: u64,
    pub end_seed_exclusive: u64,
    pub workers: NonZeroUsize,
    pub chunk_size: NonZeroUsize,
    pub max_results: NonZeroUsize,
}

impl SearchOptions {
    #[must_use]
    pub fn available_parallelism() -> NonZeroUsize {
        std::thread::available_parallelism().unwrap_or(NonZeroUsize::MIN)
    }
}

/// Observable counters shared with UI/JNI polling code.
#[derive(Debug, Default)]
pub struct SearchProgress {
    tested: AtomicU64,
    cancelled: AtomicBool,
}

impl SearchProgress {
    #[must_use]
    pub fn tested(&self) -> u64 {
        self.tested.load(Ordering::Relaxed)
    }

    #[must_use]
    pub fn is_cancelled(&self) -> bool {
        self.cancelled.load(Ordering::Acquire)
    }

    pub fn cancel(&self) {
        self.cancelled.store(true, Ordering::Release);
    }
}

/// Results and measured throughput for a completed or cancelled search.
#[derive(Clone, Debug)]
pub struct SearchOutcome {
    pub worlds: Vec<GeneratedWorld>,
    pub tested: u64,
    pub elapsed: Duration,
}

impl SearchOutcome {
    #[must_use]
    #[allow(clippy::cast_precision_loss)] // A display-only rate does not need integer precision.
    pub fn seeds_per_second(&self) -> f64 {
        if self.elapsed.is_zero() {
            return 0.0;
        }
        self.tested as f64 / self.elapsed.as_secs_f64()
    }
}

/// Validates and searches a numeric seed interval on multiple worker threads.
/// Results are sorted by seed, independent of scheduling order.
///
/// # Errors
///
/// Returns [`SearchError`] for an invalid query or numeric interval.
///
/// # Panics
///
/// Panics if a custom [`WorldGenerator::generate_batch`] implementation
/// violates its one-output-per-input contract.
pub fn search_parallel<G: WorldGenerator>(
    generator: &G,
    query: &SearchQuery,
    options: SearchOptions,
    progress: &SearchProgress,
) -> Result<SearchOutcome, SearchError> {
    query.validate()?;
    if options.start_seed >= options.end_seed_exclusive || options.end_seed_exclusive > TOTAL_SEEDS
    {
        return Err(SearchError::InvalidSeedRange);
    }

    let started = Instant::now();
    let plan = QueryPlan::analyze(query);
    if plan.is_unsatisfiable() {
        return Ok(SearchOutcome {
            worlds: Vec::new(),
            tested: 0,
            elapsed: started.elapsed(),
        });
    }
    let generation_depth = plan.generation_depth();
    let cursor = AtomicU64::new(options.start_seed);
    let results = Mutex::new(Vec::new());
    let result_count = AtomicU64::new(0);
    let chunk_size = u64::try_from(options.chunk_size.get()).unwrap_or(1);
    let max_results = u64::try_from(options.max_results.get()).unwrap_or(u64::MAX);

    std::thread::scope(|scope| {
        for _ in 0..options.workers.get() {
            scope.spawn(|| {
                while !progress.is_cancelled() && result_count.load(Ordering::Acquire) < max_results
                {
                    let chunk_start = cursor.fetch_add(chunk_size, Ordering::Relaxed);
                    if chunk_start >= options.end_seed_exclusive {
                        break;
                    }
                    let chunk_end = chunk_start
                        .saturating_add(chunk_size)
                        .min(options.end_seed_exclusive);
                    let seeds = (chunk_start..chunk_end)
                        .map(|value| {
                            DungeonSeed::new(value).expect(
                                "a validated search interval contains only representable seeds",
                            )
                        })
                        .collect::<Vec<_>>();
                    let worlds = generator.generate_batch_gated(&seeds, generation_depth, &plan);
                    assert_eq!(
                        worlds.len(),
                        seeds.len(),
                        "WorldGenerator::generate_batch_gated must return one entry per seed"
                    );
                    let mut local_results = Vec::new();
                    let mut local_tested = 0_u64;
                    for world in worlds {
                        if progress.is_cancelled()
                            || result_count.load(Ordering::Acquire) >= max_results
                        {
                            break;
                        }
                        local_tested += 1;
                        let Some(world) = world else {
                            continue;
                        };
                        if query.matches(&world) {
                            let prior = result_count.fetch_add(1, Ordering::AcqRel);
                            if prior < max_results {
                                local_results.push(world);
                            }
                        }
                    }
                    progress.tested.fetch_add(local_tested, Ordering::Relaxed);
                    if !local_results.is_empty() {
                        results
                            .lock()
                            .unwrap_or_else(std::sync::PoisonError::into_inner)
                            .extend(local_results);
                    }
                }
            });
        }
    });

    let mut worlds = results
        .into_inner()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    worlds.sort_unstable_by_key(|world| world.seed);
    worlds.truncate(options.max_results.get());
    Ok(SearchOutcome {
        worlds,
        tested: progress.tested(),
        elapsed: started.elapsed(),
    })
}

/// Starts a search on a coordinator thread and returns a cancellable handle.
/// This is the ownership shape used by the JNI layer.
pub fn spawn_search<G: WorldGenerator + Send + 'static>(
    generator: Arc<G>,
    query: SearchQuery,
    options: SearchOptions,
) -> SearchHandle {
    let progress = Arc::new(SearchProgress::default());
    let thread_progress = Arc::clone(&progress);
    let join = std::thread::spawn(move || {
        search_parallel(generator.as_ref(), &query, options, &thread_progress)
    });
    SearchHandle {
        progress,
        join: Some(join),
    }
}

/// Owned lifecycle for an asynchronous native search.
pub struct SearchHandle {
    progress: Arc<SearchProgress>,
    join: Option<std::thread::JoinHandle<Result<SearchOutcome, SearchError>>>,
}

/// Terminal state exposed by the non-blocking streaming search API.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum StreamingSearchState {
    Running,
    Completed,
    Cancelled,
    Failed,
}

/// Diagnostic retained for the first streaming worker panic.
///
/// The chunk bounds identify every seed which could have been executing when
/// the panic was raised. The panic payload is preserved when it is a string,
/// which is the shape produced by Rust assertions and generation invariants.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StreamingSearchFailure {
    pub chunk_start: Option<u64>,
    pub chunk_end_exclusive: Option<u64>,
    pub message: String,
}

/// Sentinel meaning a worker has no partially processed chunk.
const NO_PENDING_CHUNK: u64 = u64::MAX;

#[derive(Debug)]
struct StreamingShared {
    cursor: AtomicU64,
    range_start: u64,
    end_seed_exclusive: u64,
    traversal_start: u64,
    total: u64,
    chunk_size: u64,
    max_results: u64,
    /// The query plan proved no seed can match, so no worker ever claims a
    /// chunk and the traversal's coverage must stay zero.
    unsatisfiable: bool,
    tested: AtomicU64,
    accepted: AtomicU64,
    cancelled: AtomicBool,
    failed: AtomicBool,
    failure: Mutex<Option<StreamingSearchFailure>>,
    active_workers: AtomicUsize,
    results: Mutex<VecDeque<GeneratedWorld>>,
    /// One slot per worker holding the lowest logical index in a claimed chunk
    /// whose outcome is not yet recorded, or [`NO_PENDING_CHUNK`].
    worker_low_water: Vec<AtomicU64>,
}

impl StreamingShared {
    fn state(&self) -> StreamingSearchState {
        if self.active_workers.load(Ordering::Acquire) != 0 {
            StreamingSearchState::Running
        } else if !self
            .results
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .is_empty()
        {
            // Frontends poll results and stop polling as soon as status
            // becomes terminal. Keep the session observable as running until
            // every produced match has been drained — for cancelled and
            // failed searches too, because those matches sit inside the
            // consumed prefix a refined search will never revisit. Every
            // terminal state therefore implies that the workers have exited
            // and the resume coverage snapshot is frozen.
            StreamingSearchState::Running
        } else if self.failed.load(Ordering::Acquire) {
            StreamingSearchState::Failed
        } else if self.cancelled.load(Ordering::Acquire) {
            StreamingSearchState::Cancelled
        } else {
            StreamingSearchState::Completed
        }
    }

    fn record_failure(&self, failure: StreamingSearchFailure) {
        let mut retained = self
            .failure
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        if retained.is_none() {
            *retained = Some(failure);
        }
        drop(retained);
        self.failed.store(true, Ordering::Release);
        self.cancelled.store(true, Ordering::Release);
    }
}

/// A multicore search whose progress and matches can be polled without
/// blocking for completion. Dropping the handle cooperatively cancels and
/// joins every worker.
pub struct StreamingSearchHandle {
    shared: Arc<StreamingShared>,
    workers: Vec<std::thread::JoinHandle<()>>,
}

impl StreamingSearchHandle {
    #[must_use]
    pub fn state(&self) -> StreamingSearchState {
        self.shared.state()
    }

    #[must_use]
    pub fn tested(&self) -> u64 {
        self.shared.tested.load(Ordering::Relaxed)
    }

    #[must_use]
    pub fn total(&self) -> u64 {
        self.shared.total
    }

    #[must_use]
    pub fn accepted(&self) -> u64 {
        self.shared.accepted.load(Ordering::Relaxed)
    }

    /// Returns the first retained worker panic, if one occurred.
    #[must_use]
    pub fn failure(&self) -> Option<StreamingSearchFailure> {
        self.shared
            .failure
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .clone()
    }

    /// Drains up to `maximum` matches which have already completed. It never
    /// waits for a worker or a future result.
    pub fn drain_results(&self, maximum: usize) -> Vec<GeneratedWorld> {
        let mut queue = self
            .shared
            .results
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let count = maximum.min(queue.len());
        queue.drain(..count).collect()
    }

    pub fn cancel(&self) {
        self.shared.cancelled.store(true, Ordering::Release);
    }

    #[must_use]
    pub fn is_finished(&self) -> bool {
        self.shared.active_workers.load(Ordering::Acquire) == 0
    }

    /// Number of seeds at the front of the traversal whose outcome has been
    /// fully recorded: every one of the first `scanned_prefix()` seeds visited
    /// by this traversal was either rejected, pruned, or delivered as a match.
    ///
    /// The value is only meaningful once [`Self::is_finished`] is true: while
    /// workers are still running it can transiently overshoot by up to one
    /// claimed-but-unstarted chunk per worker, because a chunk is claimed
    /// from the cursor before the worker marks it pending.
    fn scanned_prefix(&self) -> u64 {
        if self.shared.unsatisfiable {
            // No worker ever ran: the pre-seeded cursor exists to complete
            // the search instantly and must not masquerade as coverage.
            return 0;
        }
        let claimed = self
            .shared
            .cursor
            .load(Ordering::Acquire)
            .min(self.shared.total);
        self.shared
            .worker_low_water
            .iter()
            .map(|slot| slot.load(Ordering::Acquire))
            .min()
            .unwrap_or(NO_PENDING_CHUNK)
            .min(claimed)
    }

    /// Where and how much a follow-up traversal must scan to complete this
    /// traversal's coverage, derived from one coherent snapshot of the
    /// scanned prefix. Read it only after the search has finished: every
    /// terminal [`StreamingSearchState`] implies [`Self::is_finished`], and a
    /// snapshot taken from a running search may overshoot the work actually
    /// done, so it must never be resumed from.
    #[must_use]
    pub fn resume_coverage(&self) -> ResumeCoverage {
        let prefix = self.scanned_prefix();
        let range_len = self.shared.end_seed_exclusive - self.shared.range_start;
        let offset = self.shared.traversal_start - self.shared.range_start;
        ResumeCoverage {
            position: self.shared.range_start + (offset + prefix) % range_len,
            remaining: self.shared.total - prefix,
        }
    }
}

/// A finished traversal's uncovered remainder: a follow-up traversal covering
/// `remaining` seeds from `position` (wrapping at the end of the configured
/// range) completes the coverage without losing any seed outcome. A resumed
/// pass can re-test a small overlap after a cancellation or worker panic, so
/// consumers accumulating matches across passes should deduplicate them by
/// seed.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ResumeCoverage {
    /// Absolute seed value where the follow-up traversal starts.
    pub position: u64,
    /// Number of seeds the follow-up traversal must cover.
    pub remaining: u64,
}

impl Drop for StreamingSearchHandle {
    fn drop(&mut self) {
        self.cancel();
        for worker in self.workers.drain(..) {
            if worker.join().is_err() {
                self.shared.failed.store(true, Ordering::Release);
            }
        }
    }
}

/// Starts a non-blocking multicore traversal suitable for JNI polling.
///
/// Results within an individual claimed chunk retain numeric seed order.
/// Chunks may finish in a different order because they run concurrently.
///
/// # Errors
///
/// Returns [`SearchError`] before starting any worker for an invalid query or
/// numeric seed interval.
pub fn spawn_streaming_search<G: WorldGenerator + Send + 'static>(
    generator: &Arc<G>,
    query: SearchQuery,
    options: SearchOptions,
) -> Result<StreamingSearchHandle, SearchError> {
    spawn_rotated_streaming_search(generator, query, options, options.start_seed)
}

/// Starts a non-blocking multicore traversal at `traversal_start`, wrapping at
/// the end of the configured range and finishing immediately before the start.
///
/// Seed construction within each chunk remains a contiguous incrementing
/// range. Only the chunk containing the single wrap point is split in two, so
/// rotating a search adds no modular arithmetic to its per-seed hot path.
///
/// # Errors
///
/// Returns [`SearchError`] before starting any worker for an invalid query,
/// numeric seed interval, or traversal start outside that interval.
pub fn spawn_rotated_streaming_search<G: WorldGenerator + Send + 'static>(
    generator: &Arc<G>,
    query: SearchQuery,
    options: SearchOptions,
    traversal_start: u64,
) -> Result<StreamingSearchHandle, SearchError> {
    let scan_len = options
        .end_seed_exclusive
        .saturating_sub(options.start_seed);
    spawn_partial_streaming_search(generator, query, options, traversal_start, scan_len)
}

/// Starts a non-blocking multicore traversal covering only the `scan_len`
/// seeds beginning at `traversal_start`, wrapping at the end of the configured
/// range. This is the resume primitive used to refine a stopped or completed
/// search: pass the previous handle's [`StreamingSearchHandle::resume_coverage`]
/// values to continue exactly where the previous traversal left off.
///
/// A `scan_len` of zero is accepted and completes immediately.
///
/// # Errors
///
/// Returns [`SearchError`] before starting any worker for an invalid query,
/// numeric seed interval, traversal start outside that interval, or a scan
/// length longer than the interval.
pub fn spawn_partial_streaming_search<G: WorldGenerator + Send + 'static>(
    generator: &Arc<G>,
    query: SearchQuery,
    options: SearchOptions,
    traversal_start: u64,
    scan_len: u64,
) -> Result<StreamingSearchHandle, SearchError> {
    query.validate()?;
    if options.start_seed >= options.end_seed_exclusive
        || options.end_seed_exclusive > TOTAL_SEEDS
        || !(options.start_seed..options.end_seed_exclusive).contains(&traversal_start)
        || scan_len > options.end_seed_exclusive - options.start_seed
    {
        return Err(SearchError::InvalidSeedRange);
    }

    let total = scan_len;
    let plan = Arc::new(QueryPlan::analyze(&query));
    let shared = Arc::new(StreamingShared {
        // An impossible query is complete before any worker claims a chunk.
        // The flag keeps its reported coverage at zero: completing without
        // scanning must not consume the remainder a satisfiable follow-up
        // query still has to cover.
        cursor: AtomicU64::new(if plan.is_unsatisfiable() { total } else { 0 }),
        unsatisfiable: plan.is_unsatisfiable(),
        range_start: options.start_seed,
        end_seed_exclusive: options.end_seed_exclusive,
        traversal_start,
        total,
        chunk_size: u64::try_from(options.chunk_size.get()).unwrap_or(1),
        max_results: u64::try_from(options.max_results.get()).unwrap_or(u64::MAX),
        tested: AtomicU64::new(0),
        accepted: AtomicU64::new(0),
        cancelled: AtomicBool::new(false),
        failed: AtomicBool::new(false),
        failure: Mutex::new(None),
        active_workers: AtomicUsize::new(options.workers.get()),
        results: Mutex::new(VecDeque::new()),
        worker_low_water: (0..options.workers.get())
            .map(|_| AtomicU64::new(NO_PENDING_CHUNK))
            .collect(),
    });
    let query = Arc::new(query);
    let mut workers = Vec::with_capacity(options.workers.get());

    for worker_index in 0..options.workers.get() {
        let worker_generator = Arc::clone(generator);
        let worker_query = Arc::clone(&query);
        let worker_plan = Arc::clone(&plan);
        let worker_shared = Arc::clone(&shared);
        workers.push(std::thread::spawn(move || {
            let active_chunk = Cell::new(None);
            let worker_result = catch_unwind(AssertUnwindSafe(|| {
                streaming_worker(
                    worker_generator.as_ref(),
                    worker_query.as_ref(),
                    worker_plan.as_ref(),
                    worker_shared.as_ref(),
                    worker_index,
                    &active_chunk,
                );
            }));
            if let Err(payload) = worker_result {
                let chunk = active_chunk.get();
                worker_shared.record_failure(StreamingSearchFailure {
                    chunk_start: chunk.map(|(start, _)| start),
                    chunk_end_exclusive: chunk.map(|(_, end)| end),
                    message: panic_payload_message(payload.as_ref()),
                });
            }
            worker_shared.active_workers.fetch_sub(1, Ordering::AcqRel);
        }));
    }

    Ok(StreamingSearchHandle { shared, workers })
}

fn streaming_worker<G: WorldGenerator>(
    generator: &G,
    query: &SearchQuery,
    plan: &QueryPlan,
    shared: &StreamingShared,
    worker_index: usize,
    active_chunk: &Cell<Option<(u64, u64)>>,
) {
    let generation_depth = plan.generation_depth();
    let seeds_before_wrap = shared.end_seed_exclusive - shared.traversal_start;
    let low_water = &shared.worker_low_water[worker_index];
    // The result cap gates *claiming*: a claimed chunk always runs to
    // completion (unless cancelled), so every pass that claims at least one
    // chunk advances the recorded coverage — resumed passes are guaranteed to
    // make progress. The cap can overshoot by at most one chunk of accepted
    // matches per worker.
    while !shared.cancelled.load(Ordering::Acquire)
        && shared.accepted.load(Ordering::Acquire) < shared.max_results
    {
        let logical_start = shared
            .cursor
            .fetch_add(shared.chunk_size, Ordering::Relaxed);
        if logical_start >= shared.total {
            return;
        }
        let logical_end = logical_start
            .saturating_add(shared.chunk_size)
            .min(shared.total);
        // Claim the whole chunk as pending so a panic anywhere inside it keeps
        // the recorded scanned prefix conservative.
        low_water.store(logical_start, Ordering::Release);
        let mut consumed = 0;

        if logical_start < seeds_before_wrap {
            let first_end = logical_end.min(seeds_before_wrap);
            consumed += streaming_seed_range(
                generator,
                query,
                plan,
                shared,
                active_chunk,
                generation_depth,
                shared.traversal_start + logical_start,
                shared.traversal_start + first_end,
            );

            // This branch runs for at most one claimed chunk in the entire
            // search. Keeping the two numeric ranges separate preserves the
            // ordinary increment loop and accurate panic diagnostics.
            if logical_end > seeds_before_wrap && !shared.cancelled.load(Ordering::Acquire) {
                consumed += streaming_seed_range(
                    generator,
                    query,
                    plan,
                    shared,
                    active_chunk,
                    generation_depth,
                    shared.range_start,
                    shared.range_start + (logical_end - seeds_before_wrap),
                );
            }
        } else {
            let start = shared.range_start + (logical_start - seeds_before_wrap);
            let end = shared.range_start + (logical_end - seeds_before_wrap);
            consumed += streaming_seed_range(
                generator,
                query,
                plan,
                shared,
                active_chunk,
                generation_depth,
                start,
                end,
            );
        }

        if consumed == logical_end - logical_start {
            low_water.store(NO_PENDING_CHUNK, Ordering::Release);
        } else {
            low_water.store(logical_start + consumed, Ordering::Release);
        }
    }
}

/// Tests one contiguous seed range and returns how many seeds at the front of
/// the range had their outcome fully recorded (rejected, pruned, or delivered
/// as an accepted match). Only cancellation stops a range midway; the result
/// cap is enforced when chunks are claimed, so a range that starts is normally
/// consumed in full and its prefix count equals its length.
#[inline]
#[allow(clippy::too_many_arguments)]
fn streaming_seed_range<G: WorldGenerator>(
    generator: &G,
    query: &SearchQuery,
    plan: &QueryPlan,
    shared: &StreamingShared,
    active_chunk: &Cell<Option<(u64, u64)>>,
    generation_depth: u8,
    start: u64,
    end: u64,
) -> u64 {
    active_chunk.set(Some((start, end)));
    let seeds: Vec<_> = (start..end)
        .map(|value| {
            DungeonSeed::new(value)
                .expect("a validated search interval only contains representable seeds")
        })
        .collect();
    let worlds = generator.generate_batch_gated(&seeds, generation_depth, plan);
    assert_eq!(
        worlds.len(),
        seeds.len(),
        "WorldGenerator::generate_batch_gated must return one entry per seed"
    );

    let mut local_results = Vec::new();
    let mut local_tested = 0_u64;
    let mut consumed = 0_u64;
    for world in worlds {
        if shared.cancelled.load(Ordering::Acquire) {
            break;
        }
        local_tested += 1;
        if let Some(world) = world {
            if query.matches(&world) {
                shared.accepted.fetch_add(1, Ordering::AcqRel);
                local_results.push(world);
            }
        }
        consumed += 1;
    }
    shared.tested.fetch_add(local_tested, Ordering::Relaxed);
    if !local_results.is_empty() {
        shared
            .results
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .extend(local_results);
    }
    active_chunk.set(None);
    consumed
}

fn panic_payload_message(payload: &(dyn std::any::Any + Send)) -> String {
    if let Some(message) = payload.downcast_ref::<&str>() {
        (*message).to_owned()
    } else if let Some(message) = payload.downcast_ref::<String>() {
        message.clone()
    } else {
        "non-string panic payload".to_owned()
    }
}

impl SearchHandle {
    #[must_use]
    pub fn progress(&self) -> &Arc<SearchProgress> {
        &self.progress
    }

    pub fn cancel(&self) {
        self.progress.cancel();
    }

    #[must_use]
    pub fn is_finished(&self) -> bool {
        self.join
            .as_ref()
            .is_none_or(std::thread::JoinHandle::is_finished)
    }

    /// Waits for worker completion.
    ///
    /// # Errors
    ///
    /// Returns the search validation error, or [`SearchError::WorkerPanicked`]
    /// if the coordinator thread failed unexpectedly.
    pub fn join(mut self) -> Result<SearchOutcome, SearchError> {
        self.join
            .take()
            .ok_or(SearchError::AlreadyJoined)?
            .join()
            .map_err(|_| SearchError::WorkerPanicked)?
    }
}

impl Drop for SearchHandle {
    fn drop(&mut self) {
        self.cancel();
        if let Some(join) = self.join.take() {
            let _ = join.join();
        }
    }
}

/// Search setup or worker error.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SearchError {
    InvalidQuery(QueryError),
    InvalidSeedRange,
    AlreadyJoined,
    WorkerPanicked,
}

impl From<QueryError> for SearchError {
    fn from(error: QueryError) -> Self {
        Self::InvalidQuery(error)
    }
}

#[cfg(test)]
mod tests {
    use std::num::NonZeroUsize;
    use std::sync::{Arc, Mutex};

    use crate::catalog::{ItemId, ItemKind};
    use crate::model::{Accessibility, GeneratedWorld, ItemSource, WorldItem};
    use crate::query::{EffectRequirement, Requirement, SearchQuery, TierRequirement};
    use crate::run::RingGems;

    use super::{
        SearchError, SearchOptions, SearchProgress, StreamingSearchState, WorldGenerator,
        search_parallel, spawn_partial_streaming_search, spawn_rotated_streaming_search,
        spawn_streaming_search,
    };

    const SEARCH_SEEDS: u64 = 1_024;

    struct DivisibleGenerator;

    impl WorldGenerator for DivisibleGenerator {
        fn generate(&self, seed: crate::seed::DungeonSeed, _max_depth: u8) -> GeneratedWorld {
            let items = if seed.value() % 17 == 0 {
                vec![WorldItem {
                    item: ItemId::WandFrost,
                    upgrade: 2,
                    effect: None,
                    cursed: false,
                    depth: 1,
                    source: ItemSource::Heap,
                    accessibility: Accessibility::Independent,
                    secret: false,
                }]
            } else {
                Vec::new()
            };
            GeneratedWorld {
                floor_rooms: Vec::new(),
                artifact_decks: Vec::new(),
                feelings: Vec::new(),
                quests: crate::quests::QuestSummary::default(),
                seed,
                items,
                ring_gems: RingGems::UNSHUFFLED,
            }
        }
    }

    #[test]
    fn parallel_results_are_sorted_and_bounded() {
        let query = SearchQuery {
            floor_requirements: Vec::new(),
            auto_apply_trinket: false,
            arcane_resin_filter: crate::query::ArcaneResinFilter::default(),
            arcane_resin_auto: false,
            arcane_resin: 0,
            requirements: vec![Requirement {
                kind: ItemKind::Wand,
                weapon_category: None,
                item: Some(ItemId::WandFrost),
                tier: TierRequirement::Any,
                upgrade: crate::query::UpgradeRequirement::Exact(2),
                effect: EffectRequirement::Any,
                require_uncursed: false,
                select_trinket: false,
                trinket_transmutations: 0,
                artifact_transmutations: 0,
                blanket: false,
                exclude_resin: false,
                source: None,
                identity_group: None,
                max_depth: None,
                alternative_group: None,
                level_sum: None,
            }],
            max_depth: 4,
            challenges: crate::challenges::Challenges::NONE,
            require_blacksmith: false,
            exclude_blacksmith_rewards: false,
            wandmaker_quest: None,
        };
        let options = SearchOptions {
            start_seed: 0,
            end_seed_exclusive: SEARCH_SEEDS,
            workers: NonZeroUsize::new(4).unwrap(),
            chunk_size: NonZeroUsize::new(31).unwrap(),
            max_results: NonZeroUsize::new(20).unwrap(),
        };
        let progress = SearchProgress::default();
        let outcome = search_parallel(&DivisibleGenerator, &query, options, &progress).unwrap();
        assert_eq!(outcome.worlds.len(), 20);
        assert!(
            outcome
                .worlds
                .windows(2)
                .all(|pair| pair[0].seed < pair[1].seed)
        );
        assert!(
            outcome
                .worlds
                .iter()
                .all(|world| world.seed.value() % 17 == 0)
        );
        assert!(outcome.tested >= 20);
    }

    #[test]
    fn streaming_search_uses_batch_hook_and_drains_without_blocking() {
        struct BatchOnlyGenerator;

        impl WorldGenerator for BatchOnlyGenerator {
            fn generate(&self, _seed: crate::seed::DungeonSeed, _max_depth: u8) -> GeneratedWorld {
                panic!("the streaming scheduler should use generate_batch")
            }

            fn generate_batch(
                &self,
                seeds: &[crate::seed::DungeonSeed],
                _max_depth: u8,
            ) -> Vec<GeneratedWorld> {
                seeds
                    .iter()
                    .copied()
                    .map(|seed| GeneratedWorld {
                        floor_rooms: Vec::new(),
                        artifact_decks: Vec::new(),
                        feelings: Vec::new(),
                        quests: crate::quests::QuestSummary::default(),
                        seed,
                        items: (seed.value() % 17 == 0)
                            .then_some(WorldItem {
                                item: ItemId::WandFrost,
                                upgrade: 2,
                                effect: None,
                                cursed: false,
                                depth: 1,
                                source: ItemSource::Heap,
                                accessibility: Accessibility::Independent,
                                secret: false,
                            })
                            .into_iter()
                            .collect(),
                        ring_gems: RingGems::UNSHUFFLED,
                    })
                    .collect()
            }
        }

        let query = SearchQuery {
            floor_requirements: Vec::new(),
            auto_apply_trinket: false,
            arcane_resin_filter: crate::query::ArcaneResinFilter::default(),
            arcane_resin_auto: false,
            arcane_resin: 0,
            requirements: vec![Requirement {
                kind: ItemKind::Wand,
                weapon_category: None,
                item: Some(ItemId::WandFrost),
                tier: TierRequirement::Any,
                upgrade: crate::query::UpgradeRequirement::Exact(2),
                effect: EffectRequirement::Any,
                require_uncursed: false,
                select_trinket: false,
                trinket_transmutations: 0,
                artifact_transmutations: 0,
                blanket: false,
                exclude_resin: false,
                source: None,
                identity_group: None,
                max_depth: None,
                alternative_group: None,
                level_sum: None,
            }],
            max_depth: 4,
            challenges: crate::challenges::Challenges::NONE,
            require_blacksmith: false,
            exclude_blacksmith_rewards: false,
            wandmaker_quest: None,
        };
        let options = SearchOptions {
            start_seed: 0,
            end_seed_exclusive: 1_000,
            workers: NonZeroUsize::MIN,
            chunk_size: NonZeroUsize::new(64).unwrap(),
            max_results: NonZeroUsize::new(4).unwrap(),
        };
        let generator = Arc::new(BatchOnlyGenerator);
        let handle = spawn_streaming_search(&generator, query, options).unwrap();
        let mut worlds = Vec::new();
        while !handle.is_finished() {
            worlds.extend(handle.drain_results(2));
            std::thread::yield_now();
        }
        worlds.extend(handle.drain_results(10));

        assert_eq!(handle.state(), StreamingSearchState::Completed);
        assert_eq!(handle.total(), 1_000);
        assert_eq!(handle.accepted(), 4);
        assert_eq!(worlds.len(), 4);
        assert_eq!(
            worlds
                .iter()
                .map(|world| world.seed.value())
                .collect::<Vec<_>>(),
            vec![0, 17, 34, 51]
        );
    }

    #[test]
    fn rotated_streaming_search_wraps_once_and_visits_each_seed_once() {
        #[derive(Default)]
        struct RecordingGenerator(Mutex<Vec<u64>>);

        impl WorldGenerator for RecordingGenerator {
            fn generate(&self, seed: crate::seed::DungeonSeed, _max_depth: u8) -> GeneratedWorld {
                self.0
                    .lock()
                    .unwrap_or_else(std::sync::PoisonError::into_inner)
                    .push(seed.value());
                GeneratedWorld {
                    floor_rooms: Vec::new(),
                    artifact_decks: Vec::new(),
                    feelings: Vec::new(),
                    quests: crate::quests::QuestSummary::default(),
                    seed,
                    items: Vec::new(),
                    ring_gems: RingGems::UNSHUFFLED,
                }
            }
        }

        let query = SearchQuery {
            floor_requirements: Vec::new(),
            auto_apply_trinket: false,
            arcane_resin_filter: crate::query::ArcaneResinFilter::default(),
            arcane_resin_auto: false,
            arcane_resin: 0,
            requirements: vec![Requirement {
                kind: ItemKind::Wand,
                weapon_category: None,
                item: Some(ItemId::WandFrost),
                tier: TierRequirement::Any,
                upgrade: crate::query::UpgradeRequirement::Exact(2),
                effect: EffectRequirement::Any,
                require_uncursed: false,
                select_trinket: false,
                trinket_transmutations: 0,
                artifact_transmutations: 0,
                blanket: false,
                exclude_resin: false,
                source: None,
                identity_group: None,
                max_depth: None,
                alternative_group: None,
                level_sum: None,
            }],
            max_depth: 4,
            challenges: crate::challenges::Challenges::NONE,
            require_blacksmith: false,
            exclude_blacksmith_rewards: false,
            wandmaker_quest: None,
        };
        let options = SearchOptions {
            start_seed: 10,
            end_seed_exclusive: 20,
            workers: NonZeroUsize::MIN,
            chunk_size: NonZeroUsize::new(4).unwrap(),
            max_results: NonZeroUsize::MIN,
        };
        let generator = Arc::new(RecordingGenerator::default());
        let handle = spawn_rotated_streaming_search(&generator, query, options, 17).unwrap();
        while !handle.is_finished() {
            std::thread::yield_now();
        }

        assert_eq!(handle.state(), StreamingSearchState::Completed);
        assert_eq!(handle.tested(), 10);
        assert_eq!(handle.total(), 10);
        assert_eq!(
            *generator
                .0
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner),
            vec![17, 18, 19, 10, 11, 12, 13, 14, 15, 16]
        );
    }

    #[test]
    fn cancelled_search_stays_running_until_queued_results_are_drained() {
        // Every seed matches, so cancelling after completion of the first
        // chunk leaves undrained matches queued. Reporting Cancelled before
        // they are drained would lose them: they are inside the consumed
        // prefix and a resumed traversal never revisits it.
        let options = SearchOptions {
            start_seed: 0,
            end_seed_exclusive: 4,
            workers: NonZeroUsize::MIN,
            chunk_size: NonZeroUsize::new(4).unwrap(),
            max_results: NonZeroUsize::new(16).unwrap(),
        };
        let generator = Arc::new(ModuloGenerator(1));
        let handle =
            spawn_partial_streaming_search(&generator, wand_query(), options, 0, 4).unwrap();
        finish(&handle);
        handle.cancel();

        assert_eq!(handle.state(), StreamingSearchState::Running);
        assert_eq!(handle.drain_results(16).len(), 4);
        assert_eq!(handle.state(), StreamingSearchState::Cancelled);
    }

    #[test]
    fn streaming_status_stays_running_until_terminal_results_are_drained() {
        let query = SearchQuery {
            floor_requirements: Vec::new(),
            auto_apply_trinket: false,
            arcane_resin_filter: crate::query::ArcaneResinFilter::default(),
            arcane_resin_auto: false,
            arcane_resin: 0,
            requirements: vec![Requirement {
                kind: ItemKind::Wand,
                weapon_category: None,
                item: Some(ItemId::WandFrost),
                tier: TierRequirement::Any,
                upgrade: crate::query::UpgradeRequirement::Exact(2),
                effect: EffectRequirement::Any,
                require_uncursed: false,
                select_trinket: false,
                trinket_transmutations: 0,
                artifact_transmutations: 0,
                blanket: false,
                exclude_resin: false,
                source: None,
                identity_group: None,
                max_depth: None,
                alternative_group: None,
                level_sum: None,
            }],
            max_depth: 4,
            challenges: crate::challenges::Challenges::NONE,
            require_blacksmith: false,
            exclude_blacksmith_rewards: false,
            wandmaker_quest: None,
        };
        let options = SearchOptions {
            start_seed: 0,
            end_seed_exclusive: 1,
            workers: NonZeroUsize::MIN,
            chunk_size: NonZeroUsize::MIN,
            max_results: NonZeroUsize::MIN,
        };
        let generator = Arc::new(DivisibleGenerator);
        let handle = spawn_streaming_search(&generator, query, options).unwrap();
        while !handle.is_finished() {
            std::thread::yield_now();
        }

        assert_eq!(handle.state(), StreamingSearchState::Running);
        assert_eq!(handle.drain_results(1).len(), 1);
        assert_eq!(handle.state(), StreamingSearchState::Completed);
    }

    fn wand_query() -> SearchQuery {
        SearchQuery {
            floor_requirements: Vec::new(),
            auto_apply_trinket: false,
            arcane_resin_filter: crate::query::ArcaneResinFilter::default(),
            arcane_resin_auto: false,
            arcane_resin: 0,
            requirements: vec![Requirement {
                kind: ItemKind::Wand,
                weapon_category: None,
                item: Some(ItemId::WandFrost),
                tier: TierRequirement::Any,
                upgrade: crate::query::UpgradeRequirement::Exact(2),
                effect: EffectRequirement::Any,
                require_uncursed: false,
                select_trinket: false,
                trinket_transmutations: 0,
                artifact_transmutations: 0,
                blanket: false,
                exclude_resin: false,
                source: None,
                identity_group: None,
                max_depth: None,
                alternative_group: None,
                level_sum: None,
            }],
            max_depth: 4,
            challenges: crate::challenges::Challenges::NONE,
            require_blacksmith: false,
            exclude_blacksmith_rewards: false,
            wandmaker_quest: None,
        }
    }

    struct ModuloGenerator(u64);

    impl WorldGenerator for ModuloGenerator {
        fn generate(&self, seed: crate::seed::DungeonSeed, _max_depth: u8) -> GeneratedWorld {
            let items = if seed.value() % self.0 == 0 {
                vec![WorldItem {
                    item: ItemId::WandFrost,
                    upgrade: 2,
                    effect: None,
                    cursed: false,
                    secret: false,
                    depth: 1,
                    source: ItemSource::Heap,
                    accessibility: Accessibility::Independent,
                }]
            } else {
                Vec::new()
            };
            GeneratedWorld {
                floor_rooms: Vec::new(),
                artifact_decks: Vec::new(),
                feelings: Vec::new(),
                seed,
                items,
                quests: crate::quests::QuestSummary::default(),
                ring_gems: RingGems::UNSHUFFLED,
            }
        }
    }

    fn finish(handle: &super::StreamingSearchHandle) {
        while !handle.is_finished() {
            std::thread::yield_now();
        }
    }

    #[test]
    fn partial_streaming_search_scans_exactly_the_requested_arc() {
        #[derive(Default)]
        struct RecordingGenerator(Mutex<Vec<u64>>);

        impl WorldGenerator for RecordingGenerator {
            fn generate(&self, seed: crate::seed::DungeonSeed, _max_depth: u8) -> GeneratedWorld {
                self.0
                    .lock()
                    .unwrap_or_else(std::sync::PoisonError::into_inner)
                    .push(seed.value());
                GeneratedWorld {
                    floor_rooms: Vec::new(),
                    artifact_decks: Vec::new(),
                    feelings: Vec::new(),
                    seed,
                    items: Vec::new(),
                    quests: crate::quests::QuestSummary::default(),
                    ring_gems: RingGems::UNSHUFFLED,
                }
            }
        }

        let options = SearchOptions {
            start_seed: 10,
            end_seed_exclusive: 20,
            workers: NonZeroUsize::MIN,
            chunk_size: NonZeroUsize::new(4).unwrap(),
            max_results: NonZeroUsize::MIN,
        };
        let generator = Arc::new(RecordingGenerator::default());
        let handle =
            spawn_partial_streaming_search(&generator, wand_query(), options, 17, 5).unwrap();
        finish(&handle);

        assert_eq!(handle.state(), StreamingSearchState::Completed);
        assert_eq!(handle.total(), 5);
        assert_eq!(handle.tested(), 5);
        assert_eq!(
            *generator
                .0
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner),
            vec![17, 18, 19, 10, 11]
        );
        // The arc [17, 12) is fully consumed; a follow-up scan starts at 12.
        assert_eq!(handle.scanned_prefix(), 5);
        assert_eq!(
            handle.resume_coverage(),
            super::ResumeCoverage {
                position: 12,
                remaining: 0
            }
        );

        assert!(matches!(
            spawn_partial_streaming_search(&generator, wand_query(), options, 17, 11),
            Err(SearchError::InvalidSeedRange)
        ));
    }

    #[test]
    fn zero_length_partial_search_completes_without_scanning() {
        let options = SearchOptions {
            start_seed: 0,
            end_seed_exclusive: 100,
            workers: NonZeroUsize::new(2).unwrap(),
            chunk_size: NonZeroUsize::new(4).unwrap(),
            max_results: NonZeroUsize::MIN,
        };
        let generator = Arc::new(DivisibleGenerator);
        let handle =
            spawn_partial_streaming_search(&generator, wand_query(), options, 40, 0).unwrap();
        finish(&handle);

        assert_eq!(handle.state(), StreamingSearchState::Completed);
        assert_eq!(handle.tested(), 0);
        let coverage = handle.resume_coverage();
        assert_eq!(coverage.remaining, 0);
        assert_eq!(coverage.position, 40);
    }

    #[test]
    fn unsatisfiable_partial_search_reports_no_coverage() {
        // A +4 ring cannot exist by depth sixteen, so the plan is proved
        // unsatisfiable and the search completes without generating a single
        // world. Completing without scanning must not consume the remainder:
        // the hint hands the whole requested arc back to the caller, so a
        // later satisfiable continuation can still cover it.
        let impossible = SearchQuery {
            floor_requirements: Vec::new(),
            auto_apply_trinket: false,
            arcane_resin_filter: crate::query::ArcaneResinFilter::default(),
            arcane_resin_auto: false,
            arcane_resin: 0,
            requirements: vec![Requirement {
                kind: ItemKind::Ring,
                weapon_category: None,
                item: None,
                tier: TierRequirement::Any,
                upgrade: crate::query::UpgradeRequirement::Exact(4),
                effect: EffectRequirement::Any,
                require_uncursed: false,
                select_trinket: false,
                trinket_transmutations: 0,
                artifact_transmutations: 0,
                blanket: false,
                exclude_resin: false,
                source: None,
                identity_group: None,
                max_depth: None,
                alternative_group: None,
                level_sum: None,
            }],
            max_depth: 16,
            challenges: crate::challenges::Challenges::NONE,
            require_blacksmith: false,
            exclude_blacksmith_rewards: false,
            wandmaker_quest: None,
        };
        let options = SearchOptions {
            start_seed: 0,
            end_seed_exclusive: 100,
            workers: NonZeroUsize::new(2).unwrap(),
            chunk_size: NonZeroUsize::new(4).unwrap(),
            max_results: NonZeroUsize::MIN,
        };
        let generator = Arc::new(DivisibleGenerator);
        let handle =
            spawn_partial_streaming_search(&generator, impossible, options, 30, 50).unwrap();
        finish(&handle);

        assert_eq!(handle.state(), StreamingSearchState::Completed);
        assert_eq!(handle.tested(), 0);
        assert_eq!(
            handle.resume_coverage(),
            super::ResumeCoverage {
                position: 30,
                remaining: 50
            }
        );
    }

    #[test]
    fn capped_resumed_passes_always_advance_and_never_duplicate() {
        // Every seed matches; a cap of two fills mid-chunk. The cap gates
        // claiming — a claimed chunk still runs to completion — so every
        // pass is guaranteed to advance coverage by at least one chunk, and
        // cap-stopped passes never re-deliver a seed.
        let options = SearchOptions {
            start_seed: 0,
            end_seed_exclusive: 10,
            workers: NonZeroUsize::MIN,
            chunk_size: NonZeroUsize::new(4).unwrap(),
            max_results: NonZeroUsize::new(2).unwrap(),
        };
        let generator = Arc::new(ModuloGenerator(1));
        let mut found = Vec::new();
        let mut resume_from = 0;
        let mut remaining = 10;
        let mut passes = 0;
        while remaining > 0 {
            passes += 1;
            let handle = spawn_partial_streaming_search(
                &generator,
                wand_query(),
                options,
                resume_from,
                remaining,
            )
            .unwrap();
            finish(&handle);
            let coverage = handle.resume_coverage();
            assert!(
                coverage.remaining < remaining,
                "every capped pass must advance coverage"
            );
            found.extend(
                handle
                    .drain_results(16)
                    .into_iter()
                    .map(|world| world.seed.value()),
            );
            resume_from = coverage.position;
            remaining = coverage.remaining;
        }

        // One full chunk per pass: [0, 4), [4, 8), [8, 10).
        assert_eq!(passes, 3);
        // Every seed is recovered exactly once across the resumed passes.
        assert_eq!(found, (0..10).collect::<Vec<_>>());
    }

    #[test]
    fn the_result_cap_stops_at_a_chunk_boundary_with_exact_coverage() {
        // Even seeds match. The cap of three fills inside the chunk [4, 8),
        // which still runs to completion (overshooting the cap by one match)
        // before the worker stops claiming.
        let options = SearchOptions {
            start_seed: 0,
            end_seed_exclusive: 12,
            workers: NonZeroUsize::MIN,
            chunk_size: NonZeroUsize::new(4).unwrap(),
            max_results: NonZeroUsize::new(3).unwrap(),
        };
        let generator = Arc::new(ModuloGenerator(2));
        let handle =
            spawn_partial_streaming_search(&generator, wand_query(), options, 0, 12).unwrap();
        finish(&handle);

        assert_eq!(
            handle
                .drain_results(16)
                .into_iter()
                .map(|world| world.seed.value())
                .collect::<Vec<_>>(),
            vec![0, 2, 4, 6]
        );
        assert_eq!(handle.scanned_prefix(), 8);
        assert_eq!(
            handle.resume_coverage(),
            super::ResumeCoverage {
                position: 8,
                remaining: 4
            }
        );
    }

    #[test]
    fn cancelled_multiworker_search_reports_a_safe_resume_position() {
        let options = SearchOptions {
            start_seed: 0,
            end_seed_exclusive: SEARCH_SEEDS,
            workers: NonZeroUsize::new(4).unwrap(),
            chunk_size: NonZeroUsize::new(4).unwrap(),
            max_results: NonZeroUsize::new(1_024).unwrap(),
        };
        let generator = Arc::new(ModuloGenerator(17));
        let handle =
            spawn_partial_streaming_search(&generator, wand_query(), options, 100, SEARCH_SEEDS)
                .unwrap();
        handle.cancel();
        finish(&handle);

        let coverage = handle.resume_coverage();
        assert_eq!(coverage.remaining, SEARCH_SEEDS - handle.scanned_prefix());
        let first_found = handle
            .drain_results(2_048)
            .into_iter()
            .map(|world| world.seed.value())
            .collect::<Vec<_>>();

        // Resuming after the cancelled prefix recovers every remaining match:
        // the union covers each multiple of seventeen at least once.
        let resumed = spawn_partial_streaming_search(
            &generator,
            wand_query(),
            options,
            coverage.position,
            coverage.remaining,
        )
        .unwrap();
        finish(&resumed);
        let mut union = first_found;
        union.extend(
            resumed
                .drain_results(2_048)
                .into_iter()
                .map(|world| world.seed.value()),
        );
        union.sort_unstable();
        union.dedup();
        assert_eq!(
            union,
            (0..SEARCH_SEEDS)
                .filter(|seed| seed % 17 == 0)
                .collect::<Vec<_>>()
        );
    }

    #[test]
    fn failed_search_stays_running_until_queued_results_are_drained() {
        // Every seed matches and the generator panics at seed six, inside the
        // second chunk. The four matches from the completed first chunk sit
        // inside the consumed prefix a refined search never revisits, so they
        // must be drained before the failure becomes observable; the panicked
        // chunk itself stays out of the reported coverage.
        struct MatchThenPanic;

        impl WorldGenerator for MatchThenPanic {
            fn generate(&self, seed: crate::seed::DungeonSeed, _max_depth: u8) -> GeneratedWorld {
                assert_ne!(seed.value(), 6, "fixture panic at seed six");
                GeneratedWorld {
                    floor_rooms: Vec::new(),
                    artifact_decks: Vec::new(),
                    feelings: Vec::new(),
                    seed,
                    items: vec![WorldItem {
                        item: ItemId::WandFrost,
                        upgrade: 2,
                        effect: None,
                        cursed: false,
                        secret: false,
                        depth: 1,
                        source: ItemSource::Heap,
                        accessibility: Accessibility::Independent,
                    }],
                    quests: crate::quests::QuestSummary::default(),
                    ring_gems: RingGems::UNSHUFFLED,
                }
            }
        }

        let options = SearchOptions {
            start_seed: 0,
            end_seed_exclusive: 12,
            workers: NonZeroUsize::MIN,
            chunk_size: NonZeroUsize::new(4).unwrap(),
            max_results: NonZeroUsize::new(16).unwrap(),
        };
        let generator = Arc::new(MatchThenPanic);
        let handle =
            spawn_partial_streaming_search(&generator, wand_query(), options, 0, 12).unwrap();
        finish(&handle);

        assert_eq!(handle.state(), StreamingSearchState::Running);
        assert_eq!(handle.drain_results(16).len(), 4);
        assert_eq!(handle.state(), StreamingSearchState::Failed);
        assert_eq!(
            handle.resume_coverage(),
            super::ResumeCoverage {
                position: 4,
                remaining: 8
            }
        );
    }

    #[test]
    fn streaming_failure_retains_claimed_chunk_and_panic_message() {
        struct PanicAtSix;

        impl WorldGenerator for PanicAtSix {
            fn generate(&self, seed: crate::seed::DungeonSeed, _max_depth: u8) -> GeneratedWorld {
                assert_ne!(seed.value(), 6, "fixture panic at seed six");
                GeneratedWorld {
                    floor_rooms: Vec::new(),
                    artifact_decks: Vec::new(),
                    feelings: Vec::new(),
                    quests: crate::quests::QuestSummary::default(),
                    seed,
                    items: Vec::new(),
                    ring_gems: RingGems::UNSHUFFLED,
                }
            }
        }

        let query = SearchQuery {
            floor_requirements: Vec::new(),
            auto_apply_trinket: false,
            arcane_resin_filter: crate::query::ArcaneResinFilter::default(),
            arcane_resin_auto: false,
            arcane_resin: 0,
            requirements: vec![Requirement {
                kind: ItemKind::Wand,
                weapon_category: None,
                item: Some(ItemId::WandFrost),
                tier: TierRequirement::Any,
                upgrade: crate::query::UpgradeRequirement::Exact(2),
                effect: EffectRequirement::Any,
                require_uncursed: false,
                select_trinket: false,
                trinket_transmutations: 0,
                artifact_transmutations: 0,
                blanket: false,
                exclude_resin: false,
                source: None,
                identity_group: None,
                max_depth: None,
                alternative_group: None,
                level_sum: None,
            }],
            max_depth: 4,
            challenges: crate::challenges::Challenges::NONE,
            require_blacksmith: false,
            exclude_blacksmith_rewards: false,
            wandmaker_quest: None,
        };
        let options = SearchOptions {
            start_seed: 0,
            end_seed_exclusive: 12,
            workers: NonZeroUsize::MIN,
            chunk_size: NonZeroUsize::new(4).unwrap(),
            max_results: NonZeroUsize::MIN,
        };
        let generator = Arc::new(PanicAtSix);
        let handle = spawn_streaming_search(&generator, query, options).unwrap();
        while !handle.is_finished() {
            std::thread::yield_now();
        }

        assert_eq!(handle.state(), StreamingSearchState::Failed);
        assert_eq!(handle.tested(), 4);
        let failure = handle.failure().unwrap();
        assert_eq!(failure.chunk_start, Some(4));
        assert_eq!(failure.chunk_end_exclusive, Some(8));
        assert!(failure.message.contains("fixture panic at seed six"));
    }
    type WorldMap = std::collections::BTreeMap<u64, GeneratedWorld>;
    type RealRelease = Arc<(Mutex<bool>, std::sync::Condvar)>;

    struct ReleaseCanonicalBatch(RealRelease);
    impl Drop for ReleaseCanonicalBatch {
        fn drop(&mut self) {
            *self
                .0
                .0
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner) = true;
            self.0.1.notify_all();
        }
    }

    struct StalledCanonicalBatch {
        generator: crate::main_world::CanonicalMainWorldGenerator,
        first_seed: u64,
        release: RealRelease,
        reached: std::sync::mpsc::Sender<()>,
    }
    impl WorldGenerator for StalledCanonicalBatch {
        fn generate(&self, seed: crate::seed::DungeonSeed, max_depth: u8) -> GeneratedWorld {
            self.generator.generate(seed, max_depth)
        }
        fn generate_batch_gated(
            &self,
            seeds: &[crate::seed::DungeonSeed],
            max_depth: u8,
            gate: &dyn super::FloorGate,
        ) -> Vec<Option<GeneratedWorld>> {
            let worlds = self.generator.generate_batch_gated(seeds, max_depth, gate);
            if seeds
                .first()
                .is_some_and(|seed| seed.value() == self.first_seed)
            {
                let _ = self.reached.send(());
                let mut release = self
                    .release
                    .0
                    .lock()
                    .unwrap_or_else(std::sync::PoisonError::into_inner);
                while !*release {
                    release = self
                        .release
                        .1
                        .wait(release)
                        .unwrap_or_else(std::sync::PoisonError::into_inner);
                }
            }
            worlds
        }
    }

    fn merge_finished_worlds(handle: &super::StreamingSearchHandle, worlds: &mut WorldMap) {
        finish(handle);
        let drained = handle.drain_results(usize::MAX);
        assert_eq!(u64::try_from(drained.len()).unwrap(), handle.accepted());
        for world in drained {
            if let Some(previous) = worlds.insert(world.seed.value(), world.clone()) {
                assert_eq!(
                    previous, world,
                    "overlapping resumed seeds preserve complete worlds"
                );
            }
        }
    }

    // Nonempty ring matches across wraparound and a three-seed chunk tail,
    // without thousands of canonical generations in an unoptimized CI build.
    const REAL_STREAM_SEEDS: u64 = 263;

    fn real_stream_fixture() -> (
        crate::main_world::CanonicalMainWorldGenerator,
        SearchQuery,
        SearchOptions,
        WorldMap,
    ) {
        let generator = crate::main_world::CanonicalMainWorldGenerator;
        let query = crate::json_query::decode(
            r#"{"auto_apply_trinket":false,"max_depth":1,"requirements":[{"kind":"ring"}]}"#,
        )
        .unwrap();
        let options = SearchOptions {
            start_seed: 20_000_000,
            end_seed_exclusive: 20_000_000 + REAL_STREAM_SEEDS,
            workers: NonZeroUsize::new(4).unwrap(),
            chunk_size: NonZeroUsize::new(4).unwrap(),
            max_results: NonZeroUsize::MAX,
        };
        let expected =
            search_parallel(&generator, &query, options, &SearchProgress::default()).unwrap();
        assert_eq!(expected.tested, REAL_STREAM_SEEDS);
        assert!(!expected.worlds.is_empty());
        (
            generator,
            query,
            options,
            expected
                .worlds
                .into_iter()
                .map(|world| (world.seed.value(), world))
                .collect(),
        )
    }

    #[test]
    fn canonical_cancelled_wrapped_search_resumes_without_losing_worlds() {
        let (generator, query, options, expected) = real_stream_fixture();
        let generator = Arc::new(generator);
        let start = options.end_seed_exclusive - 3;
        let (sent, received) = std::sync::mpsc::channel();
        let release = Arc::new((Mutex::new(false), std::sync::Condvar::new()));
        let delayed = Arc::new(StalledCanonicalBatch {
            generator: crate::main_world::CanonicalMainWorldGenerator,
            first_seed: start,
            release: Arc::clone(&release),
            reached: sent,
        });
        let handle = spawn_partial_streaming_search(
            &delayed,
            query.clone(),
            options,
            start,
            REAL_STREAM_SEEDS,
        )
        .unwrap();
        let unblock = ReleaseCanonicalBatch(release);
        received
            .recv_timeout(std::time::Duration::from_secs(10))
            .unwrap();
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(10);
        while handle.accepted() == 0 {
            assert!(
                std::time::Instant::now() < deadline,
                "other workers must deliver a match"
            );
            std::thread::yield_now();
        }
        handle.cancel();
        drop(unblock);
        let mut actual = WorldMap::new();
        merge_finished_worlds(&handle, &mut actual);
        assert_eq!(handle.state(), StreamingSearchState::Cancelled);
        assert!(
            !actual.is_empty(),
            "exercise duplicate delivery across resumed coverage"
        );
        let coverage = handle.resume_coverage();
        assert_eq!(
            coverage,
            super::ResumeCoverage {
                position: start,
                remaining: REAL_STREAM_SEEDS
            }
        );
        let resumed = spawn_partial_streaming_search(
            &generator,
            query,
            options,
            coverage.position,
            coverage.remaining,
        )
        .unwrap();
        merge_finished_worlds(&resumed, &mut actual);
        assert_eq!(resumed.state(), StreamingSearchState::Completed);
        assert_eq!(resumed.resume_coverage().remaining, 0);
        assert_eq!(actual, expected);
    }

    #[test]
    fn canonical_capped_passes_cover_every_world_across_wrap() {
        let (generator, query, mut options, expected) = real_stream_fixture();
        let generator = Arc::new(generator);
        options.max_results = NonZeroUsize::new(7).unwrap();
        let mut coverage = super::ResumeCoverage {
            position: options.end_seed_exclusive - 3,
            remaining: REAL_STREAM_SEEDS,
        };
        let mut actual = WorldMap::new();
        let mut passes = 0;
        while coverage.remaining > 0 {
            let handle = spawn_partial_streaming_search(
                &generator,
                query.clone(),
                options,
                coverage.position,
                coverage.remaining,
            )
            .unwrap();
            let previous_count = actual.len();
            merge_finished_worlds(&handle, &mut actual);
            assert_eq!(handle.state(), StreamingSearchState::Completed);
            let cap_bound =
                options.max_results.get() + options.workers.get() * options.chunk_size.get();
            assert!(
                handle.accepted() < u64::try_from(cap_bound).unwrap(),
                "result-cap overshoot is bounded by in-flight chunks"
            );
            assert_eq!(
                u64::try_from(actual.len() - previous_count).unwrap(),
                handle.accepted(),
                "cap-only passes must deliver disjoint complete chunks"
            );
            let next = handle.resume_coverage();
            assert_eq!(handle.tested(), coverage.remaining - next.remaining);
            assert!(
                next.remaining < coverage.remaining,
                "each capped pass must advance coverage"
            );
            coverage = next;
            passes += 1;
            assert!(passes <= REAL_STREAM_SEEDS);
        }
        assert!(passes > 1, "exercise result-cap interruption");
        assert_eq!(actual, expected);
    }
}
