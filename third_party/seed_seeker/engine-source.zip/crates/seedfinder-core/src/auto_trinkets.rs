//! Query-aware selection of one initial trinket before world generation.
//!
//! Preparing a policy uses the measured equipment profiles once per search.
//! Resolving it only reads the seed's private offer deck: it never scouts or
//! branches, and never combines loot from different possible worlds.
use crate::catalog::{Effect, ItemId, ItemKind};
use crate::feasibility::QueryPlan;
use crate::model::{GeneratedWorld, WorldItem};
use crate::probability::cached_equipment_probability as equipment_probability;
use crate::probability_tables::trinkets::Profile;
use crate::query::{EffectRequirement, SearchQuery};
use crate::quests::QuestSummary;
use crate::search::{FloorGate, WorldGenerator};
use crate::seed::DungeonSeed;
use crate::trinkets::{initial_offers, trinket_order};
use std::collections::VecDeque;
use std::sync::Mutex;

/// Reproducible world conditions for a result, independent of editor changes.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SeedRecipe {
    pub seed: DungeonSeed,
    pub trinket: Option<ItemId>,
}

/// A matching world with the exact choice used to generate it.
#[derive(Clone, Debug)]
pub struct TrinketSearchMatch {
    pub world: GeneratedWorld,
    pub recipe: SeedRecipe,
}

/// Attach recipes to already-matched streaming worlds and strip unnecessary
/// automatic choices with the same replay used by batch search.
#[must_use]
pub fn finish_matches<G: WorldGenerator>(
    generator: &G,
    query: &SearchQuery,
    plan: &QueryPlan,
    worlds: Vec<GeneratedWorld>,
) -> Vec<TrinketSearchMatch> {
    let matches = worlds
        .into_iter()
        .map(|world| {
            Some(TrinketSearchMatch {
                recipe: SeedRecipe {
                    seed: world.seed,
                    trinket: plan.selected_trinket(world.seed),
                },
                world,
            })
        })
        .collect();
    remove_unnecessary_trinkets(generator, query, plan, matches)
        .into_iter()
        .flatten()
        .collect()
}

/// Search once per input seed using a prepared query plan. Auto-applied
/// matches alone get a no-trinket replay to remove unnecessary choices.
/// One output per input preserves traversal accounting even for pruned seeds.
#[must_use]
pub fn search_batch<G: WorldGenerator>(
    generator: &G,
    query: &SearchQuery,
    plan: &QueryPlan,
    seeds: &[DungeonSeed],
) -> Vec<Option<TrinketSearchMatch>> {
    if plan.is_unsatisfiable() {
        return seeds.iter().map(|_| None).collect();
    }
    let results = match_batch(generator, query, plan, plan.generation_depth(), seeds);
    remove_unnecessary_trinkets(generator, query, plan, results)
}

struct RecipeGate<'a> {
    plan: &'a QueryPlan,
    choices: std::collections::BTreeMap<u64, Option<ItemId>>,
}

impl FloorGate for RecipeGate<'_> {
    fn floor_requirement(
        &self,
        depth: u8,
    ) -> Option<&crate::floor_filters::CompiledFloorRequirement> {
        self.plan.floor_requirement(depth)
    }
    fn deferred_vault_plan(&self, target: u8) -> Option<&QueryPlan> {
        self.plan.deferred_vault_plan(target)
    }

    fn continue_after_run_init(&self, run: &crate::run::RunState) -> bool {
        self.plan.continue_after_run_init(run)
    }

    fn selected_trinket(&self, seed: DungeonSeed) -> Option<ItemId> {
        self.choices.get(&seed.value()).copied().flatten()
    }
    fn continue_after_floor(&self, depth: u8, items: &[WorldItem], quests: &QuestSummary) -> bool {
        self.plan.continue_after_floor(depth, items, quests)
    }
    fn wants_vault_treasure(&self) -> bool {
        self.plan.wants_vault_treasure()
    }
}

fn remove_unnecessary_trinkets<G: WorldGenerator>(
    generator: &G,
    query: &SearchQuery,
    plan: &QueryPlan,
    mut results: Vec<Option<TrinketSearchMatch>>,
) -> Vec<Option<TrinketSearchMatch>> {
    if !enabled(query) {
        return results;
    }
    let selected: Vec<_> = results
        .iter()
        .enumerate()
        .filter_map(|(index, result)| {
            result
                .as_ref()
                .and_then(|result| result.recipe.trinket.map(|_| (index, result.recipe.seed)))
        })
        .collect();
    if selected.is_empty() {
        return results;
    }
    // Reuse the query's floor/vault pruning without its automatic choice.
    // Failed initial searches never get this extra generation pass.
    let gate = RecipeGate {
        plan,
        choices: std::collections::BTreeMap::new(),
    };
    let seeds: Vec<_> = selected.iter().map(|&(_, seed)| seed).collect();
    let baseline = match_batch(generator, query, &gate, plan.generation_depth(), &seeds);
    for ((index, _), result) in selected.into_iter().zip(baseline) {
        if result.is_some() {
            // Replace the world as well as its recipe: callers must see the
            // exact no-trinket items, not loot from the original generation.
            results[index] = result;
        }
    }
    results
}

/// Verify saved recipes against new item predicates while retaining their
/// original world conditions, then remove any unnecessary automatic choice.
/// User-facing refinement should use [`refine_batch`] to honor current trinket
/// requirements; this lower-level replay also serves generation parity checks.
#[must_use]
pub fn filter_batch<G: WorldGenerator>(
    generator: &G,
    query: &SearchQuery,
    plan: &QueryPlan,
    recipes: &[SeedRecipe],
) -> Vec<Option<TrinketSearchMatch>> {
    if plan.is_unsatisfiable() {
        return recipes.iter().map(|_| None).collect();
    }
    let gate = RecipeGate {
        plan,
        choices: recipes
            .iter()
            .map(|r| (r.seed.value(), r.trinket))
            .collect(),
    };
    let seeds: Vec<_> = recipes.iter().map(|r| r.seed).collect();
    let results = match_batch(generator, query, &gate, plan.generation_depth(), &seeds);
    remove_unnecessary_trinkets(generator, query, plan, results)
}

/// Refine under the original automatic choice, including choices previously
/// removed as unnecessary. Test that world first; only successful matches get
/// the usual no-trinket cleanup. Never rerank using the edited query while
/// automatic selection remains enabled and preserves required offers. Explicit +3 selection or
/// disabling automatic selection instead use the current query's world.
#[must_use]
pub fn refine_batch<G: WorldGenerator>(
    generator: &G,
    query: &SearchQuery,
    plan: &QueryPlan,
    base: &SearchQuery,
    recipes: &[SeedRecipe],
) -> Vec<Option<TrinketSearchMatch>> {
    if plan.is_unsatisfiable() {
        return recipes.iter().map(|_| None).collect();
    }
    let seeds: Vec<_> = recipes.iter().map(|r| r.seed).collect();
    if !enabled(query) {
        return search_batch(generator, query, plan, &seeds);
    }
    let original = QueryPlan::analyze(base);
    let reapply = enabled(base);
    let gate = RecipeGate {
        plan,
        choices: recipes
            .iter()
            .map(|r| {
                (
                    r.seed.value(),
                    r.trinket
                        .or_else(|| {
                            if reapply {
                                original.selected_trinket(r.seed)
                            } else {
                                None
                            }
                        })
                        .filter(|id| {
                            preserves_required_offers(query, *id, &initial_offers(r.seed))
                        }),
                )
            })
            .collect(),
    };
    let results = match_batch(generator, query, &gate, plan.generation_depth(), &seeds);
    remove_unnecessary_trinkets(generator, query, plan, results)
}

fn match_batch<G: WorldGenerator>(
    generator: &G,
    query: &SearchQuery,
    gate: &dyn FloorGate,
    depth: u8,
    seeds: &[DungeonSeed],
) -> Vec<Option<TrinketSearchMatch>> {
    // The caller's prepared gate owns pruning. QueryPlan also selects the
    // minimal generation horizon; recipe overrides do not change sources.
    generator
        .generate_batch_gated(seeds, depth, gate)
        .into_iter()
        .map(|world| {
            world
                .filter(|world| {
                    let safe = !enabled(query)
                        || gate.selected_trinket(world.seed).is_none_or(|chosen| {
                            preserves_required_offers(query, chosen, &initial_offers(world.seed))
                        });
                    safe && query.matches(world)
                })
                .map(|world| TrinketSearchMatch {
                    recipe: SeedRecipe {
                        seed: world.seed,
                        trinket: gate.selected_trinket(world.seed),
                    },
                    world,
                })
        })
        .collect()
}

fn preserves_required_offers(query: &SearchQuery, chosen: ItemId, offers: &[ItemId]) -> bool {
    query
        .requirements
        .iter()
        .filter(|r| r.kind == ItemKind::Trinket)
        .filter_map(|r| r.item)
        .all(|id| id == chosen || !offers.contains(&id))
}

/// Generation effects with a directional equipment benefit. Feeling changes
/// and neutral trinkets are deliberately excluded.
pub const CANDIDATES: [ItemId; 4] = [
    ItemId::ParchmentScrap,
    ItemId::MimicTooth,
    ItemId::RatSkull,
    ItemId::CrackedSpyglass,
];

/// The complete deterministic choice rule for the initial offer deck.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AutoTrinketPolicy {
    preferred: Vec<ItemId>,
    /// Preserve requested initial offers: discarded offers cannot be transmuted back before refill.
    requested: Vec<ItemId>,
}

// Filtering is split into cancellable batches and native worker slices. Ranking
// the same query in every slice can cost much more than generating the worlds,
// especially with automatic resin. Keep a small, process-local cache shared by
// those workers. Complete query equality prevents stale choices after edits.
const POLICY_CACHE_CAPACITY: usize = 8;
static POLICY_CACHE: Mutex<PolicyCache> = Mutex::new(PolicyCache(VecDeque::new()));

struct PolicyCache(VecDeque<(SearchQuery, AutoTrinketPolicy)>);

impl PolicyCache {
    fn get_or_prepare(
        &mut self,
        query: &SearchQuery,
        prepare: impl FnOnce() -> AutoTrinketPolicy,
    ) -> AutoTrinketPolicy {
        let entry = self
            .0
            .iter()
            .position(|(cached, _)| cached == query)
            .and_then(|index| self.0.remove(index))
            .unwrap_or_else(|| (query.clone(), prepare()));
        let policy = entry.1.clone();
        self.0.push_back(entry);
        if self.0.len() > POLICY_CACHE_CAPACITY {
            self.0.pop_front();
        }
        policy
    }
}

impl AutoTrinketPolicy {
    /// Prepare once per query. Explicit +3 selection overrides the automatic rule.
    /// Availability requirements instead restrict which starting offers are safe.
    #[must_use]
    pub fn prepare(query: &SearchQuery) -> Option<Self> {
        if !enabled(query) {
            return None;
        }
        // Hold the lock during preparation so concurrent native workers do not
        // all repeat the same expensive cold calculation. Generation never
        // holds this lock.
        Some(
            POLICY_CACHE
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner)
                .get_or_prepare(query, || Self::prepare_uncached(query)),
        )
    }

    fn prepare_uncached(query: &SearchQuery) -> Self {
        // Preserve item-based selection; floor rules are evaluated in the selected world.
        // Room sampling noise must not cause an otherwise unnecessary trinket choice.
        let mut item_query = query.clone();
        item_query.floor_requirements.clear();
        let mut requested: Vec<_> = query
            .requirements
            .iter()
            .filter(|r| r.kind == ItemKind::Trinket)
            .filter_map(|r| r.item)
            .collect();
        requested.sort_unstable();
        requested.dedup();
        // Deck availability is independent of equipment supply. Pure trinket
        // slots need no equipment; mixed OR slots retain their equipment alternatives.
        item_query
            .requirements
            .retain(|r| r.kind != ItemKind::Trinket);
        let query = &item_query;
        let baseline = equipment_probability(query, Profile::None);
        let forbids_parchment = query.requirements.iter().any(|r| match r.effect {
            EffectRequirement::OneOf(set) => set.effects().any(Effect::is_curse),
            EffectRequirement::Any => false,
        });
        let mut scores: Vec<_> = CANDIDATES
            .into_iter()
            .filter(|&id| id != ItemId::ParchmentScrap || !forbids_parchment)
            .map(|id| (id, equipment_probability(query, Profile::of(id))))
            .collect();
        // Stable sorting gives a fixed tie-break, independent of offer order.
        scores.sort_by(|a, b| finite_score(b.1).total_cmp(&finite_score(a.1)));
        Self {
            requested,
            preferred: scores
                .iter()
                .filter(|(_, p)| baseline.is_finite() && p.is_finite() && *p > baseline * 1.05)
                .map(|&(id, _)| id)
                .collect(),
        }
    }

    /// Choose a beneficial initial offer, or none, without generating floors.
    #[must_use]
    pub fn selected_trinket(&self, seed: DungeonSeed) -> Option<ItemId> {
        if self.preferred.is_empty() {
            return None;
        }
        self.choose(&initial_offers(seed))
    }

    pub(crate) fn choose(&self, offers: &[ItemId]) -> Option<ItemId> {
        self.preferred
            .iter()
            .copied()
            .find(|id| offers.contains(id) && self.preserves_offers(*id, offers))
    }

    fn preserves_offers(&self, chosen: ItemId, offers: &[ItemId]) -> bool {
        self.requested
            .iter()
            .all(|id| *id == chosen || !offers.contains(id))
    }

    /// Preferred generation effects, in descending estimated match probability.
    #[must_use]
    pub fn preferred(&self) -> &[ItemId] {
        &self.preferred
    }
}

fn finite_score(score: f64) -> f64 {
    if score.is_finite() { score } else { 0.0 }
}

/// Whether the requested setting applies to this query.
#[must_use]
pub fn enabled(query: &SearchQuery) -> bool {
    query.auto_apply_trinket && !query.requirements.iter().any(|r| r.select_trinket)
}

/// Probability of the chosen policy, averaged over all 2,380 offer subsets.
/// Equipment profiles already include the first brewing opportunity.
pub(crate) fn probability(query: &SearchQuery, policy: &AutoTrinketPolicy) -> f64 {
    if query
        .requirements
        .iter()
        .any(|r| r.kind == ItemKind::Trinket)
    {
        return crate::probability::trinket_deck::probability(query, Some(policy));
    }
    let baseline = equipment_probability(query, Profile::None);
    let scores = CANDIDATES.map(|id| equipment_probability(query, Profile::of(id)));
    let identities = trinket_order(DungeonSeed::MIN);
    let mut sum = 0.0;
    let mut count = 0_u32;
    for a in 0..14 {
        for b in a + 1..15 {
            for c in b + 1..16 {
                for d in c + 1..17 {
                    let selected = policy.choose(&[
                        identities[a],
                        identities[b],
                        identities[c],
                        identities[d],
                    ]);
                    sum += selected
                        .and_then(|id| CANDIDATES.iter().position(|&candidate| candidate == id))
                        .map_or(baseline, |index| scores[index]);
                    count += 1;
                }
            }
        }
    }
    sum / f64::from(count)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::challenges::Challenges;
    use crate::json_query;
    use crate::main_world::{CanonicalMainWorldGenerator, generate_main_world_with_trinket};
    use std::sync::atomic::{AtomicUsize, Ordering};

    fn query(requirements: &str) -> SearchQuery {
        json_query::decode(&format!(
            r#"{{"auto_apply_trinket":true,"max_depth":19,"requirements":{requirements}}}"#
        ))
        .unwrap()
    }

    #[test]
    fn feasibility_checks_do_not_wait_for_automatic_trinket_scoring() {
        let query = crate::deep_link::decode_text(
            "https://shpd-seed-seeker.web.app/#q=q6gAAAuW4ABLYAAlwAAXPGABc8AZhc8AZh-sAA_cAANuQKAdkLACCIIx",
        ).unwrap();
        // Model another worker preparing a costly resin/blanket policy. A UI
        // feasibility probe must not acquire this lock or rank any profiles.
        let scoring = POLICY_CACHE.lock().unwrap();
        let (sender, receiver) = std::sync::mpsc::channel();
        let check = std::thread::spawn(move || {
            sender.send(QueryPlan::check_impossibility(&query)).unwrap();
        });
        let result = receiver.recv_timeout(std::time::Duration::from_secs(5));
        // Release before joining even on failure, so a regression reports an
        // assertion instead of deadlocking the rest of the suite.
        drop(scoring);
        check.join().unwrap();
        assert_eq!(
            result.expect("feasibility waited for probability scoring"),
            None
        );
    }

    #[test]
    fn filtering_workers_rank_an_unchanged_query_only_once_across_batches() {
        let query = query(r#"[{"item":"runic_blade","upgrade":1,"effect":"Grim"}]"#);
        let cache = Mutex::new(PolicyCache(VecDeque::new()));
        let preparations = AtomicUsize::new(0);
        std::thread::scope(|scope| {
            for _ in 0..8 {
                scope.spawn(|| {
                    // The Android controller checks 1,024 saved seeds in 43 batches.
                    for _ in 0..43 {
                        let policy = cache.lock().unwrap().get_or_prepare(&query, || {
                            preparations.fetch_add(1, Ordering::Relaxed);
                            AutoTrinketPolicy::prepare_uncached(&query)
                        });
                        assert_eq!(policy.preferred()[0], ItemId::ParchmentScrap);
                    }
                });
            }
        });
        assert_eq!(preparations.load(Ordering::Relaxed), 1);
    }

    #[test]
    fn cached_policies_follow_query_edits_and_have_a_bounded_lifetime() {
        let mut cache = PolicyCache(VecDeque::new());
        let base = query(r#"[{"kind":"armor","upgrade":1}]"#);
        for depth in 1..=24 {
            let mut edited = base.clone();
            edited.max_depth = depth;
            let expected = AutoTrinketPolicy::prepare_uncached(&edited);
            assert_eq!(cache.get_or_prepare(&edited, || expected.clone()), expected);
            assert_eq!(
                cache.get_or_prepare(&edited, || panic!("cached query reranked")),
                expected
            );
            assert!(cache.0.len() <= POLICY_CACHE_CAPACITY);
        }
        let mut edited = base;
        edited.requirements.push(edited.requirements[0]);
        let expected = AutoTrinketPolicy::prepare_uncached(&edited);
        assert_eq!(cache.get_or_prepare(&edited, || expected.clone()), expected);
    }

    struct CountingGenerator(AtomicUsize);
    impl WorldGenerator for CountingGenerator {
        fn generate(&self, _: DungeonSeed, _: u8) -> GeneratedWorld {
            panic!("batch path expected")
        }
        fn generate_batch_gated(
            &self,
            seeds: &[DungeonSeed],
            depth: u8,
            gate: &dyn FloorGate,
        ) -> Vec<Option<GeneratedWorld>> {
            self.0.fetch_add(seeds.len(), Ordering::Relaxed);
            CanonicalMainWorldGenerator.generate_batch_gated(seeds, depth, gate)
        }
    }

    #[test]
    fn every_offer_set_selects_only_a_beneficial_choice_or_none() {
        let identities = trinket_order(DungeonSeed::MIN);
        for requirements in [
            r#"[{"item":"runic_blade","upgrade":1,"effect":"Grim"}]"#,
            r#"[{"kind":"melee_weapon","effect":["Grim","Annoying"]}]"#,
        ] {
            let policy = AutoTrinketPolicy::prepare(&query(requirements)).unwrap();
            let curse = requirements.contains("Annoying");
            for a in 0..14 {
                for b in a + 1..15 {
                    for c in b + 1..16 {
                        for d in c + 1..17 {
                            let offers =
                                [identities[a], identities[b], identities[c], identities[d]];
                            if let Some(choice) = policy.choose(&offers) {
                                assert!(offers.contains(&choice));
                                assert!(policy.preferred().contains(&choice));
                                assert!(!curse || choice != ItemId::ParchmentScrap);
                            } else {
                                assert!(offers.iter().all(|id| !policy.preferred().contains(id)));
                            }
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn unhelpful_offers_keep_the_no_trinket_world() {
        let mut early = query(r#"[{"item":"leather_armor","upgrade":1}]"#);
        early.max_depth = 2;
        let policy = AutoTrinketPolicy::prepare(&early).unwrap();
        assert!(policy.preferred().is_empty());
        assert_eq!(policy.selected_trinket(DungeonSeed::MIN), None);
        let mut baseline = early.clone();
        baseline.auto_apply_trinket = false;
        let seeds: Vec<_> = (0..64)
            .map(|value| DungeonSeed::new(value).unwrap())
            .collect();
        let automatic = search_batch(
            &CanonicalMainWorldGenerator,
            &early,
            &QueryPlan::analyze(&early),
            &seeds,
        );
        let plain = search_batch(
            &CanonicalMainWorldGenerator,
            &baseline,
            &QueryPlan::analyze(&baseline),
            &seeds,
        );
        assert!(automatic.iter().any(Option::is_some));
        for (automatic, plain) in automatic.into_iter().zip(plain) {
            assert_eq!(
                automatic.as_ref().map(|m| &m.world),
                plain.as_ref().map(|m| &m.world)
            );
            if let Some(result) = automatic {
                assert_eq!(result.recipe.trinket, None);
                assert!(baseline.matches(&result.world));
            }
        }
        let grim = AutoTrinketPolicy::prepare(&query(
            r#"[{"item":"runic_blade","upgrade":1,"effect":"Grim"}]"#,
        ))
        .unwrap();
        assert_eq!(
            grim.choose(&[
                ItemId::SaltCube,
                ItemId::WondrousResin,
                ItemId::MossyClump,
                ItemId::TrapMechanism
            ]),
            None
        );
    }

    #[test]
    fn whole_query_ranking_and_explicit_requirements_control_selection() {
        let grim = query(r#"[{"item":"runic_blade","upgrade":1,"effect":"Grim"}]"#);
        assert_eq!(
            AutoTrinketPolicy::prepare(&grim).unwrap().preferred()[0],
            ItemId::ParchmentScrap
        );
        let ring = query(r#"[{"item":"ring_might","upgrade":2,"max_depth":9}]"#);
        assert_eq!(
            AutoTrinketPolicy::prepare(&ring).unwrap().preferred()[0],
            ItemId::MimicTooth
        );
        let explicit = query(
            r#"[{"any_of":[{"item":"mimic_tooth","select_trinket":true},{"item":"rat_skull"}]}]"#,
        );
        assert!(AutoTrinketPolicy::prepare(&explicit).is_none());
        let unselected = query(r#"[{"item":"rat_skull"}]"#);
        assert!(
            AutoTrinketPolicy::prepare(&unselected)
                .unwrap()
                .preferred()
                .is_empty()
        );
        let mut baseline = grim.clone();
        baseline.auto_apply_trinket = false;
        assert!(AutoTrinketPolicy::prepare(&baseline).is_none());
        assert!(
            crate::probability::estimate_match_probability(&grim)
                > crate::probability::estimate_match_probability(&baseline)
        );
    }

    #[test]
    fn transmutation_budget_keeps_benefit_rule_and_preserves_required_offers() {
        let mut query = query(r#"[{"item":"dimensional_sundial","trinket_transmutations":1}]"#);
        let policy = AutoTrinketPolicy::prepare(&query).unwrap();
        assert!(
            policy.preferred().is_empty(),
            "a trinket-only query needs no helper"
        );
        query.requirements.extend(
            self::query(r#"[{"kind":"melee_weapon","source":"golden_mimic"}]"#).requirements,
        );
        let policy = AutoTrinketPolicy::prepare(&query).unwrap();
        assert_eq!(policy.preferred()[0], ItemId::MimicTooth);
        assert_eq!(
            policy.selected_trinket(DungeonSeed::MIN),
            None,
            "choosing Mimic Tooth would discard the initial Sundial"
        );
        let seed = DungeonSeed::from_code("AAA-AAA-AAN").unwrap();
        let order = trinket_order(seed);
        assert_eq!(order[4], ItemId::DimensionalSundial);
        assert!(order[..4].contains(&ItemId::MimicTooth));
        let plan = QueryPlan::analyze(&query);
        assert_eq!(plan.selected_trinket(seed), Some(ItemId::MimicTooth));
        let result = search_batch(&CanonicalMainWorldGenerator, &query, &plan, &[seed])[0]
            .clone()
            .unwrap();
        assert_eq!(result.recipe.trinket, Some(ItemId::MimicTooth));
        assert!(query.matches(&result.world));
        assert!(
            filter_batch(
                &CanonicalMainWorldGenerator,
                &query,
                &plan,
                &[result.recipe]
            )[0]
            .is_some()
        );
        let mut only_trinket = query.clone();
        only_trinket.requirements.truncate(1);
        let refined = refine_batch(
            &CanonicalMainWorldGenerator,
            &only_trinket,
            &QueryPlan::analyze(&only_trinket),
            &query,
            &[result.recipe],
        );
        assert_eq!(refined[0].as_ref().unwrap().recipe.trinket, None);
    }

    #[test]
    fn transmutation_probability_conditions_helpful_profiles_on_the_deck() {
        let mut query = query(
            r#"[{"item":"ring_might","upgrade":2},{"item":"dimensional_sundial","trinket_transmutations":1}]"#,
        );
        let policy = AutoTrinketPolicy {
            preferred: vec![ItemId::MimicTooth],
            requested: vec![ItemId::DimensionalSundial],
        };
        let mut equipment = query.clone();
        equipment.requirements.truncate(1);
        let baseline = equipment_probability(&equipment, Profile::None);
        let mimic = equipment_probability(&equipment, Profile::of(ItemId::MimicTooth));
        // Four initial Sundial positions use baseline. At tail #1, Mimic Tooth
        // is among the initial four with probability 4/16.
        let expected = (19.0 * baseline + mimic) / 68.0;
        assert!((probability(&query, &policy) - expected).abs() < 1e-12);
        query.requirements[1].trinket_transmutations = 13;
        let expected = (55.0 * baseline + 13.0 * mimic) / 68.0;
        assert!((probability(&query, &policy) - expected).abs() < 1e-12);
    }

    struct RejectChosen {
        expected: ItemId,
        calls: AtomicUsize,
    }
    impl WorldGenerator for RejectChosen {
        fn generate(&self, _: DungeonSeed, _: u8) -> GeneratedWorld {
            panic!("batch expected")
        }
        fn generate_batch_gated(
            &self,
            seeds: &[DungeonSeed],
            _: u8,
            gate: &dyn FloorGate,
        ) -> Vec<Option<GeneratedWorld>> {
            self.calls.fetch_add(1, Ordering::Relaxed);
            for &seed in seeds {
                assert_eq!(gate.selected_trinket(seed), Some(self.expected));
            }
            // A miss in the chosen world is accepted: no baseline rescue.
            seeds.iter().map(|_| None).collect()
        }
    }

    #[test]
    fn adding_glyphed_armor_to_auto_resin_query_keeps_items_but_can_change_world_policy() {
        let mut base = json_query::decode(
            r#"{"max_depth":24,"exclude_blacksmith_rewards":true,"arcane_resin":"auto",
                "requirements":[
                    {"item":"wand_disintegration"}, {"item":"wand_lightning"}, {"kind":"wand"},
                    {"item":"ring_energy","identity_group":1,"level_sum":{"group":1,"at_least":5}},
                    {"kind":"ring","identity_group":1,"level_sum":{"group":1,"at_least":5}},
                    {"kind":"ring","identity_group":1,"level_sum":{"group":1,"at_least":5}},
                    {"item":"chalice_of_blood"}, {"item":"horn_of_plenty"}
                ]}"#,
        )
        .unwrap();
        let armor = json_query::decode(
            r#"{"requirements":[{"kind":"armor","tier":{"at_most":3},"upgrade":3,"effect":"Brimstone"}]}"#,
        )
        .unwrap()
        .requirements[0];
        let mut candidate = base.clone();
        candidate.requirements.push(armor);
        base.auto_apply_trinket = true;
        candidate.auto_apply_trinket = true;

        // A changed ranking must not change the choice, even when a null
        // recipe records a trinket that was unnecessary for the parent.
        let original = QueryPlan::analyze(&base);
        let edited = QueryPlan::analyze(&candidate);
        let seed = (0..128)
            .map(|v| DungeonSeed::new(v).unwrap())
            .find(|&seed| {
                original.selected_trinket(seed).is_some()
                    && original.selected_trinket(seed) != edited.selected_trinket(seed)
            })
            .unwrap();
        let generator = RejectChosen {
            expected: original.selected_trinket(seed).unwrap(),
            calls: AtomicUsize::new(0),
        };
        assert!(
            refine_batch(
                &generator,
                &candidate,
                &edited,
                &base,
                &[SeedRecipe {
                    seed,
                    trinket: None
                }]
            )[0]
            .is_none()
        );
        assert_eq!(generator.calls.load(Ordering::Relaxed), 1);
    }

    #[test]
    fn necessary_trinkets_survive_baseline_replay_and_saved_choices_replay_the_match() {
        let seed = DungeonSeed::from_code("SRU-YSU-QHS").unwrap();
        // 4.0.2 supplies a Grim tomahawk only in the Parchment Scrap world.
        let query = query(r#"[{"kind":"weapon","effect":"Grim"}]"#);
        let plan = QueryPlan::analyze(&query);
        let generator = CountingGenerator(AtomicUsize::new(0));
        let result = search_batch(&generator, &query, &plan, &[seed])
            .pop()
            .unwrap()
            .unwrap();
        assert_eq!(generator.0.load(Ordering::Relaxed), 2);
        assert_eq!(result.recipe.trinket, Some(ItemId::ParchmentScrap));
        let baseline = generate_main_world_with_trinket(seed, 24, Challenges::NONE, None).unwrap();
        assert!(!query.matches(&baseline));
        let replay =
            generate_main_world_with_trinket(seed, 24, Challenges::NONE, result.recipe.trinket)
                .unwrap();
        assert!(query.matches(&replay));
        assert_eq!(
            baseline
                .items
                .iter()
                .filter(|i| i.depth <= 2)
                .collect::<Vec<_>>(),
            replay
                .items
                .iter()
                .filter(|i| i.depth <= 2)
                .collect::<Vec<_>>()
        );
        assert!(filter_batch(&generator, &query, &plan, &[result.recipe])[0].is_some());
        assert!(
            filter_batch(
                &generator,
                &query,
                &plan,
                &[SeedRecipe {
                    seed,
                    trinket: None
                }]
            )[0]
            .is_none()
        );
        assert_eq!(generator.0.load(Ordering::Relaxed), 5);
    }

    #[test]
    fn only_auto_applied_matches_are_rechecked_and_unneeded_worlds_are_replaced() {
        let seed = DungeonSeed::from_code("EYY-RUL-LQG").unwrap();
        let query = query(r#"[{"kind":"weapon","effect":"Grim"}]"#);
        let plan = QueryPlan::analyze(&query);
        assert_eq!(plan.selected_trinket(seed), Some(ItemId::ParchmentScrap));
        let generator = CountingGenerator(AtomicUsize::new(0));
        let required = DungeonSeed::from_code("SRU-YSU-QHS").unwrap();
        let results = search_batch(
            &generator,
            &query,
            &plan,
            &[seed, DungeonSeed::MIN, required],
        );
        assert_eq!(results.len(), 3);
        assert!(results[1].is_none());
        assert_eq!(
            results[2].as_ref().unwrap().recipe.trinket,
            Some(ItemId::ParchmentScrap)
        );
        assert_eq!(generator.0.load(Ordering::Relaxed), 5); // Three searches, two match rechecks.
        let result = results[0].as_ref().unwrap();
        assert_eq!(
            result.recipe,
            SeedRecipe {
                seed,
                trinket: None
            }
        );

        let mut baseline_query = query.clone();
        baseline_query.auto_apply_trinket = false;
        let baseline = search_batch(
            &generator,
            &baseline_query,
            &QueryPlan::analyze(&baseline_query),
            &[seed],
        );
        assert_eq!(result.world, baseline[0].as_ref().unwrap().world);
        assert_eq!(generator.0.load(Ordering::Relaxed), 6); // No recheck with auto off.
        let filtered = filter_batch(&generator, &query, &plan, &[result.recipe]);
        assert_eq!(filtered[0].as_ref().unwrap().world, result.world);
        assert_eq!(generator.0.load(Ordering::Relaxed), 7); // No recheck for a null recipe.

        let explicit = json_query::decode(
            r#"{"auto_apply_trinket":true,"max_depth":19,
            "requirements":[{"kind":"weapon","effect":"Grim"},
                {"item":"parchment_scrap","select_trinket":true}]}"#,
        )
        .unwrap();
        let explicit_result = search_batch(
            &generator,
            &explicit,
            &QueryPlan::analyze(&explicit),
            &[seed],
        );
        assert_eq!(
            explicit_result[0].as_ref().unwrap().recipe.trinket,
            Some(ItemId::ParchmentScrap)
        );
        assert_eq!(generator.0.load(Ordering::Relaxed), 8); // Manual choices are preserved.
    }
}
