//! Local, bounded browser adapter for the pinned GPL-3.0-or-later generator.
use serde_json::{Value, json};
use shpd_seedfinder_core::{catalog, main_world, model::Accessibility, model::source_name, seed::{DungeonSeed, TOTAL_SEEDS}};
use std::sync::Mutex;

static OUTPUT: Mutex<Vec<u8>> = Mutex::new(Vec::new());

fn checked_seed(raw: u64) -> Result<DungeonSeed, String> {
    if raw < TOTAL_SEEDS { return DungeonSeed::new(raw).map_err(|e| e.to_string()); }
    let daily = DungeonSeed::daily_at_unix_seconds((raw - TOTAL_SEEDS) / 1000).map_err(|e| e.to_string())?;
    if daily.value() != raw { return Err("Unsupported numeric seed; enter a nine-letter seed code or a UTC daily date.".into()); }
    Ok(daily)
}

pub fn document(raw: u64, depth: u32) -> Result<Value, String> {
    if !(1..=24).contains(&depth) { return Err("Maximum depth must be 1..24.".into()); }
    let seed = checked_seed(raw)?;
    let world = main_world::generate_main_world(seed, depth as u8).map_err(|e| e.to_string())?;
    let items: Vec<Value> = world.items.iter().map(|entry| {
        let definition = catalog::item(entry.item);
        let access = match entry.accessibility {
            Accessibility::Independent => json!({"type":"independent"}),
            Accessibility::Choice {group, option} => json!({"type":"choice","group":group,"option":option}),
            Accessibility::Scenarios {group, mask} => json!({"type":"scenarios","group":group,"mask":mask.to_string()}),
        };
        json!({"id":definition.stable_id,"class":format!("{:?}",entry.item),"name":definition.display_name,
            "kind":format!("{:?}",definition.kind),"tier":definition.tier,"depth":entry.depth,
            "level":entry.displayed_upgrade(),"transfer_level":entry.upgrade,"cursed":entry.cursed,
            "effect":entry.effect.map(|e| e.wire_name()),"effect_curse":entry.effect.is_some_and(|e| e.is_curse()),
            "source":source_name(entry.source),"secret":entry.secret,"access":access})
    }).collect();
    let floors: Vec<Value> = world.floor_rooms.iter().map(|floor| {
        json!({"depth":floor.depth,"rooms":floor.rooms.iter().map(|r|r.stable_id()).collect::<Vec<_>>(),
            "feeling":world.feelings.iter().find(|f|f.depth==floor.depth).map(|f|format!("{:?}",f.feeling))})
    }).collect();
    Ok(json!({"schema":1,"game_version":shpd_seedfinder_core::SHPD_VERSION,"game_commit":shpd_seedfinder_core::SHPD_COMMIT,
        "engine_commit":"b3596f5c0d26852acc20bb6de4f2169ebcbdd24a","profile":"canonical-warrior-no-challenges-no-trinket",
        "seed":raw.to_string(),"seed_code":seed.to_code(),"daily":seed.is_daily(),"maximum_depth":depth,
        "items":items,"floors":floors}))
}

/// No input pointers or host APIs: one bounded generation per disposable worker.
#[unsafe(no_mangle)]
pub extern "C" fn forecast(low: u32, high: u32, depth: u32) -> u32 {
    let raw = u64::from(low) | (u64::from(high) << 32);
    let value = document(raw, depth).unwrap_or_else(|error| json!({"error":error}));
    let mut output = OUTPUT.lock().expect("single worker output lock");
    *output = serde_json::to_vec(&value).expect("document serialization");
    output.len() as u32
}

#[unsafe(no_mangle)]
pub extern "C" fn result_ptr() -> *const u8 {
    OUTPUT.lock().expect("single worker output lock").as_ptr()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rejects_invalid_bounds_without_generation() {
        for depth in [0,25,u32::MAX] { assert!(document(0,depth).is_err()); }
        for seed in [TOTAL_SEEDS+1,u64::MAX] { assert!(document(seed,1).is_err()); }
    }
    #[test]
    fn preserves_full_daily_identity() {
        let seed = DungeonSeed::from_daily_date("2026-10-11").unwrap();
        assert_eq!(checked_seed(seed.value()).unwrap(),seed);
        assert!(checked_seed(seed.value()+1).is_err());
    }
    #[test]
    fn normal_prefix_has_bounded_provenance_and_choice_constraints() {
        let first=document(0,4).unwrap();
        assert_eq!(first,document(0,4).unwrap());
        assert_eq!(first["game_version"],"4.0.2");
        let items=first["items"].as_array().unwrap();
        assert!(!items.is_empty());
        assert!(items.iter().all(|i|i["depth"].as_u64().unwrap()<=4));
        assert!(items.iter().any(|i|i["access"]["type"]=="choice"));
        assert!(items.iter().all(|i|i["class"].is_string()&&i["source"].is_string()));
    }
    #[test]
    fn canonical_full_world_and_daily_generate() {
        for seed in [0,DungeonSeed::MAX.value(),DungeonSeed::from_daily_date("2026-10-11").unwrap().value()] {
            let result=document(seed,24).unwrap();
            assert_eq!(result["seed"],seed.to_string());
            assert!(result["items"].as_array().unwrap().iter().all(|i|i["depth"].as_u64().unwrap()<=24));
            assert!(result["floors"].as_array().unwrap().iter().any(|f|f["depth"]==24));
        }
    }
}
